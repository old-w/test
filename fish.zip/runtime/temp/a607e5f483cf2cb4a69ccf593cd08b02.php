<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:87:"D:\phpStudy\PHPTutorial\WWW\fish_game\public/../application/admin\view\index\index.html";i:1537320911;}*/ ?>


<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title><?php echo $html_title; ?></title>
  <meta name="renderer" content="webkit">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
  <link rel="stylesheet" href="/static/admin/layui/css/layui.css" media="all">
</head>
<body>
  <div id="LAY_app"></div>
  <script src="https://cdn.bootcss.com/jquery/3.3.1/jquery.min.js"></script>
  <script src="/static/admin/layui/layui.js"></script>
  <script>
  layui.config({
    base: '/static/admin/src/'
    ,title:'<?php echo $admin_title; ?>'
    ,version: '20180730-1'
  }).use('index');

  </script>
</body>
</html>


