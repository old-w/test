<?php
/**
 * author xtj
 * createtime 2019/5/30 0030 上午 11:15
 * return array obj json bool
 * param
 */

/**
 * 统一返回处理类（ajax）允许跨域
 *
 * 使用： **
 *      use Gucci\ServerResponse;
 *      return ServerResponse::createBySuccess("成功");
 *      ServerResponse::createByError("断点失败了");
 */

namespace Gucci;

use think\Config;
use think\exception\HttpResponseException;
use think\Response;

class ServerResponse
{
    public static $successCode = 200;
    public static $errorCode = 404;

    //构造函数
    public function __construct($status,$msg = "",$data = [])
    {

        $result['status'] = $status;
        $msg ? $result['msg'] = $msg : null;
        $data ? $result['data'] = $data : null;

        $type                                   = $this->getResponseType();
        $header['Access-Control-Allow-Origin']  = '*';
        $header['Access-Control-Allow-Headers'] = 'X-Requested-With,Content-Type';
        $header['Access-Control-Allow-Methods'] = 'GET,POST,PATCH,PUT,DELETE,OPTIONS';
        $response                               = Response::create($result, $type)->header($header);
        throw  new HttpResponseException($response);
    }

    /**
     * 成功
     * @param $msg
     * @param null $data
     * @return ServerResponse
     */
    public static function createBySuccess($msg, $data = null){
        return new ServerResponse(self::$successCode, $msg,$data);
    }

    /**
     * 失败
     * @param $msg
     * @return ServerResponse
     */
    public static function createByError($msg){
        return new ServerResponse(self::$errorCode, $msg);

    }

    /**
     * 获取当前的response 输出类型
     * @access protected
     * @return string
     */
    private function getResponseType()
    {
        return Config::get('default_ajax_return');
    }
}
