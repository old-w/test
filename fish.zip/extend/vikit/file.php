<?php
namespace vikit;

use think\File as tpFile;

class file extends tpFile
{
    public function savename($path)
    {
        $path = $path.$this->buildSaveName(true).'png';
        $dir = dirname($path);
        if(!is_dir($dir)){
            mkdir($dir);
        }
        return $path;
    }
}