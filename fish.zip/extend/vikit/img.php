<?php
namespace vikit;

use think\Image;

class img extends Image
{
    public function __construct(\SplFileInfo $file)
    {
        parent::__construct($file);
    }

    public function show($w=null,$h=null)
    {
        if($w > 0 && $h > 0){
            $this->thumb($w,$h);
        }
        Header("Content-type: image/png");
        ob_start();
        imagepng($this->im, null, 9);
        ob_end_flush();

        die;
        return;
    }
}