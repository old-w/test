<?php

namespace app\admin\controller;

use think\Controller;
use app\common\model\Config;

class Index extends Controller
{
    public function index()
    {
        $config = new Config;
        $this->assign([
            'html_title'=>$config->value('html_title'),
            'admin_title'=>$config->value('admin_title'),
        ]);
        return view();
    }
}
