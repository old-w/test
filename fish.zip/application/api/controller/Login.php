<?php
namespace app\api\controller;

use think\Controller;
use think\Request;
use think\Cache;
use think\Cookie;
use Gucci\ServerResponse;
use think\Db;

class Login extends Controller
{
    /*
     * 判断是否已登录
     * */
    public function isLogin(Request $request){
        header('Access-Control-Allow-Origin:*');
        $params = $request->param();
        if ($params['token'] == ''  || !isset($params['token'])){
            return ServerResponse::createByError('没有登录');
        }
        $res = db('user')->where('token',$params['token'])->find();
        if ($res){
            return ServerResponse::createBySuccess('已登录',$res);
        }else{
            return ServerResponse::createByError('token错误');
        }
    }
    /**
     * 获取短信验证码
     */
    public function getCode(Request $request)
    {
        header('Access-Control-Allow-Origin:*');
        $params = $request->param();
        if (!is_numeric($params['phone']) || !preg_match("/^1[345789]{1}\d{9}$/",$params['phone'])){
            return  ServerResponse::createByError('请输入正确的手机号');
        }
        $phone = $params['phone'];
        $code = rand(100001,999999);
        $result = send_sms($phone,['code'=>$code]);
        if ($result['Message'] == 'OK'){
            Cache::set($phone.'_code',$code);
            return ServerResponse::createBySuccess('发送成功');
        }else{
            return  ServerResponse::createByError('发送失败');
        }
    }

    /**
     * 登陆
     * 两种方式
     * 1.普通登录
     * 2.分享登录
     */
    public function login(Request $request)
    {
        header('Access-Control-Allow-Origin:*');
        $params = $request->param();
        if (!is_numeric($params['phone']) || !preg_match("/^1[345789]{1}\d{9}$/",$params['phone'])){
            return  ServerResponse::createByError('请输入正确的手机号');
        }
        if (!is_numeric($params['code'])){
            return  ServerResponse::createByError('验证码错误');
        }
        $phone = $params['phone'];
        $code = Cache::get($phone.'_code');
        if ($code != trim($params['code'])){
            return  ServerResponse::createByError('验证码错误');
        }
        $url = $request->url();         //返回的url，暂时不用
        //判断是否登陆用到的token值
        $strs = '1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM';
        $loginToken = substr(str_shuffle($strs),mt_rand(0,strlen($strs)-11),32);
        //判断是否被邀请的token值
        $hasToken = Request::instance()->has('token','get');
        if ($hasToken == 1){                //分享登录
            //若已经注册  登录  不加鱼钩等级和邀请人数
            $isRegister = db('user')->where('phone',$params['phone'])->find();
            if ($isRegister){
                Cache::set($phone.'_info',$isRegister);
                return  ServerResponse::createBySuccess('用户已注册,不增加邀请者鱼钩等级及邀请人数',$isRegister);
            }
            $invite_id = substr($params['token'],0,stripos($params['token'],'_'));
            $insert_data = [];
            $img_number = rand(1,15);
            $insert_data['phone'] = $phone;
            $insert_data['token'] = $loginToken;
            $insert_data['headimgurl'] = '/static/head_img/'.$img_number.'jpeg';
            //invite 已邀请人数
            $invite_data = [];
            Db::startTrans();
            try{
                $invite = Db::table('user')->where('id',$invite_id)->value('invite_id');
                //邀请者鱼钩等级
                if (!empty($invite)){
                    $invite_data = explode(',',$invite);
                    $invite_num = count($invite_data) + 1;

                    switch ($invite_num){
                        case 2:
                            Db::table('user_fishhook')->where(['is_show',1])->insert(['user_id'=>$invite_id,'fishhook_id'=>2]);
                            Db::table('user_fishhook')->where(['is_show',1])->insert(['user_id'=>$invite_id,'fishhook_id'=>3]);
                            break;
                        case 5:
                            Db::table('user_fishhook')->where(['is_show',1])->insert(['user_id'=>$invite_id,'fishhook_id'=>4]);
                            break;
                        default:
                            break;
                    }
                }
                $id= Db::table('user')->insertGetId($insert_data);
                Db::table('user_fishhook')->insert(['user_id'=>$id,'fishhook_id'=>1]);
                Db::table('user_bait')->insert(['user_id'=>$id,'bait_id'=>5,'amount'=>8]);          //新用户注册送8个水草
                $userData = Db::table('user')->where('id',$id)->find();
                Cache::set($phone.'_info',$userData);
                array_push($invite_data,$id);
                $invite_data = implode(',',$invite_data);
                Db::table('user')->where('id',$invite_id)->setField('invite_id',$invite_data);

                Db::commit();
                return array('status'=>200,'msg'=>'登录成功','data'=>$userData);
            } catch(\Exception $e){
                Db::rollback();
                return array('status'=>404,'msg'=>'登录失败');
            }
        }else{
            //第一次登陆时，注册
            $user_info = db('user')->where('phone',$phone)->find();
            if ($user_info){
                Cache::set($phone.'_info',$user_info);
                return ServerResponse::createBySuccess('登录成功',$user_info);
            }else{
                $img_number = rand(1,15);
                $insert_data = [];
                $insert_data['phone'] = $phone;
                $insert_data['token'] = $loginToken;
                $insert_data['headimgurl'] = '/static/head_img/'.$img_number.'jpeg';
                $id = db('user')->insertGetId($insert_data);
                if ($id){
                    db('user_fishhook')->insert(['user_id'=>$id,'fishhook_id'=>1]);
                    db('user_bait')->insert(['user_id'=>$id,'bait_id'=>5,'amount'=>8]);      //新用户注册送8个水草
                    $result = db('user')->where('phone',$phone)->find();
                    Cache::set($phone.'_info',$result);
                    return ServerResponse::createBySuccess('登录成功',$result);
                }
                return  ServerResponse::createByError('未知错误');
            }
        }


    }
    /*
     * 获取分享链接
     * */
    public function share(Request $request){
        header('Access-Control-Allow-Origin:*');
        $params = $request->param();
        if (!is_numeric($params['id']) || empty($params['id'])) {
            return ServerResponse::createByError('参数错误');
        }
        $has_id = db('user')->where('id',$params['id'])->find();
        if (!$has_id){
            return ServerResponse::createByError('参数错误');
        }
        $strs = '1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM';
        $str=substr(str_shuffle($strs),mt_rand(0,strlen($strs)-11),32);
        $token = $params['id'].'_'.$str;
        $url = 'http://fish-game.7in6.com/index.html?token='.$token;
        return ServerResponse::createBySuccess('获取成功',$url);
    }
    /*
     * 退出登录
     * */
    public function loginOut(Request $request){
        header('Access-Control-Allow-Origin:*');
        $params = $request->param();
        if (!is_numeric($params['phone']) || !preg_match("/^1[345789]{1}\d{9}$/",$params['phone'])){
            return  ServerResponse::createByError('请输入正确的手机号');
        }
        Cache::rm($params['phone'].'_info');
        Cookie::clear('phone');
        return ServerResponse::createBySuccess('退出成功');
    }
}
