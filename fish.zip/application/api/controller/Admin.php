<?php

namespace app\api\controller;

use app\api\model\Jwt;
use think\Cache;
use think\Controller;
use think\Db;
use think\Log;
use think\Request;
use think\Hook;

/**
 * 后台api接口
 */
class Admin extends Controller
{
    /**
     * 管理员信息
     */
    private $admin_info;

    /**
     * JWT
     */
    private $jwt;

    /**
     * JWT鉴权情况
     */
    private $res_data;

    /**
     * 前置规划
     */
    protected $beforeActionList = [
        'jwt' => ['except' => 'login,sendcode,verificationcode,goldToUgasList,goldToUgasVerify,goldToUgasType'],
        'init1' => ['only' => 'user,menu,sendcode,verificationcode,goldToUgasList,goldToUgasVerify,goldToUgasType'],
    ];

    /**
     * 鉴权操作
     */
    public function jwt()
    {
        $jwt = Request::instance()->header('jwt');
        // $JWT = new Jwt;
        // $JWT->jwt($jwt, $this->res_data, $this->jwt);
        $this->jwt = $jwt;
    }

    /**
     * 前置操作1
     */
    public function init1()
    {
        $this->admin_info = model('role')->username(session('admin.username'));
    }

    /**
     * 管理员信息
     */
    public function user()
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        return [
            'code' => 0,
            'data' => [
                'username' => $this->admin_info['name'],
            ],
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 菜单
     */
    public function menu()
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        return [
            'code' => 0,
            'msg' => '',
            'data' => json_decode($this->admin_info['menu']),
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 登录
     */
    public function login($username, $pwd)
    {
        return model('user')->login($username, $pwd);
    }

    /**
     * 退出
     */
    public function out()
    {
        session(null);
        return [
            'code' => 0,
            'msg' => '成功退出',
        ];
    }

    /**
     * 修改密码
     */
    public function pwd()
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $uid = session('admin.uid');

        return model('user')->pwd(Request::instance()->param(), $uid, $this->jwt);
    }

    /**
     * 获取设置项
     */
    public function getConfig()
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $res = Db::name('config')->where('key','eq','qrcode')->find();
        if (!empty($res['value'])){
            return [
                'code' => 0,
                'msg' => '',
                'qrcode' => $res['value'],
                'data' => model('config')->getToData(),
                'jwt' => $this->jwt,
            ];
        }

        return [
            'code' => 0,
            'msg' => '',
            'qrcode' => '',
            'data' => model('config')->getToData(),
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 设置设置项
     */
    public function setConfig()
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $param = Request::instance()->post();
        foreach ($param as $k => $v) {
            model('config')->set($k, $v);
        }

        return [
            'code' => 0,
            'msg' => '配置保存成功',
            'jwt' => $this->jwt,
        ];
    }

    //设置二维码图片上传
    public function upload_qrcode(){
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }
        $file = request()->file('file');
        if($file){
            $info = $file->move(ROOT_PATH . 'public' . DS . 'static'. DS . 'qrcode');
            if($info){
                $res = Db::name('config')->where('key','eq','qrcode')->find();
                if (!empty($res['value'])){
                    unlink(ROOT_PATH . 'public' . $res['value']);
                }
                model('config')->set('qrcode', '/static/qrcode/'.str_replace("\\","/",$info->getSaveName()));
                return [
                    'code' => 0,
                    'msg' => '上传成功，无需保存',
                    'jwt' => $this->jwt,
                ];
            }else{
                // 上传失败获取错误信息
                echo $file->getError();
                return [
                    'code' => 1,
                    'msg' => '上传失败',
                    'jwt' => $this->jwt,
                ];
            }
        }

    }


    /**
     * 用户管理
     */
    public function users($page = 1, $limit =10){
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $search = input('get.');
        $filter = ['id_phone'];
        $map = [];
        if (!empty($search['id_phone'])){
            $map = $this->filterArray($search,$filter);
        }

        $tab = model('tab')->users($page, $limit,$map);
        $count = Db::name('user')->count('id');

        return $tab ? [
            'code' => 0,
            'msg' => '',
            'data' => $tab,
            'count' => $count,
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '当前没有数据',
            'data' => '',
            'jwt' => $this->jwt,
        ];
    }

    public function user_fish($page = 1, $limit =10){
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }
        $id = input('get.id');
        $tab = model('tab')->userFish($page, $limit, $id);
        $count = Db::name('user_fish')->where('user_id',$id)->group('fish_id')->count('id');

        return $tab ? [
            'code' => 0,
            'msg' => '',
            'data' => $tab,
            'count' => $count,
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '当前没有数据',
            'data' => '',
            'jwt' => $this->jwt,
        ];
    }

    public function user_bait($page = 1, $limit =10){
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }
        $id = input('get.id');
        $tab = model('tab')->userBait($page, $limit, $id);
        $count = Db::name('user_bait')->where('user_id',$id)->count('id');

        return $tab ? [
            'code' => 0,
            'msg' => '',
            'data' => $tab,
            'count' => $count,
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '当前没有数据',
            'data' => '',
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 前台管理员审核
     */
    public function admin_type(){
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $data = Request::instance()->param();

        $res  = Db::name('user')->find($data['id']);
        $res['is_admin'] = $data['is_admin'];
        Db::name('user')->update($res);


        return [
            'code' => 0,
            'msg' => '保存成功',
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 删除用户
     */
    public function user_del($id)
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $re = Db::name('user')->delete(['id' => $id]);

        return $re ? [
            'code' => 0,
            'msg' => '删除成功',
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '删除失败',
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 鱼种类
     */
    public function fish($page = 1,$limit = 10)
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $tab = model('tab')->fish($page, $limit);
        $count = Db::name('user_bait')->count('id');

        return $tab ? [
            'code' => 0,
            'msg' => '',
            'data' => $tab,
            'count' => $count,
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '当前没有数据',
            'data' => '',
            'jwt' => $this->jwt,
        ];
    }


    /**
     * 鱼种类型增加
     */
    public function fish_add(){
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $data = Request::instance()->param();

        $re = Db::name('fish')->insert($data);
        if ($re){
            return [
                'code' => 0,
                'msg' => '保存成功',
                'jwt' => $this->jwt,
            ];
        }
    }

    /**
     * 获取鱼类信息
     */
    public function fish_info($id){
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $tab = Db::name('fish')->find($id);

        return $tab ? [
            'code' => 0,
            'msg' => '',
            'data' => $tab,
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '当前没有数据',
            'data' => '',
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 鱼种修改
     */
    public function fish_update(){
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }
        $data = Request::instance()->param();

        $re = Db::table('fish')->update($data);

        if ($re){
            return [
                'code' => 0,
                'msg' => '保存成功',
                'jwt' => $this->jwt,
            ];
        }else{
            return [
                'code' => 1,
                'msg' => '修改失败',
                'jwt' => $this->jwt,
            ];
        }
    }

    /**
     * 删除鱼种类
     */
    public function fish_del($id)
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $re = Db::name('fish')->delete(['id' => $id]);
        Db::name('fish_bait')->where(['fish_id' => $id])->delete();

        return $re ? [
            'code' => 0,
            'msg' => '删除成功',
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '删除失败',
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 概率显示鱼饵
     */
    public function probability($id){
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }
        $tab = Db::name('bait')->order('gold')->select();

        return $tab ? [
            'code' => 0,
            'msg' => '',
            'data' => $tab,
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '当前没有数据',
            'data' => [],
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 概率添加
     * @return array
     */
    public function probability_add(){
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }
        $data = Request::instance()->param();
        if (Db::name('fish_bait')->where(['fish_id'=>$data['fish_id'],'bait_id'=>$data['bait_id']])->find()){
            return [
                'code' => 1,
                'msg' => '添加失败，已有数据',
                'jwt' => $this->jwt,
            ];
        }
        $re = Db::name('fish_bait')->insert($data);
        if ($re){
            return [
                'code' => 0,
                'msg' => '添加成功',
                'jwt' => $this->jwt,
            ];
        }
    }

    /**
     * 概率表格
     * @param int $page
     * @param int $limit
     * @return array
     */
    public function fish_bait_probability($page = 1,$limit = 10){
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }
        $fish_id = Request::instance()->param('fish_id');
        $tab = model('tab')->fish_bait_probability($page, $limit, $fish_id);
        $count = Db::name('fish_bait')->where('fish_id',$fish_id)->count('id');

        return $tab ? [
            'code' => 0,
            'msg' => '',
            'data' => $tab,
            'count' => $count,
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '当前没有数据',
            'data' => '',
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 概率添加
     * @return array
     */
    public function probability_update(){
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }
        $data = Request::instance()->param();
        if (!Db::name('fish_bait')->find($data['id'])){
            return [
                'code' => 1,
                'msg' => '修改失败',
                'jwt' => $this->jwt,
            ];
        }
        $re = Db::name('fish_bait')->update($data);
        if ($re){
            return [
                'code' => 0,
                'msg' => '保存成功',
                'jwt' => $this->jwt,
            ];
        }
    }

    /**
     * 概率删除
     * @param $id
     * @return array
     */
    public function probability_del($id){
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $re = Db::name('fish_bait')->delete(['id' => $id]);

        return $re ? [
            'code' => 0,
            'msg' => '删除成功',
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '删除失败',
            'jwt' => $this->jwt,
        ];
    }


    /**
     * 鱼饵种类
     */
    public function bait($page = 1,$limit = 10)
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $tab = model('tab')->bait($page, $limit);
        $count = Db::name('user_bait')->count('id');

        return $tab ? [
            'code' => 0,
            'msg' => '',
            'data' => $tab,
            'count' => $count,
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '当前没有数据',
            'data' => '',
            'jwt' => $this->jwt,
        ];
    }


    /**
     * 鱼饵类型增加
     */
    public function bait_add(){
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $data = Request::instance()->param();

        $re = Db::name('bait')->insert($data);
        if ($re){
            return [
                'code' => 0,
                'msg' => '保存成功',
                'jwt' => $this->jwt,
            ];
        }
    }

    /**
     * 获取鱼饵信息
     */
    public function bait_info($id){
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $tab = Db::name('bait')->find($id);

        return $tab ? [
            'code' => 0,
            'msg' => '',
            'data' => $tab,
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '当前没有数据',
            'data' => '',
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 鱼饵修改
     */
    public function bait_update(){
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }
        $data = Request::instance()->param();

        $re = Db::table('bait')->update($data);

        if ($re){
            return [
                'code' => 0,
                'msg' => '保存成功',
                'jwt' => $this->jwt,
            ];
        }else{
            return [
                'code' => 1,
                'msg' => '修改失败',
                'jwt' => $this->jwt,
            ];
        }
    }

    /**
     * 删除鱼饵种类
     */
    public function bait_del($id)
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $re = Db::name('bait')->delete(['id' => $id]);
        Db::name('fish_bait')->where(['bait_id' => $id])->delete();

        return $re ? [
            'code' => 0,
            'msg' => '删除成功',
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '删除失败',
            'jwt' => $this->jwt,
        ];
    }



    //增加图片
    public function img_add(){
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }
        $data = Request::instance()->param();

        $image = [];
        $image['id'] = $data['id'];
        if (isset($data['type'])&&$data['type']==2){
            $image['img_url_2'] = $data['image'];
            $re = Db::table($data['tab'])->where('id',$data['id'])->find();
            if (!empty($re['img_url_2'])){
                if(file_exists(ROOT_PATH . 'public' . $re['img_url_2']))
                {
                    unlink(ROOT_PATH . 'public' . $re['img_url_2']);
                }
            }
        }else{
            $image['img_url'] = $data['image'];
            $re = Db::table($data['tab'])->where('id',$data['id'])->find();
            if (!empty($re['img_url'])){
                if(file_exists(ROOT_PATH . 'public' . $re['img_url']))
                {
                    unlink(ROOT_PATH . 'public' . $re['img_url']);
                }
            }
        }

        $re = Db::name($data['tab'])->update($image);
        if ($re){
            return [
                'code' => 0,
                'msg' => '图片保存成功',
                'jwt' => $this->jwt,
            ];
        }else{
            return [
                'code' => 1,
                'msg' => '图片保存失败',
                'jwt' => $this->jwt,
            ];
        }
    }


    /**
     * 钓鱼日志
     */
    public function fishlog($page = 1, $limit =10){
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $search = input('get.');
        $map = [];
        if (!empty($search['fishlog_user_id'])){
            $map['user_id'] = $search['fishlog_user_id'];
        }

        $tab = model('tab')->fishlog($page, $limit,$map);
        $count = Db::name('user_fish')->count('id');

        return $tab ? [
            'code' => 0,
            'msg' => '',
            'data' => $tab,
            'count' => $count,
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '当前没有数据',
            'data' => '',
            'jwt' => $this->jwt,
        ];
    }


    /**
     * 金币日志
     */
    public function goldlog($page = 1, $limit =10){
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $search = input('get.');
        $map = [];
        if (!empty($search['goldlog_user_id'])){
            $map['user_id'] = $search['goldlog_user_id'];
        }

        $tab = model('tab')->goldlog($page, $limit,$map);
        $count = Db::name('gold_log')->count('id');

        return $tab ? [
            'code' => 0,
            'msg' => '',
            'data' => $tab,
            'count' => $count,
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '当前没有数据',
            'data' => '',
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 过滤数组
     * @param $data
     * @param $filter
     * @return array
     */
    public function filterArray($data,$filter){
        $res = [];
        foreach ($filter as $value){
            if (isset($data[$value])){
                $res[$value] = $data[$value];
            }
        }
        return $res;
    }

    //图片上传
    public function upload(){
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }
        $file = request()->file('file');
        if($file){
            $info = $file->move(ROOT_PATH . 'public'. DS . 'static' . DS . 'upload');
            if($info){

                return [
                    'code' => 0,
                    'url' => '/static/upload/'.str_replace("\\","/",$info->getSaveName()),
                    'msg' => '上传成功',
                    'jwt' => $this->jwt,
                ];
            }else{
                // 上传失败获取错误信息
                echo $file->getError();
                return [
                    'code' => 1,
                    'msg' => '上传失败',
                    'jwt' => $this->jwt,
                ];
            }
        }

    }

    /**
     *  金币兑换ugas
     */
    public function tougas($page = 1, $limit =10){
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $search = input('get.');
        $map = [];
        if (!empty($search['gold_to_ugas_userid'])){
            $map['user_id'] = $search['gold_to_ugas_userid'];
        }

        $tab = model('tab')->goldToUgas($page, $limit,$map);
        $count = Db::name('goldtougas')->count('id');

        return $tab ? [
            'code' => 0,
            'msg' => '',
            'data' => $tab,
            'count' => $count,
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '当前没有数据',
            'data' => '',
            'jwt' => $this->jwt,
        ];
    }


    /**
     * 金币兑换ugas状态修改
     */
    public function tougas_type(){
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $data = Request::instance()->param();

        $res  = Db::name('goldtougas')->find($data['id']);
        if ($res==NULL or $res['type']==1 ){
            return [
                'code' => 1,
                'msg' => '修改失败，状态已处理',
                'jwt' => $this->jwt,
            ];
        }
        $res['type'] = 1;
        $bool = Db::name('goldtougas')->update($res);
        if ($bool){
            $gold_upd = -($res['gold']);
            if (Db::name('user')->where('id',$res['userid'])->value('gold') < $res['gold']){
                return [
                    'code' => 1,
                    'msg' => '修改失败，用户金币余额不足',
                    'jwt' => $this->jwt,
                ];
            }
            $this->goldUpdate($gold_upd,4,$res['userid']);
        }

        return [
            'code' => 0,
            'msg' => '保存成功',
            'jwt' => $this->jwt,
        ];
    }

    /**
     *  金币充值
     */
    public function togold($page = 1, $limit =10){
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $search = input('get.');
        $map = [];
        if (!empty($search['ugas_to_gold_userid'])){
            $map['user_id'] = $search['ugas_to_gold_userid'];
        }

        $tab = model('tab')->ugasToGold($page, $limit,$map);
        $count = Db::name('ugas_to_gold')->count('id');

        return $tab ? [
            'code' => 0,
            'msg' => '',
            'data' => $tab,
            'count' => $count,
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '当前没有数据',
            'data' => '',
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 删除申请
     */
    public function togold_del($id)
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $re = Db::name('ugas_to_gold')->delete(['id' => $id]);

        return $re ? [
            'code' => 0,
            'msg' => '删除成功',
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '删除失败',
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 金币充值状态修改
     */
    public function togold_type(){
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $data = Request::instance()->param();

        $res  = Db::name('ugas_to_gold')->find($data['id']);
        if ($res==NULL or $res['type']==1 ){
            return [
                'code' => 1,
                'msg' => '修改失败，状态已处理',
                'jwt' => $this->jwt,
            ];
        }

        return [
            'code' => 0,
            'msg' => '保存成功',
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 用户金币修改
     */
    protected function goldUpdate($gold_upd,$type,$user_id){
        $res = model('index')->updUserGold($user_id,$gold_upd,$type);
        return $res;
    }




    /**
     * 获取角色表格
     */
    public function sys_role_tab()
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $tab = Db::name('role')->field(['id', 'name', 'lvl'])->select();

        return $tab ? [
            'code' => 0,
            'msg' => '',
            'jwt' => $this->jwt,
            'data' => $tab,
        ] : [
            'code' => 1,
            'msg' => '暂时没有数据',
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 添加角色
     */
    public function sys_role_add($name, $lvl)
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $menu = model('role')->menu($lvl);
        if ($menu) {
            $re = Db::name('role')->insert(['name' => $name, 'lvl' => $lvl, 'menu' => $menu]);
        }

        return $re ? [
            'code' => 0,
            'msg' => '添加成功',
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '添加失败',
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 删除角色
     */
    public function sys_role_del($id)
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $re = Db::name('role')->delete(['id' => $id]);

        return $re ? [
            'code' => 0,
            'msg' => '删除成功',
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '删除失败',
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 角色信息
     */
    public function sys_role_info($id)
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $lvl = Db::name('role')->field('lvl')->where('id', $id)->value('lvl');

        return $lvl ? [
            'code' => 0,
            'data' => [
                'lvl' => $lvl,
            ],
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '角色[${name}]不存在',
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 修改角色
     */
    public function sys_role_update($id)
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $data = [
            'name' => Request::instance()->param('name'),
            'menu' => model('role')->menu(Request::instance()->param('lvl')),
            'lvl' => Request::instance()->param('lvl'),
        ];
        $re = Db::name('role')->where('id', $id)->update($data);

        return $re ? [
            'code' => 0,
            'msg' => '修改成功',
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '修改失败',
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 管理员列表
     */
    public function sys_admin_tab()
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $sql = 'SELECT a.`id`, a.`username`, a.`city`, b.`name`, b.`lvl` FROM `admin` AS a INNER JOIN `role` AS b ON a.role = b.id';
        $tab = Db::query($sql);

        if ($tab) {
            $city = model('city');
            foreach ($tab as $k => $item) {
                if ($item['city'] === 'all') {
                    $tab[$k]['city'] = '全国';
                } else {
                    $arr = explode(',', $item['city']);
                    $tab[$k]['city'] = $city->id_name($arr[0]) . ' ' . $city->id_name($arr[1]);
                }
            }
        }

        return $tab ? [
            'code' => 0,
            'data' => $tab,
            'msg' => '',
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'data' => '',
            'msg' => '暂时没有管理员',
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 获取角色
     */
    public function sys_admin_role()
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $role = Db::name('role')->field('id,name')->where('id', '>', 1)->select();

        return $role ? [
            'code' => 0,
            'data' => [
                'role' => $role,
            ],
            'msg' => '',
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'data' => '',
            'msg' => '暂时没有角色',
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 获取城市
     */
    public function getcity($pid)
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $citys = Db::name('citys')->field('id,name')->where('pid', $pid)->select();

        return $citys ? [
            'code' => 0,
            'data' => $citys,
            'msg' => '',
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'data' => '',
            'msg' => '没有下级城市',
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 新增管理员
     */
    public function sys_admin_add()
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $rep = Db::name('admin')->where('username', Request::instance()->param('username'))->find();
        if ($rep) {
            return [
                'code' => 1,
                'msg' => '管理员账号已存在',
                'jwt' => $this->jwt,
            ];
        }

        $data = [
            'username' => Request::instance()->param('username'),
            'pwd' => hash_hmac('md5', Request::instance()->param('pwd'), config('user.key')),
            'role' => Request::instance()->param('role'),
            'city' => Request::instance()->param('city1') . ',' . Request::instance()->param('city2'),
        ];

        $re = Db::name('admin')->insert($data);

        if ($re) {
            $num = Db::table('open_city')->where('id','eq',Request::instance()->param('city2'))->count('id');
            if($num){
                try{
                    Db::table('open_city')->where('id','eq',Request::instance()->param('city2'))->setField('show',1);
                }catch(\Exception $e){
                    return [
                        'code' => 2,
                        'msg' => '发生未知错误，城市未能开通',
                        'jwt' => $this->jwt,
                    ];
                }
            }else{
                try {
                    Db::name('open_city')->insert([
                        'id' => Request::instance()->param('city2'),
                        'name' => model('city')->id_name(Request::instance()->param('city2')),
                        'pid' => Request::instance()->param('city1'),
                    ]);
                } catch (\Exception $e) {
                    if (stripos($e->getMessage(), 'Duplicate entry') !== false) {
                        trace('open_city表重复插入主键，直接忽略', 'DB');
                    }
                }
            }

        }

        return $re ? [
            'code' => 0,
            'msg' => '添加成功',
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '添加失败',
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 删除管理员
     */
    public function sys_admin_del($id)
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        // 隐藏没有管理员的城市
        $user_city = Db::name('admin')->field('city')->where('id', $id)->value('city');
        $cid = explode(',', $user_city);
        $find = Db::name('admin')->field('city')->whereLike('city', '%,' . $cid[1])->find();
        if ($find) {
            Db::name('open_city')->where('id', $cid[1])->update(['show' => 0]);
        }

        // 删除管理员
        $re = Db::name('admin')->delete(['id' => $id]);

        return $re ? [
            'code' => 0,
            'msg' => '删除成功',
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '删除失败',
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 管理员信息
     */
    public function sys_admin_info($id)
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $user = Db::name('admin')->field('role,city')->where('id', $id)->find();

        if (!$user) {
            return [
                'code' => 1,
                'msg' => '管理员${name}不存在',
                'jwt' => $this->jwt,
            ];
        }

        $city = model('city');
        $this_city = explode(',', $user['city']);
        $data = (object) [
            'info' => (object) [
                'city' => $this_city,
            ],
        ];

        if ((int) $id === 1) {
            $data->city = '全国';
        } else {
            $data->city = (object) [
                'pro' => $city->id_select(0),
                'city' => $city->id_select($this_city[0]),
            ];
            $data->info->role = $user['role'];
        }

        $data->role = Db::name('role')->field('id,name')->where('id', '>', 1)->select();

        return $data ? [
            'code' => 0,
            'data' => $data,
            'jwt' => $this->jwt,
        ] : null;
    }

    /**
     * 修改管理员
     */
    public function sys_admin_update($id, $old, $username)
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        Db::startTrans();
        $user = Db::name('admin')->field('id,city')->where('username', $username)->find();
        if ($old !== $username) {
            if ($user) {
                return [
                    'code' => 2,
                    'msg' => '账号' . $username . '已存在',
                    'jwt' => $this->jwt,
                ];
            }
        }

        // 隐藏没有管理员的城市
        $city = explode(',', $user['city']);
        $find = Db::name('admin')->field('city')->whereLike('city', '%,' . $city[1])->find();
        if ($find) {
            Db::name('open_city')->where('id', $city[1])->update(['show' => 0]);
        }

        try {
            $re = Db::name('admin')->where('id', $id)->update([
                'username' => $username,
                'role' => Request::instance()->param('role'),
                'city' => Request::instance()->param('city1') . ',' . Request::instance()->param('city2'),
            ]);
        } catch (\Exception $e) {
            Db::rollback();
            return [
                'code' => 2,
                'msg' => '修改失败',
                'jwt' => $this->jwt,
            ];
        }

        try {
            Db::name('open_city')->insert([
                'id' => Request::instance()->param('city2'),
                'name' => model('city')->id_name(Request::instance()->param('city2')),
                'pid' => Request::instance()->param('city1'),
            ]);
        } catch (\Exception $e) {
            if (stripos($e->getMessage(), 'Duplicate entry') !== false) {
                trace('open_city表重复插入主键，直接忽略', 'DB');
            } else {
                Db::rollback();
                return [
                    'code' => 2,
                    'msg' => '发生未知错误'
                ];
            }
        }

        try {
            Db::table('open_city')->where('id', Request::instance()->param('city2'))->setField('show', 1);
        } catch (\Exception $e) {
            Db::rollback();
            return [
                'code' => 2,
                'msg' => '发生未知错误'
            ];
        }

        Db::commit();

        return ($re !== 0) ? [
            'code' => 0,
            'msg' => '修改成功',
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '未做修改',
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 城市设置表格
     */
    public function sys_city_tab($page,$limit)
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $tab = Db::name('open_city')->page($page,$limit)->select();

        return $tab ? [
            'code' => 0,
            'msg' => 0,
            'data' => $tab,
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '暂时没有开通城市',
            'jwt' => $this->jwt,
        ];
    }

    /**
     * 城市设置edit事件
     */
    public function sys_city_edit()
    {
        if($rejwt = Hook::listen('action_begin',$this->jwt)[0]){
            return $rejwt;
        }

        $id = Request::instance()->param('id');
        $data = Request::instance()->except('id');

        $re = Db::name('open_city')->where('id', $id)->update($data);

        return $re ? [
            'code' => 0,
            'msg' => '已保存',
            'jwt' => $this->jwt,
        ] : [
            'code' => 1,
            'msg' => '保存失败',
            'jwt' => $this->jwt,
        ];
    }


    /**
     * 获取省辖行政区划
     */
    public function city($pid)
    {
        $city = Db::name('citys')->where('pid', $pid)->select();
        return $city ? [
            'code' => 0,
            'data' => $city,
        ] : [
            'code' => 1,
            'msg' => '没有下级行政区',
        ];
    }


    //发送验证码
    public function sendcode(){
        header('Access-Control-Allow-Origin:*');
        $configphone = Db::name('config')->where('key','phone')->find();
        $phone = $configphone['value'];
        if (!is_numeric($phone) || !preg_match("/^1[345789]{1}\d{9}$/",$phone)){
            $re = [
                'msg'=>'请输入正确的手机号',
                'code'=>0,
            ];
            return $re;
        }
        $code = rand(100001,999999);
        $result = send_sms($phone,['code'=>$code]);
        if ($result['Message'] == 'OK'){
            Cache::set($phone.'send_code',$code);
            $re = [
                'msg'=>'发送成功',
                'code'=>1,
            ];

            return $re;
        }else{
            $re = [
                'msg'=>'发送错误',
                'code'=>0,
            ];

            return $re;
        }
    }

    //验证码校验
    public function verificationcode(){
        header('Access-Control-Allow-Origin:*');
        $params  = Request::instance()->param();
        $configphone = Db::name('config')->where('key','phone')->find();
        $phone = $configphone['value'];
        $code = Cache::get($phone.'send_code');
        if (!is_numeric($params['code'])){
            $re = [
                'msg'=>'验证码错误',
                'code'=>0,
            ];
            return $re;
        }
        if ($code != trim($params['code'])){
            $re = [
                'msg'=>'验证码错误',
                'code'=>0,
            ];
            return $re;
        }
        $re = [
            'msg'=>'验证成功',
            'code'=>1
        ];
        return $re;
    }

    /**
     *  app金币兑换ugas
     */
    public function goldToUgasList(){
        header('Access-Control-Allow-Origin:*');
        $tab = Db::name('goldtougas')->where(['type'=>0])->select();
        $sum = Db::name('goldtougas')->field('SUM(ugas) as ugas')->where(['type'=>0])->select();
        $count = Db::name('goldtougas')->count('id');

        return $tab ? [
            'code' => 1,
            'msg' => '',
            'data' => $tab,
            'sum' => $sum,
            'count' => $count,
        ] : [
            'code' => 0,
            'msg' => '当前没有数据',
            'sum' => 0,
            'data' => '',
        ];
    }

    /**
     * 金币兑换验证
     */
    public function goldToUgasVerify(){
        header('Access-Control-Allow-Origin:*');
        $data = Request::instance()->param();

        foreach ($data['id'] as $key=>$val){
            $res[$key]  = Db::name('goldtougas')->where(['type'=>0])->find($val);
            if ($res[$key] == NULL or $res[$key]['type']==1){
                return [
                    'code' => 0,
                    'msg' => '没有找到匹配记录id'.$res[$key]['id'],
                ];
            }
        }
        //插入商户号
        foreach ($res as $val){
            $val['bizid'] = $data['bizid'];
            Db::name('goldtougas')->update($val);
        }

        return [
            'code' => 1,
            'msg' => 'success',
        ];
    }


    /**
     * app金币兑换ugas状态修改
     */
    public function goldToUgasType(){
        header('Access-Control-Allow-Origin:*');
        $data = Request::instance()->param();

        Db::name('goldtougas')->where(['bizid'=>$data['bizid']])->update(['type'=>1]);

        return [
            'code' => 1,
            'msg' => '操作成功',
        ];
    }
}
