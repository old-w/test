<?php

namespace app\api\controller;

use think\Controller;
use vikit\img;
use think\Request;

class Test extends Controller
{
    public function index()
    {
        // $name = hash_hmac('sha256',time().mt_rand(1000,99999),md5(time())).'.png';
        $file = Request::instance()->file('pic');
        $crop = json_decode(Request::instance()->param('crop'));
        $img = (new img($file))->crop($crop->w,$crop->h,$crop->x,$crop->y,200,200);
        $img->show();
    }

    public function api(){
        return json(Request::instance()->getInput());
    }
}
