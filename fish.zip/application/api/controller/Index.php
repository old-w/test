<?php

namespace app\api\controller;

use think\Cache;
use think\Cookie;
use think\Db;
use think\Log;
use think\Request;
use app\common\exception\BaseException;
use think\Session;


class Index extends Controller
{
    protected $user;
    /**
     * 基类初始化
     * @throws BaseException
     */
    public function _initialize()
    {
        header('Access-Control-Allow-Origin:*');

        if (!Request::instance()->param('token')){
            throw new BaseException(['msg' => '登录信息失效，请重新登录', 'code' => -2]);
        }
        $token = Request::instance()->param('token');

        $user = Db::name('user')->where(['token'=>$token])->find();
        if (!$user){
            throw new BaseException(['msg' => '登录信息失效，请重新登录', 'code' => -2]);
        }

        $this->user = $user;

    }

    /**
     * 获取用户信息
     * @return array
     */
    public function getUser(){
        header('Access-Control-Allow-Origin:*');
        $user = $this->user;
        return $this->renderSuccess(compact('user'));
    }

    /**
     * 获取鱼类信息
     * @return array
     */
    public function getFish(){
        header('Access-Control-Allow-Origin:*');
        $fish = model('form')->fish();
        return $this->renderSuccess(compact('fish'));
    }
    /**
     * 获取所有鱼饵数据
     * @return array
     */
    public function getBait(){
        header('Access-Control-Allow-Origin:*');
        $bait = model('form')->bait();

        return $this->renderSuccess(compact('bait'));
    }

    /**
     * 获取该用户所拥有的鱼及数量
     * @return array
     */
    public function getUserFish(){
        header('Access-Control-Allow-Origin:*');
        $fish = model('form')->userFish($this->user['id']);
        $sum = 0;
        if ($fish!=[]){
            foreach ($fish as $key => $val){
                $fish[$key]['total_price'] = $val['gold']*$val['amount'];
                $sum += $fish[$key]['total_price'];
            }
        }
        return $this->renderSuccess(compact('fish','sum'));
    }

    /**
     * 获取该用户所拥有的鱼饵数量
     * @return array
     */
    public function getUserBait(){
        header('Access-Control-Allow-Origin:*');
        $bait = model('form')->userBait($this->user['id']);
        return $this->renderSuccess(compact('bait'));
    }

    /**
     * 鱼饵购买
     * data中code为1表示购买成功，0为失败
     * 外层code为-1时返回报错条件
     */
    public function buyBait(){
        header('Access-Control-Allow-Origin:*');
        $res = Request::instance()->param();
//        $res = [
//            'bait_id' => 2,
//            'number' => 2
//        ];
        $filter = ['bait_id','number'];
        $data = $this->filterArray($res,$filter);
        $bait = Db::name('bait')->find(['id'=>$res['bait_id']]);
        $this->judgeGold($bait['gold'],$res['number']);

        if ($tab =Db::name('user_bait')->where(['user_id'=>$this->user['id'],'bait_id'=>$data['bait_id']])->find()){
            $amount = $tab['amount'] + $data['number'];
            Db::name('user_bait')->where(['user_id'=>$this->user['id'],'bait_id'=>$data['bait_id']])->update(['amount'=>$amount]);
        }else{
            $insert = [
                'user_id'=>$this->user['id'],
                'bait_id'=>$data['bait_id'],
                'amount'=>$data['number']
            ];

            Db::name('user_bait')->insert($insert);
        }
        $gold_upd = -($bait['gold']*$res['number']);
        $bool = $this->goldUpdate($gold_upd,2);
        $code = $bool;
        $bait = model('form')->userBait($this->user['id']);
        $gold = Db::name('user')->where('id',$this->user['id'])->value('gold');
        return $this->renderSuccess(compact('code','bait','gold'));
    }

    /**
     * 判断金币是否足够
     */
    public function judgeGold($gold,$amount){

        $res = model('form')->getUser($this->user['id']);
        $sum = $gold*$amount;
        if ($sum > $res['gold']){
            throw new BaseException(['msg' => '金币余额不足', 'code' => -1]);
        }
    }

    /**
     * 单个鱼种贩卖
     * data中code为1表示贩卖成功，0为失败
     * 外层code为-1时返回报错条件
     */
    public function fishSell(){
        header('Access-Control-Allow-Origin:*');
        $res = Request::instance()->param();
        $this->judgeFish($res['fish_id'],1);
        $gold_upd = 0;
        $time = date('Y-m-d H-i-s',time());
        Db::name('user_fish')
            ->where(['user_id'=>$this->user['id'],'fish_id'=>$res['fish_id'],'is_sell'=>0])
            ->limit(1)
            ->update(['is_sell'=>1,'sell_time'=>$time]);
        $tab = Db::name('fish')->find(['id'=>$res['fish_id']]);
        $gold_upd += $tab['gold'];
        $bool = $this->goldUpdate($gold_upd,3);
        $code = $bool;
        $fish = model('form')->userFish($this->user['id']);
        $sum = 0;
        if ($fish!=[]){
            foreach ($fish as $key => $val){
                $fish[$key]['total_price'] = $val['gold']*$val['amount'];
                $sum += $fish[$key]['total_price'];
            }
        }
        $gold = Db::name('user')->where('id',$this->user['id'])->value('gold');
        return $this->renderSuccess(compact('code','fish','sum','gold'));
    }

    /**
     * 一键贩卖
     * data中code为1表示贩卖成功，0为失败
     * 外层code为-1时返回报错条件
     */
    public function fishSellAll(){
        header('Access-Control-Allow-Origin:*');
        $res = Db::name('user_fish')
            ->alias('a')
            ->field('count(a.fish_id) as number,b.id as fish_id')
            ->where('a.user_id',$this->user['id'])
            ->where('a.is_sell','=',0)
            ->group('a.fish_id')
            ->join('fish b','a.fish_id=b.id')
            ->order('b.gold')
            ->select();
        $gold_upd = 0;
        $time = date('Y-m-d H-i-s',time());
        foreach ($res as $val){
            Db::name('user_fish')
                ->where(['user_id'=>$this->user['id'],'fish_id'=>$val['fish_id'],'is_sell'=>0])
                ->limit($val['number'])
                ->update(['is_sell'=>1,'sell_time'=>$time]);
            $tab = Db::name('fish')->find(['id'=>$val['fish_id']]);
            $gold_upd += $tab['gold']*$val['number'];
        }
        $bool = $this->goldUpdate($gold_upd,3);
        $code = $bool;
        $fish = model('form')->userFish($this->user['id']);
        $sum = 0;
        if ($fish!=[]){
            foreach ($fish as $key => $val){
                $fish[$key]['total_price'] = $val['gold']*$val['amount'];
                $sum += $fish[$key]['total_price'];
            }
        }
        $gold = Db::name('user')->where('id',$this->user['id'])->value('gold');
        return $this->renderSuccess(compact('code','fish','sum','gold'));
    }

    /**
     * 判断鱼的数量是否足够
     * @param $fish_id
     * @param $number
     * @throws BaseException
     */
    public function judgeFish($fish_id , $number){

        $count = Db::name('user_fish')->where(['user_id'=>$this->user['id'],'fish_id'=>$fish_id,'is_sell'=>0])->count();
        if ($count < $number || $count==0){
            throw new BaseException(['msg' => '仓库鱼的数量不足', 'code' => -1]);
        }
    }

    /**
     * 用户金币修改
     */
    protected function goldUpdate($gold_upd,$type){
        $res = model('index')->updUserGold($this->user['id'],$gold_upd,$type);
        return $res;
    }

    /**
     * 用户ugas修改
     */
    protected function ugasUpdate($ugas_upd,$type){
        $res = model('index')->updUserUgas($this->user['id'],$ugas_upd,$type);
        return $res;
    }

    /**
     * 随机组队
     */
    public function formRandomTeam(){
        $data = [
            'user_id' => $this->user['id'],
            'current_time' => date('Y-m-d H-i-s',time())
        ];
        $code = model('index')->formRandomTeam($data);
        return $this->renderSuccess(compact('code'));
    }

    /**
     * 队伍分配
     * {"code":1,"msg":"success","data":{"team_id":"2"}}
     */
    public function setupRandomTeam(){
        $count = Db::name('random_team')->where('team_id','null')->whereTime('current_time','-100 seconds')->count();
//        $res = Db::name('fishhook')->where('level','neq',9)->where('number','elt',$count)->order('level desc')->limit(1)->find();
        if ($count == 0){
            throw new BaseException(['msg' => '队伍组建失败', 'code' => -1]);
        }
        if ($count>5){
            $count = 5;
        }
        $team_id = Db::name('team')->insertGetId(['number'=>$count]);

        Db::name('random_team')
            ->where(['user_id'=>$this->user['id']])
            ->where('team_id','null')
            ->whereTime('current_time','-100 seconds')
            ->update(['team_id'=>$team_id]);
        $number = --$count;
        if ($number!=0){
            Db::name('random_team')
                ->limit($number)
                ->where('team_id','null')
                ->order('current_time asc')
                ->whereTime('current_time','-100 seconds')
                ->update(['team_id'=>$team_id]);
        }
        return $this->renderSuccess(compact('team_id'));
    }

    /**
     * 队伍所拥有的用户
     */
    public function teamUser(){
        $res = Request::instance()->param();
        $tab = Db::name('random_team')
            ->alias('a')
            ->field('b.id,b.headimgurl')
            ->where(['a.team_id'=>$res['team_id']])
            ->join('user b','a.user_id=b.id')
            ->select();
        $tab = $tab ? $tab : [];
        return $this->renderSuccess(compact('tab'));
    }

    /**
     * 钓鱼概率计算
     */
    public function fishing(){
        header('Access-Control-Allow-Origin:*');
        $res = Request::instance()->param();

        $user_bait = Db::name('user_bait')
            ->where(['user_id'=>$this->user['id'],'bait_id'=>$res['bait_id']])
            ->where('amount','>',0)->find();
        if (!$user_bait){
            throw new BaseException([ 'code' => -1,'msg' => '该鱼饵数量不足']);
        }
        if ($res['type'] == 0){
            $code = 0;
            $msg = '好可惜，鱼儿溜走了。。。';
            $gold = 0;
            $bait = model('form')->userBait($this->user['id']);
            $user_bait['amount']--;
            Db::name('user_bait')
                ->where(['user_id'=>$this->user['id'],'bait_id'=>$res['bait_id']])->update($user_bait);
            return $this->renderSuccess(compact('code','msg','gold','bait'));
        }
//        $random_team = Db::name('random_team')
//            ->where(['user_id'=>$this->user['id'],'team_id'=>$res['team_id'],'is_fishing'=>0])->find();
//        if (!$random_team){
//            throw new BaseException([ 'code' => -1,'msg' => '还未加入队伍或已钓完鱼']);
//        }

//        $number = Db::name('team')->where(['id'=>$res['team_id']])->value('number');
        $number = $res['number'];
        $user = model('form')->getUser($this->user['id']);
        $fishhook_probability = Db::name('fishhook')->where(['level'=>$user['fishhook_id']])->value('probability');
        $team_coefficient = Db::name('team_coefficient')->where('number',$number)->value('probability');
        $fish_bait = Db::name('fish_bait')->order('probability desc')->where('bait_id',$res['bait_id'])->select();

        $fish_probability = [];
        $i = 1;
        $sum = 0;
        foreach ($fish_bait as $val){
            $fish_probability[$i] =[
                'fish_id'=>$val['fish_id'],
                'probability'=>round($val['probability']*$fishhook_probability*$team_coefficient,7)*10000000
            ];
            $sum += $val['probability'];
            $i++;
        }
        if ($sum<1){        //判断是否会上鱼
            $fish_probability[0]=[
                'fish_id'=>0,
                'probability'=>(1-$sum)*10000000
            ];
            $num = mt_rand(1,10000000);
            $index = 0;
            $add = 0;
            foreach ($fish_probability as $key=>$val){
                $add += $val['probability'];
                if ($num<$add){
                    $index = $key;
                    break;
                }
            }
        }else{
            $num = mt_rand(1,$sum*10000000);
            $index = 0;
            $add = 0;
            foreach ($fish_probability as $key=>$val){
                $add += $val['probability'];
                if ($num<$add){
                    $index = $key;
                    break;
                }
            }
        }
        $fish_id = $fish_probability[$index]['fish_id'];
        if ($fish_id == 0){
//            Db::name('random_team')
//                ->where(['user_id'=>$this->user['id'],'team_id'=>$res['team_id']])->update(['is_fishing'=>1]);
            $code = 0;
            $msg = '好可惜，鱼儿溜走了。。。';
            $gold = 0;
            $user_bait['amount']--;
            Db::name('user_bait')
                ->where(['user_id'=>$this->user['id'],'bait_id'=>$res['bait_id']])->update($user_bait);
        }else{
//            Db::name('random_team')
//                ->where(['user_id'=>$this->user['id'],'team_id'=>$res['team_id']])->update(['is_fishing'=>1]);
            $user_bait['amount']--;
            Db::name('user_bait')
                ->where(['user_id'=>$this->user['id'],'bait_id'=>$res['bait_id']])->update($user_bait);
            $data = [
                'user_id' => $this->user['id'],
                'fish_id' => $fish_id,
                'is_sell' => 0,
                'create_time' => date('Y-m-d H-i-s',time())
            ];
            $back = Db::name('user_fish')->insert($data);
            if ($back){
                $fish = Db::name('fish')->where(['id'=>$fish_id])->find();
            }
            $code = 1;
            $msg = '恭喜你钓到了'.$fish['name'].'!';
            $gold = $fish['gold'];
            $img_url = $fish['img_url_2'];
        }
        $bait = model('form')->userBait($this->user['id']);
        return $this->renderSuccess(compact('code','msg','gold','img_url','bait','fish_id'));

    }

    /**
     * 鱼钩界面信息获取
     */
    public function fishhook(){
        header('Access-Control-Allow-Origin:*');
        $res = Db::name('fishhook')->select();
        $user = model('form')->getUser($this->user['id']);
        if ($user['invite_id']==NULL){
            $number = 0;
        }else{
            $arr_number = explode(",",$user['invite_id']);
            $number = count($arr_number);
        }

        $have = Db::name('user_fishhook')->where(['user_id'=>$this->user['id']])->column('fishhook_id');
        $data = [];
        $i = 0;
        foreach ($res as $value){
            if (in_array($value['level'],$have)) {
                $data[$i] = $value;
                if ($user['fishhook_id']==$value['level']){     //使用中
                    $data[$i]['status'] = 2;
                }else{
                    $data[$i]['status'] = 1;        //已拥有
                }
                $i++;
                continue;
            }
            if ($value['is_show']==1){
                $data[$i] = $value;
                $data[$i]['status'] = 0;        //未拥有
                $i++;
                continue;
            }
        }
        return $this->renderSuccess(compact('data','number'));
    }

    /**
     * 选择使用何种鱼钩
     */
    public function chooseFishhook(){
        header('Access-Control-Allow-Origin:*');
        $res = Request::instance()->param();
        if (!Db::name('user_fishhook')->where(['fishhook_id'=>$res['fishhook_id']])->find()){
            throw new BaseException(['msg' => '您还未拥有该鱼饵', 'code' => -1]);
        }else{
            $code = Db::name('user')->where(['id'=>$this->user['id']])->update(['fishhook_id'=>$res['fishhook_id']]);
        }
        return $this->renderSuccess(compact('code'));
    }


    /**
     * 金币guas兑换列表
     */
    public function goldUgasList(){
        header('Access-Control-Allow-Origin:*');
        $tab = Db::name('gold_ugas')->order('ugas desc')->select();
        $proportion = Db::name('config')->where('key','eq','proportion')->value('value');
        $proportion = $proportion ? $proportion:10;
        foreach ($tab as $key=>$val){
            $tab[$key]['gold'] = $proportion*$val['ugas'];
        }
        return $this->renderSuccess(compact('tab'));
    }

    /**
     * 获得比例接口
     */
    public function getProportion(){
        header('Access-Control-Allow-Origin:*');
        $proportion = Db::name('config')->where('key','eq','proportion')->value('value');
        return $this->renderSuccess(compact('proportion'));
    }


    /**
     *  ugas转金币页面
     */
    public function ugasToGoldList(){
        header('Access-Control-Allow-Origin:*');
        $data = [
          'user_id' =>  $this->user['id'],
          'note_yards' =>  $this->user['id'].time(),
          'create_time' =>  date('Y-m-d H-i-s',time()),
        ];
        $res = Db::name('ugas_to_gold')->insert($data);
        if ($res == NULL){
            throw new BaseException(['msg' => '错误', 'code' => -1]);
        }
        $tab = $data;
        $tab['to_address'] = Db::name('config')->where('key','eq','to_address')->value('value');
        $tab['qrcode'] = Db::name('config')->where('key','eq','qrcode')->value('value');
        $tab['proportion'] = Db::name('config')->where('key','eq','proportion')->value('value');
        return $this->renderSuccess(compact('tab'));
    }


    /**
     * 轮询获取金币接口
     */
    public function getGold(){
        $res = Db::name('user')->where(['id'=>$this->user['id'],'gold_update'=>1])->find();

        if ($res) {
            $gold = $res['gold'];
            Db::name('user')->where(['id'=>$this->user['id']])->update(['gold_update'=>0]);
            return $this->renderSuccess(compact('gold'));
        }
        exit();
    }


    /**
     * 过滤数组
     * @param $data
     * @param $filter
     * @return array
     */
    public function filterArray($data,$filter){
        $res = [];
        foreach ($filter as $value){
            if (isset($data[$value])){
                $res[$value] = $data[$value];
            }
        }
        return $res;
    }

    /**
     * 金币兑换ugas
     */
    public function userwalletad(){
        header('Access-Control-Allow-Origin:*');
        $params = Request::instance()->param();
        $address = $params['address'];
        $phone = $params['phone'];
        $code = $params['code'];
        $userid = $this->user['id'];
        $goldid = $params['goldid'];
        $user = Db::name('user')->where('id',$userid)->find();
        if (!is_numeric($params['phone']) || !preg_match("/^1[345789]{1}\d{9}$/",$params['phone'])){
            throw new BaseException(['msg' => '请输入正确的手机号', 'code' => -1]);

        }
        if($user['phone'] != $phone){
            throw new BaseException(['msg' => '输入手机号与绑定手机号不一致', 'code' => -1]);
        }
        if (!is_numeric($params['code'])){
            throw new BaseException(['msg' => '验证码错误', 'code' => -1]);

        }
        $code = Cache::get($phone.'_code');
        if ($code != trim($params['code'])){
            throw new BaseException(['msg' => '验证码错误', 'code' => -1]);

        }
        $ishave = Db::name('user')->where('phone',$phone)->find();
        if($ishave){
            $gold = Db::name('gold_ugas')->where('id',$goldid)->find();
            $config = Db::name('config')->where('key','proportion')->find();
            $goldnum = $gold['ugas']*$config['value'];
//            $where = 'userid='.$userid.' AND type=0';
            //$allgold = Db::name('goldtougas')->where($where)->select();
            //$golds = $goldnum;

            // if($allgold){
            //     foreach($allgold as $k=>$v){
            //       $golds = $golds+$v['gold'];
            //     }
            // }

            if($goldnum>$user['gold']){
                throw new BaseException(['msg' => '金币余额不足', 'code' => -1]);
            }
            $data = array(
                'phone'=>$phone,
                'wallet_address'=>$address,
                'userid'=>$userid,
                'gold'=>$goldnum,
                'ugas'=>$gold['ugas'],
                'create_time'=>date('Y-m-d H-i-s',time())
            );
            $resout = Db::name('goldtougas')->insert($data);
            if($resout){
                $msg  ='申请成功';
                $code = 1;
                $goldnum =  -($goldnum);
                $res=$this->goldUpdate($goldnum,4);
                $user = Db::name('user')->where('id',$userid)->find();
                $goldnow = $user['gold'];
                return $this->renderSuccess(compact('code','msg','goldnow'));
                // return ServerResponse::createBySuccess('申请成功');
            }else{
                throw new BaseException(['msg' => '申请失败', 'code' => -1]);
            }
        }else{
            throw new BaseException(['msg' => '手机号码未注册', 'code' => -1]);

        }

    }

    //充值 app唤起
    public function ugas_to_gold_forapp(){
        header('Access-Control-Allow-Origin:*');
        $res = Request::instance()->param();

        $ugas =$res['ugas'];
        $uid = $this->user['id'];
        $bizid = $res['bizid'];
        $gold = $res['gold'];

        //$proportion = Db::name('config')->where('key','eq','proportion')->value('value');
        //$gold_upd = $proportion * $gold_ugas['ugas'];
        $data = array(
            'user_id'=>$uid,
            'create_time'=>date('Y-m-d H-i-s',time()),
            'type'=>1,
            'ugas'=>$ugas,
            'gold'=>$gold,
            'bizid'=>$bizid
        );
        $resout = Db::name('ugas_to_gold')->insert($data);
        if($resout){
            $ress=$this->goldUpdate($gold,1);
            $user = Db::name('user')->where('id',$uid)->find();
            $msg  ='充值成功';
            $code = 1;
            $gold = $user['gold'];
            //$res=$this->goldUpdate('-'.$goldnum,4);
            return $this->renderSuccess(compact('code','msg','gold'));
        }else{
            throw new BaseException(['msg' => '充值失败', 'code' => -1]);
        }
    }
}
