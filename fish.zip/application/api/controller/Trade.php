<?php
/**
 * author xtj
 * createtime 2019/7/15 0015 上午 9:39
 * return array obj json bool
 * param
 */
namespace app\api\controller;

use think\Request;
use think\Db;
use think\Session;

class Trade extends Controller
{
    //唤起转账，交易成功后调用这个接口将数据写入数据库
    public function tradeSuccess(Request $request){

    }
    public function getAccountTrade(){
        $array = [
            'page'=> 1,
            'pageSize'=> 20,
            'queryParams' => array('account_name'=>'haiyang333'),
            'sortParams' => array('_id'=>-1)
        ];
        $url = "http://ultrain-history.natapp1.cc/actions/by/account";
        $result = self::send_post($url,$array);
        $get_data = json_decode($result,true);
        if (!empty($get_data)){
            //如果拿到的交易总数不等于上次拿到的，说明有新交易产生
            $tradeCount = Session::get('tradeCount');
            if ($get_data['total'] != $tradeCount && $get_data['total'] > 0){
                Session::set('tradeCount',$get_data['total']);
                $tradeHistory = $get_data['results'];
                //拿到当天的交易数据
                $todayBegin = date("Y-m-d H:i:s", mktime(0, 0, 0, date('m'), date('d'), date('Y')));
                $todayEnd = date("Y-m-d H:i:s", mktime(0, 0, 0, date('m'), date('d')+1, date('Y'))-1);
                $data = array();
                foreach ($tradeHistory as $key=>$value){
                    $tradeHistoryCreate = date("Y-m-d H:i:s",strtotime($value['createdAt']));
                    if ($tradeHistoryCreate > $todayBegin  &&  $tradeHistoryCreate < $todayEnd){
                        $data[$key] = $value['data'];
                    }
                }
                //处理备注码为字符串的数据
                foreach ($data as $k=>$item){
                    $data[$k]['quantity'] = strstr($item['quantity'],' UGAS',true);
                    if ($item['memo'] == 'test' || preg_match('/[\x{4e00}-\x{9fa5}]/u', $item['memo'])>0){
                        unset($data[$k]);
                    }
                    $is_ok = db('ugas_to_gold')->where('note_yards',$item['memo'])->value('is_ok');
                    if ($is_ok == 1){
                        unset($data[$k]);
                    }
                }
                if (empty($data)){
                    die;
                }
                //将用户充值金币
                $userData = array();          //user表变动数据
                $goldLog = array();             //金币日志数据
                $ugasToGold = array();          //ugas_to_gold表变动数据
                Db::startTrans();
                try{
                    foreach ($data as $i=>$v){
                        $data[$i]['user_id'] = Db::name('ugas_to_gold')->where('note_yards',$v['memo'])->value('user_id');
                        $data[$i]['gold'] = Db::name('user')->where('id',$data[$i]['user_id'])->value('gold');          //已有金币
                        $userData[$i]['gold'] = $data[$i]['gold'] + $v['quantity'] * 10;            //已有金币加上充值金币
                        $userRes = Db::name('user')->where('id',$data[$i]['user_id'])->setField('gold',$userData[$i]['gold']);
                        if (!$userRes){
                            throw new \Exception('获取用户账户金币余额失败');
                            Db::rollback();
                        }
                        //金币日志
                        $goldLog['user_id'] = $data[$i]['user_id'];
                        $goldLog['gold_upd'] = $v['quantity'] * 10;
                        $goldLog['type'] = 1;
                        $goldLog['gold_balance'] = $userData[$i]['gold'];
                        $goldLog['create_time'] = date('Y-m-d H:i:s');
                        $goldLogRes = Db::name('gold_log')->insert($goldLog);
                        if (!$goldLogRes){
                            throw new \Exception('金币日志更新失败');
                            Db::rollback();
                        }
                        //ugas_to_gold表变动数据
                        $ugasToGold['ugas'] = $v['quantity'];
                        $ugasToGold['gold'] = $v['quantity'] * 10;
                        $ugasToGold['is_ok'] = 0;
                        if ($userRes) {
                            $ugasToGold['is_ok'] = 1;
                        }
                        $ugasToGold['update_time'] = date('y-m-d H:i:s');
                        $ugasToGoldRes = Db::name('ugas_to_gold')->where('note_yards',$v['memo'])->update($ugasToGold);
                        if (!$ugasToGoldRes){
                            throw new \Exception('修改用户充值操作失败');
                            Db::rollback();
                        }
                    }
                    Db::commit();
                }catch (\Exception $e){
                    Db::rollback();
                }
            }else{
              echo '无新交易记录';
            }
        }else{
            echo '暂无数据';
        }
    }



    function send_post($url,$post_data) {
        $postdata = http_build_query($post_data);
        $options = array(
            'http' => array(
                'method' => 'POST',
                'header' => 'Content-type:application/x-www-form-urlencoded',
                'content' => $postdata,
                'timeout' => 15 * 60 // 超时时间（单位:s）
            )
        );

        $context = stream_context_create($options);
        $result = file_get_contents($url, false, $context);


        return $result;
    }


}
