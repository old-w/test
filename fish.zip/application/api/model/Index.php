<?php

namespace app\api\model;

use think\Db;

/**
 * 前台数据表操作
 * Class Index
 * @package app\api\model
 */
class Index
{
    /**
     * 修改用户金币
     */
    public function updUserGold($user_id, $gold_upd , $type){

        $res = Db::name('user')->find($user_id);
        $res['gold'] = $res['gold'] + $gold_upd;
        $bool = Db::name('user')->update($res);

        $data = [
            'user_id' => $user_id,
            'gold_upd' => $gold_upd,
            'gold_balance' => $res['gold'],
            'type' => $type,
            'create_time' => date('Y-m-d H-i-s',time())
        ];
        Db::name('gold_log')->insert($data);

        return $bool ? 1 : 0;
    }

    /**
     * 修改用户ugas
     */
    public function updUserUgas($user_id, $ugas_upd , $type){

        $res = Db::name('user')->find($user_id);
        $res['ugas'] = $res['ugas'] + $ugas_upd;
        $bool = Db::name('user')->update($res);

        $data = [
            'user_id' => $user_id,
            'ugas_upd' => $ugas_upd,
            'ugas_balance' => $res['ugas'],
            'type' => $type,
            'create_time' => date('Y-m-d H-i-s',time())
        ];
        Db::name('ugas_log')->insert($data);

        return $bool ? 1 : 0;
    }


    /**
     * 用户选择随机组队
     * @param $data
     * @return int
     */
    public function formRandomTeam($data){
        $bool = Db::name('random_team')->insert($data);
        return $bool ? 1 : 0;
    }


}
