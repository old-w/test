<?php

namespace app\api\model;

use think\Db;

/**
 * 后台数据列表
 * Class Tab
 * @package app\api\model
 */
class Tab
{
    //获得用户匹配列表
    public function users($page, $limit,$map = []){
        if (isset($map['id_phone'])){
            $tab = Db::name('user')->order('id desc')->where('id|phone','eq',$map['id_phone'])->page($page, $limit)->select();
        }else{
            $tab = Db::name('user')->order('id desc')->page($page, $limit)->select();
        }
        return $tab ? $tab : false;
    }

    /**
     * 根据user_id获取用户所钓鱼未售卖的各个总数
     */
    public function userFish($page, $limit,$user_id){
        $tab = Db::name('user_fish')
            ->alias('a')
            ->field('a.id,count(a.fish_id) as amount,b.name,b.gold')
            ->where('a.user_id',$user_id)
            ->where('a.is_sell','=',0)
            ->group('a.fish_id')
            ->join('fish b','a.fish_id=b.id')
            ->order('b.gold')
            ->page($page, $limit)
            ->select();
        return $tab ? $tab : false;
    }

    /**
     * 根据user_id获取用户所拥有的鱼饵数量
     */
    public function userBait($page, $limit,$user_id){
        $tab = Db::name('user_bait')
            ->alias('a')
            ->field('a.id,a.amount,b.name,b.gold')
            ->where('a.user_id',$user_id)
            ->where('a.amount','>',0)
            ->group('a.bait_id')
            ->join('bait b','a.bait_id=b.id')
            ->page($page, $limit)
            ->select();
        return $tab ? $tab : false;
    }

    /**
     * 获取所有鱼类
     */
    public function fish($page, $limit){
        $tab = Db::name('fish')->order('gold')->select();
        return $tab ? $tab : false;
    }


    /**
     * 获取所有鱼饵
     */
    public function bait($page, $limit){
        $tab = Db::name('bait')->order('gold')->page($page, $limit)->select();
        return $tab ? $tab : false;
    }

    /**
     * 获取鱼所有对应鱼饵的概率
     */
    public function fish_bait_probability($page, $limit, $fish_id){
        $tab = Db::name('fish_bait')
            ->alias('a')
            ->field('a.id,a.probability,b.name')
            ->where('a.fish_id',$fish_id)
            ->join('bait b','a.bait_id=b.id')
            ->page($page, $limit)
            ->select();
        return $tab ? $tab : false;
    }

    /**
     * 钓鱼日志
     */
    public function fishlog($page, $limit, $map = []){
        $tab = Db::name('user_fish')
            ->alias('a')
            ->field('a.id,a.user_id,a.is_sell,a.create_time,b.name')
            ->order('a.create_time desc')
            ->where($map)
            ->join('fish b','a.fish_id=b.id')
            ->page($page, $limit)
            ->select();

        return $tab ? $tab : false;
    }

    /**
     * 金币日志
     */
    public function goldlog($page, $limit, $map = []){
        $tab = Db::name('gold_log')->where($map)->order('create_time desc')->page($page, $limit)->select();
        return $tab ? $tab : false;
    }

    public function goldToUgas($page, $limit, $map = []){
        $tab = Db::name('goldtougas')->where($map)->order('create_time desc')->page($page, $limit)->select();
        return $tab ? $tab : false;
    }

    public function ugasToGold($page, $limit, $map = []){
        $tab = Db::name('ugas_to_gold')->where($map)->where(['type'=>1])->order('create_time desc')->page($page, $limit)->select();
        return $tab ? $tab : false;
    }
}
