<?php

namespace app\api\model;

use Lcobucci\JWT\Builder;
use think\Model;

class User extends Model
{


    /**
     * 登录
     */
    public function login($username, $pwd)
    {
        $user = db('admin')->where('username', $username)->find();
        if (empty($user)) {
            return [
                'code' => 1,
                'msg' => '账号或密码不正确',
            ];
        }

        if ($user['pwd'] !== hash_hmac('md5', $pwd, config('user.key'))) {
            return [
                'code' => 1,
                'msg' => '账号或密码不正确',
            ];
        }

        $info = model('role')->username($username);
        session('admin.username', $username);
        session('admin.uid', $user['id']);
        return [
            'code' => 0,
            'msg' => '登陆成功',
            'jwt' => $this->jwt($user),
            'data' => [
                'name' => $info['name'],
                'username' => $username,
            ],
        ];
    }

    /**
     * 修改密码
     */
    public function pwd($param, $id, $jwt)
    {
        $pwd = db('admin')->field('pwd')->where('id', $id)->value('pwd');
        $old = hash_hmac('md5', $param['old'], config('user.key'));
        if ($pwd !== $old) {
            return [
                'code' => 1,
                'msg' => '原密码不正确',
                'jwt' => $jwt,
            ];
        }

        $newpwd = hash_hmac('md5', $param['pwd'], config('user.key'));
        $re = db('admin')->where('id', $id)->update(['pwd' => $newpwd]);
        if ($re) {
            return [
                'code' => 0,
                'msg' => '密码修改成功',
                'jwt' => $jwt,
            ];
        }

        return [
            'code' => 2,
            'msg' => '密码修改失败',
            'jwt' => $jwt,
        ];
    }

    private function jwt($user)
    {
        $key = hash_hmac('sha256', $this->sign($user), config('jwt.key'));
        session('admin.token', $key);
        $token = (new Builder)->setIssuer(input('server.SERVER_NAME'))
            ->setAudience(input('server.SERVER_NAME'))
            ->setId($key, true)
            ->setIssuedAt(time())
            ->setExpiration(time() + config('jwt.time'))
            ->set('id', $user['id'])
            ->getToken();
        return (string) $token;
    }

    private function sign($info)
    {
        return $info['id'] . $info['username'] . $info['pwd'];
    }
}
