<?php

namespace app\api\model;

use think\Db;

class Role
{
    public function id($id)
    {
        return Db::name('admin')->field('id,username,pwd')->where('id', $id)->find();
    }

    public function username($username)
    {
        return Db::name('admin')->alias('a')->join(['role' => 'r'], 'a.role = r.id', 'left')->field('name,menu')->where('username', $username)->find();
    }

    public function menu($lvl)
    {
        $role = ['home'];
        $arr = explode(',',$lvl);
        $role = array_merge($role,$arr);
        array_push($role,'user');
        $json = json_decode(file_get_contents('./static/admin/menu.json'));

        $menu = [];
        foreach($role as $item){
            $menu[] = $json->$item;
        }
        return json_encode($menu);
    }
}
