<?php

namespace app\api\model;

use think\Db;

/**
 * 前台数据表
 * Class Form
 * @package app\api\model
 */
class Form
{
    //获得用户匹配列表
    public function users(){
        $tab = Db::name('user')->order('id desc')->select();
        return $tab ? $tab : [];
    }

    public function getUser($id){
        $tab = Db::name('user')->find($id);
        return $tab ? $tab : [];
    }

    /**
     * 根据user_id获取用户所钓鱼未售卖的各个总数
     */
    public function userFish($user_id){
        $tab = Db::name('user_fish')
            ->alias('a')
            ->field('count(a.fish_id) as amount,b.id')
            ->where('a.user_id',$user_id)
            ->where('a.is_sell','=',0)
            ->group('a.fish_id')
            ->join('fish b','a.fish_id=b.id')
            ->order('b.gold')
            ->select();
        $fish = Db::name('fish')->order('gold asc')->select();
        foreach ($fish as $key=>$val){
            $fish[$key]['amount'] = 0;
            foreach ($tab as $item){
                if ($val['id']==$item['id']){
                    $fish[$key]['amount'] = $item['amount'];
                }
            }
        }
        return $fish ? $fish : [];
    }

    /**
     * 根据user_id获取用户所拥有的鱼饵数量
     */
    public function userBait($user_id){
        $tab = Db::name('user_bait')
            ->alias('a')
            ->field('a.amount,b.name,b.gold,b.id')
            ->where('a.user_id',$user_id)
            ->join('bait b','a.bait_id=b.id')
            ->order('b.gold asc')
            ->select();
        $bait = Db::name('bait')->order('gold asc')->select();
        foreach ($bait as $key=>$val){
            $bait[$key]['amount'] = 0;
            foreach ($tab as $item){
                if ($val['id']==$item['id']){
                    $bait[$key]['amount'] = $item['amount'];
                }
            }
        }
        return $bait ? $bait : [];
    }

    /**
     * 获取所有鱼类
     */
    public function fish(){
        $tab = Db::name('fish')->order('gold')->select();
        return $tab ? $tab : [];
    }


    /**
     * 获取所有鱼饵
     */
    public function bait(){
        $tab = Db::name('bait')->where('id','neq','5')->order('gold')->select();
        return $tab ? $tab : [];
    }

    /**
     * 获取鱼所有对应鱼饵的概率
     */
    public function fish_bait_probability($fish_id){
        $tab = Db::name('fish_bait')
            ->alias('a')
            ->field('a.id,a.probability,b.name')
            ->where('a.fish_id',$fish_id)
            ->join('bait b','a.bait_id=b.id')
            ->select();
        return $tab ? $tab : [];
    }



}
