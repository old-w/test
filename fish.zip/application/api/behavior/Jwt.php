<?php
namespace app\api\behavior;

use Lcobucci\JWT\ValidationData;
use think\Session;
use Lcobucci\JWT\Parser;
use think\Config;
use Lcobucci\JWT\Builder;

class Jwt
{
    public function run(&$jwt)
    {
        if(!is_string($jwt)){
            return;
        }

        if(!Session::has('admin.token')){
            return [
                'code'=>1001,
                'msg'=>'没有权限'
            ];
        }

        $token = (new Parser)->parse($jwt);

        $data = new ValidationData;
        $data->setId(Session::get('admin.token'));
        $data->setIssuer($_SERVER['SERVER_NAME']);
        $data->setAudience($_SERVER['SERVER_NAME']);

        // 授权验证
        if (!$token->validate($data)) {
            return [
                'code' => 1001,
                'msg' => '授权失效',
            ];
        }

        // 账户验证
        $info = model('role')->id($token->getClaim('id'));
        if (!$info) {
            return [
                'code' => 1001,
                'msg' => '账户不存在',
            ];
        }

        // 真假验证
        if($info['username'] !== session('admin.username')){
            return [
                'code' => 1001,
                'msg' => '授权失败',
            ];
        }

        $key = hash_hmac('sha256',$this->sign($info),Config::get('jwt.key'));
        Session::set('admin.token',$key);

        $jwt = (string)(new Builder)->setIssuer($_SERVER['SERVER_NAME'])
        ->setAudience($_SERVER['SERVER_NAME'])
        ->setId($key,true)
        ->setIssuedAt(time())
        ->setExpiration(time()+Config::get('jwt.time'))
        ->set('id',$info['id'])
        ->getToken();

        return false;
    }

    private function sign($info)
    {
        return $info['id'].$info['username'].$info['pwd'];
    }
}