<?php
return [
    'action_begin'=>[
        'app\\api\\behavior\\Jwt'
    ],
];