<?php
return [
    'time'=>3600,
    'key'=>'lide_jwt',
];