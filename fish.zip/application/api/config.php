<?php
return [
    'default_return_type' => 'json',
    'jwt'=>[
        'time'=>3600,
        'key'=>'lide_jwt',
    ],
    'user'=>[
        'key'=>'lide_user'
    ]
];