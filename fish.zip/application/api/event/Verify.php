<?php
namespace app\api\event;

/**
 * 接口验证类
 */
class Verify
{
    public function t_save($data)
    {


        // 验证通过
        return false;

        // TODO: 不支持php5.6
        re:
        // 验证失败
        return '检测到网络劫持，请注意信息安全！本次提交不处理';
    }
}
