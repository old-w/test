<?php

namespace app\push\controller;
use function PHPSTORM_META\elementType;
use think\Session;
use think\Db;
use Workerman\Lib\Timer;

class Socket extends Server
{
    protected $socket = 'websocket://0.0.0.0:9090';
    protected $global_uid = 0;
//    protected $global_room = 0;

    public function onWorkerStart(){

//        $time_interval = 2.5;
//        Timer::add($time_interval,
//            function()
//            {
//                echo "22222\n";
//            }
//        );
//
//        Timer::add($time_interval, function(){
//
//                $new_message = array(
//                    'type' => rand(1,100),
//                    'head_img_url'=>'/Public/main/img/kefu.jpg',
//                    'from_client_name' => 'GM管理员',
//                    'content'=>'期号:22222222222',
//                    'time'=>date('H:i:s')
//                );
//                foreach ($this->worker->connections as $conn) {
//                    $conn->send(json_encode($new_message));
//                }
//        });
//
//        //ping 统计人数
//        Timer::add($time_interval, function(){
//            //ping客户端(获取房间内所有用户列表 )
//            $clients_list = $this->worker->connections;
//            $num = count($clients_list);
//
//            $new_message = array(
//                'type' => 'ping',
//                'content' => $num,
//                'time' => date('H:i:s')
//            );
//            //if($num!=F('online')){
//            //F('online',$num);
//            foreach ($this->worker->connections as $conn) {
//                $conn->send(json_encode($new_message));
//            }
//            //}
//        });
    }
    /*
     * 客户端连接时
     *
     * */
    public function onConnect($connection){
//        global $worker,$global_uid;

//        $connection->uid = ++$global_uid;
//        $connection->onWebSocketConnect = function($connection , $http_header)
//        {
//
//        };
//        echo '连接成功';
    }
    /*
     * 客户端断开时
     *
     * */
    public function onClose($connection){

    }
    /**
     * onMessage
     * @access public
     * 转发客户端消息
     * @param  void
     * @param  void
     * @return void
     */

    public function onMessage($connection, $data) {
//        global $worker,$global_uid,$global_room;
        // 客户端传递的是json数据
        $message_data = json_decode($data, true);
        if (!$message_data) {
            return;
        }

        // 1:表示执行登陆操作 2:表示执行说话操作 3:表示执行退出操作
        // 根据类型执行不同的业务
        switch($message_data['type']){
            // 客户端回应服务端的心跳
            case 'pong' :
                break;
            case 'login' :
               //登陆时判断有没有在其他设备上登录,如果有，释放，重新安排房间
//                $return = [];
//                $isLogin = false;

                if (!empty($this->worker->uidConnections)){
                    foreach ($this->worker->uidConnections as $k=>$v){
                        if ($v['user_id'] == $message_data['uid']){
                            unset($this->worker->uidConnections[$k]);
                            unset($this->worker->connections[$k]);
//                            $isLogin = true;
                        }
                    }
//                    if ($isLogin != false){
//                        $return['content'] = '您已登陆过';
//                        $return['uid'] = $message_data['uid'];
//                        $connection->send(json_encode($return));
//                    }
                }

                $room_id = Session::get('room_id');
                if (!isset($room_id) || empty($room_id)){
                    Session::set('room_id',1);
                }
                $client_name = htmlspecialchars($message_data['client_name']);
                //判断房间总共多少人，返回其头像及人数
                $return = [];
                if (empty($this->worker->uidConnections)){
                    $return['peopleNum'] = 1;
                    $return['probability'] = 0.900;
                    $return['headimgurl'] = db('user')->where('id',$message_data['uid'])->column('headimgurl');
                }else{
                    $user = [];
                    foreach ($this->worker->uidConnections as $key=>$value){
                        if ($value['room'] == $room_id){
                            $user[$key] = $value['user_id'];
                        }
                    }
                    array_push($user,$message_data['uid']);
                    $return['peopleNum'] = count($user);
                    $return['probability'] = db('team_coefficient')->where('number',$return['peopleNum'])->value('probability');
                    $return['headimgurl'] = db('user')->where('id','in',$user)->column('headimgurl');

                }
                // 随机匹配加入,分配房间id
                if ($connection->id % 5 == 0){
                    $connection->room = $room_id;
                    $room_id += 1;
                    Session::set('room_id',$room_id);
                }else{
                    $connection->room =  Session::get('room_id');
                }
                //分配id
                $this->worker->uidConnections[$connection->id]['id'] = $connection->id;
                $this->worker->uidConnections[$connection->id]['user_id'] =$message_data['uid'];
                //设置房间
                $this->worker->uidConnections[$connection->id]['room'] = $connection->room;
//                print_r($this->worker->uidConnections);
                $return['uid'] = $message_data['uid'];
                $return['room'] = $connection->room;
                $return['type'] = 'login';
                $return['nickname'] = $client_name;
                $return['time'] = date('Y-m-d H:i:s');
                $return['content'] = '欢迎用户'.$return['uid'].'进入海洋大亨聊天室';
//                print_r($this->worker->connections);
                foreach ($this->worker->connections as $conn) {
                    if ($conn->room == $return['room']){
                        $conn->send(json_encode($return));
                    }
                }
                break;
            case 'say' :
                foreach ($this->worker->connections as $conn) {
                    if ($conn->room == $message_data['room']){
                        $conn->send(json_encode($message_data));
                    }
                }
                break;

            case 'robot':
                //退出
                foreach ($this->worker->uidConnections as $key=>$value) {
                    if ($value['user_id'] == $message_data['uid']){
                       unset($this->worker->uidConnections[$key]);
                       unset($this->worker->connections[$key]);
                    }
                }
                foreach ($this->worker->connections as $conn) {
                    if ($conn->room == $message_data['room']){
                        $conn->send(json_encode($message_data));
                    }
                }
                break;
        }
    }

}

