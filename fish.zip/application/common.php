<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------

// 应用公共文件
use Aliyun\Core\Config;
use Aliyun\Core\Profile\DefaultProfile;
use Aliyun\Core\DefaultAcsClient;
use Aliyun\Api\Sms\Request\V20170525\SendSmsRequest;

function send_sms($phone,$code){
    require_once '../vendor/alisms/vendor/autoload.php';
    Config::load();     //加载区域节点配置
    //key
    $accessKeyId = 'LTAILtkjcGkbCKlw';
    //secret
    $accessKeySecret = 'vgCs52U4VwbaFeIvsjqLCqje8DTA2g';

    $templateParam = $code;
    //短信签名
    $signName = 'IT情报站';
    //短信模板ID
    $templateCode = 'SMS_107035081';
    //短信API产品名（无需修改）
    $product = "Dysmsapi";
    //短信API域名（无需修改）
    $domain = "dysmsapi.aliyuncs.com";
    //暂时不支持多Region（目前仅支持cn-hangzhou 请勿修改）
    $region = "cn-hangzhou";
    //初始化用户Profile实例
    $profile = DefaultProfile::getProfile($region, $accessKeyId, $accessKeySecret);
    //增加服务节点
    DefaultProfile::addEndpoint("cn-hangzhou","cn-hangzhou", $product, $domain);
    //初始化AcsClient用于发起请求
    $acsClient = new DefaultAcsClient($profile);
    //初始化SendSmsRequest实例用于设置发送短信的参数
    $request = new SendSmsRequest();
    //必填，设置短信接受号码
    $request->setPhoneNumbers($phone);
    //必填，设置签名名称
    $request->setSignName($signName);
    //必填，设置模板CODE
    $request->setTemplateCode($templateCode);
    //可选，设置模板参数
    if ($templateParam){
        $request->setTemplateParam(json_encode($templateParam));
    }
    //发起访问请求
    $acsResponse = $acsClient->getAcsResponse($request);
    //返回请求结果
    $result = json_decode(json_encode($acsResponse),true);

    return $result;
}