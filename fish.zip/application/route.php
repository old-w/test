<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------

return [
//    '/'=>'/fish_game/index.html',
    '[mapi]' => [
        'menu' => 'api/admin/menu',
        'user' => 'api/admin/user',
        'login' => 'api/admin/login',
        'out' => 'api/admin/out',
        'pwd' => 'api/admin/pwd',

        'getConfig' => 'api/admin/getConfig',
        'setConfig' => 'api/admin/setConfig',
        'getcity/:pid' => 'api/admin/getcity',

        //用户
        'users' => 'api/admin/users',
        'user_del' => 'api/admin/user_del',
        'user_update' => 'api/admin/user_update',
        'user_fish' => 'api/admin/user_fish',
        'user_bait' => 'api/admin/user_bait',
        'admin_type' => 'api/admin/admin_type',

        //鱼类管理
        'fish' => 'api/admin/fish',
        'fish_del' => 'api/admin/fish_del',
        'fish_add' => 'api/admin/fish_add',
        'fish_update' => 'api/admin/fish_update',

        //鱼饵管理
        'bait' => 'api/admin/bait',
        'bait_del' => 'api/admin/bait_del',
        'bait_add' => 'api/admin/bait_add',
        'bait_update' => 'api/admin/bait_update',
        'img_add' => 'api/admin/img_add',

        //概率设置
        'probability_add' => 'api/admin/probability_add',
        'probability_update' => 'api/admin/probability_update',

        //钓鱼日志
        'fishlog' => 'api/admin/fishlog',
        //金币日志
        'goldlog' => 'api/admin/goldlog',

        //金币兑换ugas
        'tougas' => 'api/admin/tougas',
        'tougas_type' => 'api/admin/tougas_type',
        'tougas_del' => 'api/admin/tougas_del',

        //金币充值
        'togold' => 'api/admin/togold',
        'togold_type' => 'api/admin/togold_type',
        'tougas_del' => 'api/admin/tougas_del',

        //app后台
        'sendcode' => 'api/admin/sendcode',
        'verificationcode' => 'api/admin/verificationcode',
        'goldToUgasList' => 'api/admin/goldToUgasList',
        'goldToUgasVerify' => 'api/admin/goldToUgasVerify',
        'goldToUgasType' => 'api/admin/goldToUgasType',

        'sys/role/tab' => 'api/admin/sys_role_tab',
        'sys/role/add' => 'api/admin/sys_role_add',
        'sys/role/del' => 'api/admin/sys_role_del',
        'sys/role/info' => 'api/admin/sys_role_info',
        'sys/role/update' => 'api/admin/sys_role_update',

        'sys/admin/tab' => 'api/admin/sys_admin_tab',
        'sys/admin/role' => 'api/admin/sys_admin_role',
        'sys/admin/add' => 'api/admin/sys_admin_add',
        'sys/admin/del' => 'api/admin/sys_admin_del',
        'sys/admin/info/:id' => 'api/admin/sys_admin_info',
        'sys/admin/update' => 'api/admin/sys_admin_update',

        'sys/city/tab' => 'api/admin/sys_city_tab',
        'sys/city/edit' => 'api/admin/sys_city_edit',
        'sys/city/set/info' => 'api/admin/sys_city_set_info',
        'sys/city/get/info' => 'api/admin/sys_city_get_info',


    ],
    '[iapi]' => [
        'getUser' => 'api/index/getUser',
        'getFish' => 'api/index/getFish',
        'getBait' => 'api/index/getBait',
        'getUserFish' => 'api/index/getUserFish',
        'getUserBait' => 'api/index/getUserBait',
        'buyBait' => 'api/index/buyBait',
        'fishSell' => 'api/index/fishSell',
        'fishSellAll' => 'api/index/fishSellAll',
        'formRandomTeam' => 'api/index/formRandomTeam',
        'setupRandomTeam' => 'api/index/setupRandomTeam',
        'fishing' => 'api/index/fishing',
        'fishhook' => 'api/index/fishhook',
        'chooseFishhook' => 'api/index/chooseFishhook',
        'teamUser' => 'api/index/teamUser',
        'existLogin' => 'api/index/existLogin',
        'goldUgasList' => 'api/index/goldUgasList',
        'ugasToGoldList' => 'api/index/ugasToGoldList',
        'userwalletad' => 'api/index/userwalletad',
        'getGold' => 'api/index/getGold',
        'ugas_to_gold_forapp' => 'api/index/ugas_to_gold_forapp',
        'getProportion' => 'api/index/getProportion',
    ],
];
