<?php

namespace app\common\model;

use think\Db;

class Config
{
    /**
     * 获取单项配置值
     */
    public function value($key)
    {
        return Db::name('config')->where('key',$key)->value('value');
    }

    /**
     * 获取所有配置项
     */
    public function getToData(){
        $list = Db::name('config')->where('is_show',1)->select();

        $arr = [];
        foreach($list as $v){
            $arr[] = [
                'title'=>$v['title'],
                'val'=>$v['value'],
                'aux'=>$v['aux'],
                'name'=>$v['key'],
            ];
        }

        return $arr;
    }

    /**
     * 写入配置项
     */
    public function set($key,$val)
    {
        Db::name('config')->where('key',$key)->setField('value',$val);
    }
}
