<?php

namespace app\common\model;

use vikit\map;
use think\Db;
use think\Session;

class City
{
    /**
     * 获取地级市id
     */
    public static function getid($province, $city)
    {
        $pid = Db::name('citys')->field('id')->where('name', $province)->value('id');
        $cid = Db::name('citys')->field('id')->where(['pid' => $pid, 'name' => $city])->value('id');
        return $cid ? $cid : false;
    }

    /**
     * 获取地级市辖区
     */
    public static function getCitys($province, $city)
    {
        $pid = static::getid($province, $city);
        if ($pid) {
            $citys = static::id_select($pid);
        } else {
            $citys = [];
        }

        return $citys;
    }

    /**
     * pid查询城市
     */
    public static function id_select($pid)
    {
        $list = Db::name('citys')->field('id,name')->where('pid', $pid)->cache(1500)->select();

        return $list;
    }

    /**
     * id转换name
     */
    public static function id_name($id)
    {
        $name = Db::name('citys')->field('name')->where('id', $id)->value('name');
        return $name ? $name : false;
    }

    /**
     * 获取ip数据
     */
    public static function ip($ip)
    {
        $map = new map;
        $ip_info = json_decode($map->ip($ip));
        $pid = Db::name('citys')->field('id')->where('name',$ip_info->province)->value('id');
        $cid = Db::name('citys')->field('id')->where(['name'=>$ip_info->city,'pid'=>$pid])->value('id');

        return [
            'province' => $pid,
            'city' => $cid,
            'citys'=>Db::name('citys')->field('id,name')->where('pid',$pid)->select(),
            'data' => static::getCitys($ip_info->province, $ip_info->city),
        ];
    }

    /**
     * 获取城市id
     */
    public static function cid()
    {
        if(Session::has('index.cid')){
            return Session::get('index.cid');
        }

        $map = new map;
        // TODO: 后期需要换成动态获取ip
        // $ip = json_decode($map->ip(Request::instance()->ip()));
        $ip = json_decode($map->ip('60.190.157.195'));
        $cid = static::getid($ip->province, $ip->city);
        Session::set('index.cid', $cid);

        return $cid;
    }

    /**
     * 获取全国开通城市
     */
    public static function open_list()
    {
        // 省级
        $pro = City::id_select(0);
        $zxs = array_shift($pro);

        usort($pro,function($a,$b){
            $a = iconv('UTF-8','GBK',$a['name']);
            $b = iconv('UTF-8','GBK',$b['name']);
            return $a > $b ? 1 : -1;
        });
        array_unshift($pro,$zxs);

        // 开通的城市
        $citys = [];
        $city = Db::name('open_city')->field('id,name,pid')->where('show', 1)->select();
        foreach ($city as $item) {
            $citys[$item['pid']][] = ['id' => $item['id'], 'name' => $item['name']];
        }

        return [$pro,$citys];
    }
}
