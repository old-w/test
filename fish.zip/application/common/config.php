<?php
return [
//    'default_return_type' => 'json',
    'vmap'=>[
        'key'=>'f944a58171423a3f97b18f2d11e2e48c',
        'format'=>'json'
    ],

];