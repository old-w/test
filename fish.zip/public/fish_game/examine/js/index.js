var vm = new Vue({
    el: '#container',
    data() {
        return {
            isLogin: false,
            code:'',
            ugas: 0,
            isAll: false,
            listData: [],
            chainId:'',
            chooseData: [],
        };
    },
    mounted() {
        var that = this
        // that.getList()
        // 验证登录
        $.ajax({
            type: "GET",
            url: "http://fish.7in6.com/mapi/sendcode",
            data: '',
            dataType: "json",
            success: function (res) {
                if (res.code == 1) {
                    that.tips('验证码已发送', 1500)
                } else{
                    that.tips(res.msg, 1500)
                }
            }
        });
        that.chainId = that.getUrlParam('chainId')

        document.addEventListener("message", that.receiveMessage, false);
    },
    methods:{
        // 发送验证码
        sendCode(){
            var that = this
            $.ajax({
                type: "GET",
                url: "http://fish.7in6.com/mapi/verificationcode",
                data: {
                    code: that.code
                },
                dataType: "json",
                success: function (res) {
                    if (res.code == 1) {
                        that.tips(res.msg, 1500)
                        that.isLogin = true
                        that.getList()
                        that.chooseData = []
                    } else {
                        that.tips(res.msg, 1500)
                    }
                }
            });
        },
        // 获取列表数据
        getList(){
            var that = this
            $.ajax({
                type: "GET",
                url: "http://fish.7in6.com/mapi/goldToUgasList",
                data: '',
                dataType: "json",
                success: function (res) {
                    console.log(res)
                    if (res.code == 1) {
                        that.listData = res.data
                        if (that.listData.length) {
                            for (var i = 0; i < that.listData.length; i++) {
                                that.listData[i].isChoose = false
                            }
                        }
                        that.ugas = res.sum[0].ugas
                    } else {
                        that.tips(res.msg, '1500')
                    }
                }
            });
        },
        choose(item, index) {
            var that = this
            if (item.isChoose){//取消选择
                for (var i = 0; i < that.chooseData.length; i++) {
                    if (that.chooseData[i].id == item.id) {
                        that.chooseData.splice(i,1)
                    }
                }
                console.log(that.chooseData)
            }else{//选中
                that.chooseData.push(item)
                console.log(that.chooseData)
            }
        },
        // 全选
        chooseAll(){
            if (this.isAll) {
                this.isAll = false;
                for (var i = 0; i < this.listData.length; i++) {
                    this.listData[i].isChoose = false;
                }
                this.chooseData = []
            } else {
                this.isAll = true;
                for (var i = 0; i < this.listData.length; i++) {
                    this.listData[i].isChoose = true;
                    this.chooseData.push(this.listData[i])
                }
            }
        },
        // 同意一个
        doone(item,index){
            var that = this
            var bizId = that.getOrderId()
            $.ajax({
                type: "GET",
                url: "http://fish.7in6.com/mapi/goldToUgasVerify",
                data: {
                    id:[item.id],
                    bizid: bizId
                },
                dataType: "json",
                success: function (res) {
                    console.log(res)
                    if (res.code == 1) {
                        that.sendData(JSON.stringify({
                            'chainId': that.chainId,
                            'contract': 'utrio.token',
                            'action': 'transfer',
                            'type': 'transfer',
                            'bizId': bizId,
                            'data': {
                                'receiver': item.wallet_address,
                                'quantity': item.ugas + ' UGAS',
                                'memo': '提现',
                            },
                        }));
                    } else {
                        that.tips(res.msg, '1500')
                    }
                }
            });
        },
        // 批量同意
        doAll(){
            var that = this
            if (that.chooseData.length < 2) return;
            console.log(that.chooseData);
            // var idArr = []
            // for (var i = 0; i < that.chooseData.length; i++) {
            //     idArr.push(that.chooseData[i].id)
            // }
            var bizId = that.getOrderId()
            // var sendArr = []
            // for (var i = 0; i < that.chooseData.length; i++) {
            //     sendArr.push({
            //         'chainId': that.chainId,
            //         'contract': 'utrio.token',
            //         'action': 'transfer',
            //         'type': 'transfer',
            //         'bizId': bizId,
            //         'data': {
            //             'receiver': that.chooseData[i].wallet_address,
            //             'quantity': that.chooseData[i].ugas + ' UGAS',
            //             'memo': '提现',
            //         },
            //     })
            // }
            $.ajax({
                type: "GET",
                url: "http://fish.7in6.com/mapi/goldToUgasVerify",
                data: {
                    id: [that.chooseData[0].id, that.chooseData[1].id],
                    bizid: bizId
                },
                dataType: "json",
                success: function (res) {
                    console.log(res)
                    if (res.code == 1) {
                        that.sendData(JSON.stringify(
                            [
                                {
                                    'chainId': that.chainId,
                                    'contract': 'utrio.token',
                                    'action': 'transfer',
                                    'type': 'transfer',
                                    'bizId': bizId,
                                    'data': {
                                        'receiver': that.chooseData[0].wallet_address,
                                        'quantity': that.chooseData[0].ugas + ' UGAS',
                                        'memo': '提现',
                                    },
                                },
                                {
                                    'chainId': that.chainId,
                                    'contract': 'utrio.token',
                                    'action': 'transfer',
                                    'type': 'transfer',
                                    'bizId': bizId,
                                    'data': {
                                        'receiver': that.chooseData[1].wallet_address,
                                        'quantity': that.chooseData[1].ugas + ' UGAS',
                                        'memo': '提现',
                                    },
                                },
                            ]
                        ));
                    } else {
                        that.tips(res.msg, '1500')
                    }
                }
            });
        },
        // 转账回执
        receiveMessage(e) {
            var that = this
            var data = JSON.parse(e.data)
            if (data.success) {
                $.ajax({
                    type: "GET",
                    url: "http://fish.7in6.com/mapi/goldToUgasType",
                    data: {
                        bizid: data.bizId
                    },
                    dataType: "json",
                    success: function (res) {
                        console.log(res)
                        if (res.code == 1) {
                            that.tips('操作成功', '1500')
                            that.getList()
                        } else {
                            that.tips(res.msg, '1500')
                        }
                    }
                });
            } else {
                that.tips(data.msg, 1500)
            }
        },
        // 轻提示弹窗
        tips(msg, time) {
            time = time ? time : 1000
            $('.tips_window').css('display', 'block')
            $('.tips_window .words').text(msg)
            setTimeout(function () {
                $('.tips_window').css('display', 'none')
            }, time)
        },

        //获取业务ID
        getOrderId() {
            var myDate = new Date;
            var year = myDate.getFullYear(); //获取当前年
            var mon = myDate.getMonth() + 1; //获取当前月
            var date = myDate.getDate(); //获取当前日
            var h = myDate.getHours(); //获取当前小时数(0-23)
            var m = myDate.getMinutes(); //获取当前分钟数(0-59)
            var s = myDate.getSeconds(); //获取当前秒
            var x = 9999;
            var y = 1000;
            var rand = parseInt(Math.random() * (x - y + 1) + y);
            var result = year + this.isGtTen(mon) + this.isGtTen(date) + this.isGtTen(h) + this.isGtTen(m) + this.isGtTen(s) + rand;
            return result;
        },
        isGtTen(val) {
            if (val == '' || val == undefined) {
                return;
            }
            if (val < 10) {
                return '0' + val;
            }
            return val;
        },
        // 获取URL参数
        getUrlParam(name) {
            var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
            var r = window.location.search.substr(1).match(reg); //匹配目标参数
            if (r != null) return unescape(r[2]);
            return null; //返回参数值
        },
        // 唤起APP转账方法
        sendData(data) {
            if (window.postMessage) {
                console.log('sending data to webview...', data);
                window.postMessage(data);
            } else {
                throw Error('postMessage接口还未注入');
            }
        },
        
    },
})