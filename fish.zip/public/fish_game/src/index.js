// var game;
$(function () {
    var data1 = {};
    var postData = {};
    var ugas_text = ''
    var phone = ''; // 手机号
    var myYuerData; // 我的鱼饵
    var myYugouData; // 我的鱼钩
    var chooseData; // 选择的鱼饵
    var up;
    var hand;
    var yuerData; // 鱼市买鱼饵数据
    var yuData; // 鱼市买鱼数据
    var isApp = true
    // 第一场景 加载loading
    // var bootState = function (game) {
    //     this.preload = function () {
    //         game.load.image('loading', 'assets/preloader.gif');
    //     };
    //     this.create = function () {
    //         game.stage.backgroundColor = '#2d2d2d';
    //         game.input.maxPointers = 1;
    //         game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
    //         game.scale.pageAlignHorizontally = true;
    //         game.scale.pageAlignVertically = true;
    //         game.state.start('loader');
    //     };
    // }
    // 第二场景 加载资源场景 显示loading
    // var loaderState = function (game) {
    //     var progressText;
    //     this.init = function () {
    //         var sprite = game.add.image(game.world.centerX, game.world.centerY, 'loading');
    //         sprite.anchor = {
    //             x: 0.5,
    //             y: 0.5
    //         };
    //         progressText = game.add.text(game.world.centerX, game.world.centerY + 30, '0%', {
    //             fill: '#fff',
    //             fontSize: '16px'
    //         });
    //         progressText.anchor = {
    //             x: 0.5,
    //             y: 0.5
    //         }; 
    //     };
    //     this.preload = function () {
    //         game.load.audio("click_music", "assets/audio/click_music.mp3");
    //         game.load.audio("diao_music", "assets/audio/diao_music.mp3");
    //         game.load.audio("bg_music", "assets/audio/bg_music.mp3");
    //         game.load.image("bg", "assets/bg.png");
    //         game.load.image("up", "assets/up.png");
    //         game.load.image("hand", "assets/hand.png");
    //         game.load.spritesheet('fish', 'assets/diao.png', 750, 1334)
    //         game.load.onFileComplete.add(function (progress) {
    //             progressText.text = progress + '%';
    //         });
            
    //     };
    //     this.create = function () {
    //         if (progressText.text == "100%") {
    //             game.state.start('game');
    //         }
    //     };
    // }
    // 第三场景 游戏场景
    // var gameState = function () {
    //     var fish;
    //     var diao_music;
    //     var click_music;
    //     var bg_music;
    //     var diao_flag = true;
    //     var out_flag = false;
    //     var time1;
    //     var out_type = 2

    //     this.init = function () {
    //         click_music = game.add.audio('click_music')
    //         diao_music = game.add.audio('diao_music')
    //         bg_music = game.add.audio('bg_music', 1, true)
    //     }
    //     this.create = function () {
    //         bg_music.play()
    //         game.add.tileSprite(0, 0, game.width, game.height, 'bg');
    //         fish = game.add.sprite(0, 0, 'fish')
    //         var finsh = fish.animations.add('diao', [0, 1, 2, 3, 4, 6, 7, 8, 9, 10, 12, 13, 14, 15, 16, 18, 19, 20, 21, 22, 5, 11, 17, 23])
    //         var finsh2 = fish.animations.add('diaoing', [24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47])
    //         var finsh3 = fish.animations.add('diaoout', [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71])
    //         fish.inputEnabled = true;
    //         fish.input.useHandCursor = true;
    //         finsh3.onComplete.add(function(){
    //             diao_flag = true
    //             out_flag = false
    //             fishing(out_type)
    //         })
    //         finsh.onComplete.add(function(){
    //             fish.animations.play('diaoing', 18, true)
    //             $('.box').css('display', 'block');
    //             time1 = setTimeout(function () {
    //                 $('.box').css('display', 'none');
    //                 if (out_flag) {
    //                     fish.animations.play('diaoout', 20)
    //                     out_type = 0
    //                 }
    //             },5000)
    //         })
    //     }



    // 背景音乐播放
    document.addEventListener('DOMContentLoaded', function () {
        function audioAutoPlay() {
            var audio = document.getElementById('bg_music');
            audio.play();
            document.addEventListener("WeixinJSBridgeReady", function () {
                audio.play();
            }, false);
        }
        audioAutoPlay();
    });
    //--创建触摸监听，当浏览器打开页面时，触摸屏幕触发事件，进行音频播放
    document.addEventListener('touchstart', function () {
        function audioAutoPlay() {
            var audio = document.getElementById('bg_music');
            audio.play();
        }
        audioAutoPlay();
    });

    var click_music = document.getElementById('click_music');
    var diao_music = document.getElementById('diao_music');

    // ajax拦截
    $.ajaxSetup({
        contentType: "application/x-www-form-urlencoded;charset=utf-8",
        complete: function (XMLHttpRequest, textStatus) {
            //通过XMLHttpRequest取得响应结果
            var res = XMLHttpRequest.responseText;
            try {
                var jsonData = JSON.parse(res);
                if (jsonData.code == -2) {
                    $('.login_window').css('display', 'block');
                }
            } catch (e) {
                console.log(e, 'catch')
            }
        }
    });

    // 判断登录态
    if (!localStorage.token) {
        $('.login_window').css('display', 'block');
    } else {
        getYuer2()
        getLink() // 获取复制链接
        getUserInfo() // 获取用户信息
    }
    
    if (getUrlParam("chainId")) { 
        //是app
        console.log('2222')
        $('.no_app').css('display', 'none')
        $('.gold_app').css('display','block')
        isApp = true
        if (localStorage.is_admin == 1) {
            $('.admin_btn').css('display', 'block')
        }

    }else{
        
        //非app
        $('.no_app').css('display', 'block')
        $('.gold_app').css('display', 'none')
        isApp = false
        console.log('1111', isApp)
    }
    

    

    // 获取 我的鱼饵 信息
    function getYuer() {
        $.ajax({
            type: "GET",
            url: "http://fish.7in6.com/iapi/getUserBait",
            data: {
                token: localStorage.token
            },
            dataType: "json",
            success: function (res) {
                if (res.code == 1) {
                    if (res.data.bait.length) {
                        myYuerData = res.data.bait;
                        if (chooseData) {
                            for (var i = 0; i < res.data.bait.length; i++) {
                                res.data.bait[i].isUse = false;
                                if (res.data.bait[i].id == chooseData.id){
                                    res.data.bait[i].isUse = true;
                                    chooseData = res.data.bait[i]
                                }
                            }
                            $('.yuer_item').children('div').children('.num').text(chooseData.amount);
                            var text = chooseData.name + '：' + chooseData.amount + '个';
                            $('.yuer_item').children('span').text(text);
                            $('.yuer_item img').attr('src', 'http://fish.7in6.com' + chooseData.img_url_2)
                        }else{
                            res.data.bait[0].isUse = true;
                        }
                        yuerAddHtml(myYuerData)
                    }
                } else {
                    tips(res.msg,1000)
                }
            }
        });
    }
    
    // 获取 我的鱼钩 信息
    function getYugou () {
        $.ajax({
            type: "GET",
            url: "http://fish.7in6.com/iapi/fishhook",
            data: {
                token: localStorage.token
            },
            dataType: "json",
            success: function (res) {
                if (res.code == 1) {
                    if (res.data.data.length) {
                        for (var i = 0; i < res.data.data.length; i++) {
                            res.data.data[i].isUse = false;
                            if (res.data.data[i].status == 2) {
                                res.data.data[i].isUse = true;
                            }
                        }
                        myYugouData = res.data;
                        yugouAddHtml(myYugouData)
                        $('.yugou_window').css('display', 'block');
                    }
                } else {
                    tips(res.msg,1000)
                }
            }
        });
    }

    // 获取 分享游戏-复制 链接
    function getLink() {
        var userId = localStorage.id
        $.ajax({
            type: "GET",
            url: "http://fish.7in6.com/api/login/share",
            data: {
                id: userId
            },
            dataType: "json",
            success: function (res) {
                if (res.status == 200) {
                    $('#text').text(res.data);
                }
            }
        });
    }

    // 获取 鱼市-买鱼饵 信息
    function getShopYuer(type) {
        $.ajax({
            type: "GET",
            url: "http://fish.7in6.com/iapi/getBait",
            data: {
                token: localStorage.token
            },
            dataType: "json",
            success: function (res) {
                if (res.code == 1) {
                    if (res.data.bait.length) {
                        yuerData = res.data.bait
                        $(".scroll_box").empty();
                        for (var i = 0; i < yuerData.length; i++) {
                            var html =
                                '<div class="mai_yuer_item" data-index="' + i + '">' +
                                '<span class="yuer_name">' + yuerData[i].name + '</span>' +
                                '<img class="yuer_img" src="http://fish.7in6.com' + yuerData[i].img_url + '" alt="">' +
                                '<div class="buy_btn">' +
                                '<img src="assets/jb.png" alt="">' +
                                '<span>' + yuerData[i].gold+'</span>' +
                                '</div>' +
                                '</div>'
                            $(".mai_yuer .scroll_box").append(html);
                        }
                        $(".yushi_window").css("display", "block");
                        if (type == 1) {
                            $(".yushi_tabs .btn_left").trigger("click");
                        } else {
                            $(".yushi_tabs .btn_right").trigger("click");
                        }
                    }
                } else {
                    tips(res.msg,1000)
                }
            }
        });
    }
    
    // 获取 鱼市-卖鱼 信息
    function getShopYu(type) {
        $.ajax({
            type: "GET",
            url: "http://fish.7in6.com/iapi/getUserFish",
            data: {
                token: localStorage.token
            },
            dataType: "json",
            success: function (res) {
                if (res.code == 1) {
                    if (res.data.fish.length) {
                        yuData = res.data.fish
                        addShopYuHtml(yuData)
                        $('.all_const span').text(res.data.sum)
                        if (type == 1) {
                            $(".yushi_tabs .btn_left").trigger("click");
                        } else {
                            $(".yushi_tabs .btn_right").trigger("click");
                        }
                    }
                } else {
                    tips(res.msg,1000)
                }
            }
        });
    }

    // 获取 用户 信息
    function getUserInfo() {
        $.ajax({
            type: "GET",
            url: "http://fish.7in6.com/iapi/getUser",
            data: {
                token: localStorage.token
            },
            dataType: "json",
            success: function (res) {
                if (res.code == 1) {
                    var num = parseInt(res.data.user.gold)
                    num = (num).toFixed(0)
                    $('.wrap_gold_num').text(num)
                    $('.gold_num').text(num)
                } else {
                    tips(res.msg,1000)
                }
            }
        });
    }
    

    // 点击市场按钮
    $('.wrap_shop_btn').click(function (e) {
        click_music.play();
        openShopWindow(1)
    });
    
    // 打开市场弹窗
    function openShopWindow(type) {
        getShopYuer(type)
        getShopYu(type)
    }

    // 点击鱼饵
    var chooseYuer;
    $(".scroll_box").on("click", ".mai_yuer_item", function(e) {
        click_music.play();
        var index = e.currentTarget.dataset.index;
        chooseYuer = yuerData[index];
        $('.math_msg_right_top .name').text(chooseYuer.name)
        $('.math_msg_right_bottom span').text(chooseYuer.gold)
        var gold = chooseYuer.gold * num_val
        $('.math_window .math_btn').text(gold);
        $(".math_window").css("display", "block");
        $(".math_img img").attr("src", "http://fish.7in6.com" + chooseYuer.img_url);
    })

    // 买鱼饵选择数量滑块
    var num_val = 0;
    $.fn.RangeSlider = function (cfg) {
        this.sliderCfg = {
            min: cfg && !isNaN(parseFloat(cfg.min)) ? Number(cfg.min) : null,
            max: cfg && !isNaN(parseFloat(cfg.max)) ? Number(cfg.max) : null,
            step: cfg && Number(cfg.step) ? cfg.step : 1,
            callback: cfg && cfg.callback ? cfg.callback : null
        };
        var $input = $(this);
        var min = this.sliderCfg.min;
        var max = this.sliderCfg.max;
        var step = this.sliderCfg.step;
        var callback = this.sliderCfg.callback;

        $input.attr('min', min)
            .attr('max', max)
            .attr('step', step);

        $input.bind("input", function (e) {
            $input.attr('value', this.value);
            num_val = this.value
            $input.css('background-size', this.value * 100.0 / max + '% 100%');
            if ($.isFunction(callback)) {
                callback(this);
            }
        });
    };
    var change = function ($input) {
        var gold = num_val * chooseYuer.gold;
        $('.math_msg_right_top .num').text(num_val)
        $('.math_window .math_btn').text(gold);
        /*拖动滑块的事件，内容可自行定义*/

    }
    $('#slider').RangeSlider({
        min: 0,
        max: 99,
        step: 1,
        callback: change
    });

    //购买鱼饵
    $('.math_window .math_btn').click(function(){
        click_music.play()
        var number = $('.math_msg_right_top .num').text()
        $.ajax({
            type: "GET",
            url: "http://fish.7in6.com/iapi/buyBait",
            data: {
                token: localStorage.token,
                bait_id: chooseYuer.id,
                number: number
            },
            dataType: "json",
            success: function (res) {
                if (res.code == 1) {
                    tips('购买成功',1000)
                    var num = parseInt(res.data.gold)
                    num = (num).toFixed(0)
                    $('.wrap_gold_num').text(num)
                    $('.gold_num').text(num)
                    $(".math_window").css("display", "none");
                    for (var i = 0; i < res.data.bait.length; i++) {
                        if (res.data.bait[i].id == chooseData.id){
                            $('.yuer_btn').children('.num').text(res.data.bait[i].amount);
                            $('.yuer_btn img').attr('src', 'http://fish.7in6.com' + res.data.bait[i].img_url_2)
                        }
                    }
                    
                } else {
                    tips(res.msg,1000)
                }
            }
        });
    })
        
    // 点击买鱼饵内金币
    $('.my_gold .gold_box').click(function () {
        click_music.play();
        openGoldWindow()
    });

    // 鱼市tab切换
    $(".yushi_tabs .btn_left").click(function () {
        click_music.play();
        $(".yushi_tabs .left1").css("display", "none");
        $(".yushi_tabs .left2").css("display", "block");
        $(".yushi_tabs .right1").css("display", "block");
        $(".yushi_tabs .right2").css("display", "none");
        $(".mai_yuer").css("display", "block");
        $(".mai_yu").css("display", "none");
    });

    $(".yushi_tabs .btn_right").click(function () {
        click_music.play();
        $(".yushi_tabs .left1").css("display", "block");
        $(".yushi_tabs .left2").css("display", "none");
        $(".yushi_tabs .right1").css("display", "none");
        $(".yushi_tabs .right2").css("display", "block");
        $(".mai_yuer").css("display", "none");
        $(".mai_yu").css("display", "block");
    });

    //处理 鱼市-卖鱼 数据
    function addShopYuHtml(yuData) {
        $(".mai_yu .scroll_box2").empty();
        if(yuData.length){
            for(var i = 0; i<yuData.length; i++){
                var html = '';
                if (yuData[i].amount == 0) {
                    html =
                        '<div class="yu_item">'+
                            '<div class="yu_item_left">'+
                                '<div class="yu_img_box">'+
                                    '<img class="yu_img" src="http://fish.7in6.com' + yuData[i].img_url + '" alt="">'+
                                    '<span>' + yuData[i].amount + '</span>' +
                                '</div>'+
                                '<div class="yu_name_box">'+
                                ' <div class="yu_name">'+ yuData[i].name +'</div>'+
                                    '<div class="yu_num">'+
                                        '<img src="assets/jb.png" alt="">'+
                                        '<span>'+ yuData[i].gold +'</span>'+
                                    '</div>'+
                                '</div>'+
                            '</div>'+
                            '<div class="yu_item_right" data-index="' + i + '">' +
                                '<img src="assets/sell2.png" alt="">'+
                            '</div>'+
                        '</div>'
                }else{
                    html =
                        '<div class="yu_item">'+
                            '<div class="yu_item_left">'+
                                '<div class="yu_img_box">'+
                                    '<img class="yu_img" src="http://fish.7in6.com' + yuData[i].img_url + '" alt="">'+
                                    '<span>' + yuData[i].amount + '</span>' +
                                '</div>'+
                                '<div class="yu_name_box">'+
                                ' <div class="yu_name">'+ yuData[i].name +'</div>'+
                                    '<div class="yu_num">'+
                                        '<img src="assets/jb.png" alt="">'+
                                        '<span>' + yuData[i].gold + '</span>' +
                                    '</div>'+
                                '</div>'+
                            '</div>'+
                            '<div class="yu_item_right" data-index="' + i + '">' +
                                '<img src="assets/sell1.png" alt="">'+
                            '</div>'+
                        '</div>'
                }
                
                $(".mai_yu .scroll_box2").append(html);
            }
        }
    }

    // 卖鱼
    $('.mai_yu .scroll_box2').on('click', '.yu_item .yu_item_right', function (e) {
        click_music.play();
        var index = e.currentTarget.dataset.index
        if (yuData[index].amount != 0) {
            $.ajax({
                type: "GET",
                url: "http://fish.7in6.com/iapi/fishSell",
                data: {
                    fish_id: yuData[index].id,
                    token: localStorage.token
                },
                dataType: "json",
                success: function (res) {
                    if (res.code == 1) {
                        tips('出售成功', 1000)
                        yuData = res.data.fish
                        addShopYuHtml(yuData)
                        $('.all_const span').text(res.data.sum)
                        var num = parseInt(res.data.gold)
                        num = (num).toFixed(0)
                        $('.wrap_gold_num').text(num)
                        $('.gold_num').text(num)
                    } else {
                        tips(res.msg,1000)
                    }
                }
            });
        }
    })

    // 一键卖鱼
    $('.sell_yu img').click(function () {
        click_music.play();
        $.ajax({
            type: "GET",
            url: "http://fish.7in6.com/iapi/fishSellAll",
            data: {
                token: localStorage.token
            },
            dataType: "json",
            success: function (res) {
                if (res.code == 1) {
                    yuData = res.data.fish
                    addShopYuHtml(yuData)
                    $('.all_const span').text(res.data.sum)
                    var num = parseInt(res.data.gold)
                    num = (num).toFixed(0)
                    $('.wrap_gold_num').text(num)
                    $('.gold_num').text(num)
                } else {
                    tips(res.msg,1000)
                }
            }
        });
    })

    // 关闭没有鱼市弹窗
    $(".yushi_box .close").click(function() {
        click_music.play();
        $(".yushi_window").css("display", "none");
    });
    // 关闭鱼饵选择数量弹窗
    $(".math_box .close").click(function() {
        click_music.play();
        $(".math_window").css("display", "none");
    });
    




    // 打开选择鱼饵弹窗
    $(".yuer_btn").click(function(e) {
        e.stopPropagation()
        click_music.play()
        getYuer()
        $(".choose_yuer").css("display", "block");
        
    });

    // 选择鱼饵
    $(".all_yuer").on("click", ".yuer_item_all", function (e) {
        e.stopPropagation()
        click_music.play()
        var id = e.currentTarget.dataset.id
        for (var j = 0; j < myYuerData.length; j++) {
            myYuerData[j].isUse = false
            if(j == id){
                chooseData = myYuerData[j]
                myYuerData[j].isUse = true
            }
        }
        if (chooseData.amount == 0) {
            $(".tip_window").css('display','block');
        }
        yuerAddHtml(myYuerData)
        $('.yuer_item').children('div').children('.num').text(chooseData.amount);
        var text = chooseData.name + '：' + chooseData.amount + '个';
        $('.yuer_item').children('span').text(text);
        $('.yuer_item img').attr('src', 'http://fish.7in6.com' + chooseData.img_url_2)
        $('.yuer_btn').children('.num').text(chooseData.amount);
        $('.yuer_btn img').attr('src', 'http://fish.7in6.com' + chooseData.img_url_2)
        $(".choose_yuer").css("display", "none");
    });
    // 点击我的鱼饵
    $('.my_yuer').click(function () {
        click_music.play()
        $(".choose_yuer").css("display", "none");
    });
    // 关闭没有鱼饵弹窗
    $('.tip_window .tip_box .close').click(function (e) {
        click_music.play()
        $(".tip_window").css('display', 'none');
    });

    // 没有鱼饵弹窗 去购买
    $('.tip_window .tip_box .gopay').click(function (e) {
        click_music.play()
        $(".tip_window").css('display', 'none');
        openShopWindow(1)
    });

    // 处理鱼饵数据
    function yuerAddHtml (data) {
        if (data.length) {
            var html = ''
            for(var i=0;i<data.length;i++){
                if (data[i].isUse) {
                    html += 
                    '<div class="yuer_item_all" data-id="' + i + '">' +
                        '<div>'+
                            '<img class="yuer_is" src="assets/yuer_is.png" alt="">' +
                            '<img class="yuer_no" style="display:none" src="http://fish.7in6.com' + data[i].img_url_2 + '" alt="">' +
                        '</div>'+
                        '<span>' + data[i].name + '：' + data[i].amount + '个</span>' +
                    '</div>';
                }else{
                    html += 
                    '<div class="yuer_item_all" data-id="' + i + '">' +
                        '<div>'+
                            '<img class="yuer_is" style="display:none" src="assets/yuer_is.png" alt="">' +
                            '<img class="yuer_no" src="http://fish.7in6.com' + data[i].img_url_2 + '" alt="">' +
                        '</div>'+
                        '<span>' + data[i].name + '：' + data[i].amount + '个</span>' +
                    '</div>';
                }
            }
            $('.all_yuer').html(html);
        }
    }


    // 点击鱼钩按钮
    $('.wrap_yugou_btn').click(function () {
        click_music.play();
        getYugou()
    });

    // 关闭鱼钩弹窗
    $('.yugou_box .close').click(function () {
        click_music.play();
        $('.yugou_window').css('display', 'none');
    });
    
    // 分享鱼钩
    $('.yogou_wrap').on('click', '.yogou_item_share', function (e) {
        // debugger
        e.stopPropagation()
        click_music.play()
        $(".copy_btn").trigger("click");
    });

    // 复制点击事件
    $('.copy_btn').click(function (e) {
        var text = $('#text').text()
        copyText(text)
    });

    // 复制调用方法
    function copyText(text) {
        // 数字没有 .length 不能执行selectText 需要转化成字符串
        const textString = text.toString();
        let input = document.querySelector('#copy-input');
        if (!input) {
            input = document.createElement('input');
            input.id = "copy-input";
            input.readOnly = "readOnly"; // 防止ios聚焦触发键盘事件
            input.style.position = "absolute";
            input.style.left = "-1000px";
            input.style.zIndex = "-1000";
            document.body.appendChild(input)
        }
        input.value = textString;
        // ios必须先选中文字且不支持 input.select();
        selectText(input, 0, textString.length);
        if (document.execCommand('copy')) {
            document.execCommand('copy');
            tips('已复制到粘贴板',1000)
        } else {
            console.log('不兼容');
        }
        input.blur();
        $('#copy-input').blur(function () {
            console.log('jqblur')
            window.scroll(0, 0);
        })
        input.onblur = function(){
            console.log('onblur')
            window.scroll(0, 0);
        }
        setTimeout(function(){
            $('#copy-input').blur(function () {
                console.log('jqblur')
                window.scroll(0, 0);
            })
            input.onblur = function () {
                console.log('onblur')
                window.scroll(0, 0);
            }
        },500)
        // input自带的select()方法在苹果端无法进行选择，所以需要自己去写一个类似的方法
        // 选择文本。createTextRange(setSelectionRange)是input方法
        function selectText(textbox, startIndex, stopIndex) {
            if (textbox.createTextRange) { //ie
                const range = textbox.createTextRange();
                range.collapse(true);
                range.moveStart('character', startIndex); //起始光标
                range.moveEnd('character', stopIndex - startIndex); //结束光标
                range.select(); //不兼容苹果
            } else { //firefox/chrome
                textbox.setSelectionRange(startIndex, stopIndex);
                textbox.focus();
            }
        }
    };

    // 选择鱼钩
    $('.yogou_wrap').on('click', '.yugou_item', function (e) {
        click_music.play();
        var index = e.currentTarget.dataset.index
        if (myYugouData.data[index].status != 0) {
            $.ajax({
                type: "GET",
                url: "http://fish.7in6.com/iapi/chooseFishhook",
                data: {
                    fishhook_id: myYugouData.data[index].level,
                    token: localStorage.token
                },
                dataType: "json",
                success: function (res) {
                    if (res.code == 1) {
                        tips('鱼钩切换成功',1000)
                        for (var i = 0; i < myYugouData.data.length; i++) {
                            myYugouData.data[i].isUse = false
                        }
                        myYugouData.data[index].isUse = true
                        yugouAddHtml(myYugouData)
                    }else{
                        tips(res.msg,1000)
                    }
                }
            });
        }
    });
    
    // 处理鱼钩数据
    function yugouAddHtml(yugouData) {
        var data = yugouData.data
        $(".yogou_wrap").empty();
        if (data.length) {
            var html = ''
            for (var i = 0; i < data.length; i++) {
                if (data[i].status == 0) {
                    html += '<div class="yugou_item nobg" data-index="' + i + '">'
                    html += '<div class="yugou_item_left">'
                    html += '<img class="yugou_item_img" src="assets/lock.png" alt="">'
                } else{
                    html += '<div class="yugou_item" data-index="' + i + '">'
                    html += '<div class="yugou_item_left">'
                    html += '<img class="yugou_item_img_2" src="http://fish.7in6.com' + data[i].img_url + '" alt="">'
                }
                
                if (data[i].number) {
                    html += '<div class="yogou_item_word">'
                }else{
                    html += '<div class="yogou_item_word nowidth">'
                }
                html += '<div class="yogou_item_name">' 
                html += '<span class="name">' + data[i].name + '</span>'
                if (data[i].level == 1) {
                    html += '<span class="tip">概率：-10%</span>'
                } else if (data[i].level == 3) {
                    html += '<span class="tip">概率：+10%</span>'
                } else if (data[i].level == 4) {
                    html += '<span class="tip">概率：+18%</span>'
                } else if (data[i].level == 9) {
                    html += '<span class="tip">概率：+22%</span>'
                }
                html += '</div>'
                if (data[i].number && data[i].number != 1) {
                    html += '<div class="yogou_item_tip">' + data[i].note + ',当前完成' + yugouData.number + '/' + data[i].number + '</div>'
                } else if (data[i].number == null) {
                    html += '<div class="yogou_item_tip nowidth">' + data[i].note + '</div>'
                } else{
                    html += '<div class="yogou_item_tip">' + data[i].note + '</div>'
                }
                html += '</div>' 
                html += '</div>' 
                html += '<div class="yugou_item_right">' 
                if (data[i].number && data[i].status == 0) {
                    html += '<div class="yogou_item_share">'
                    html += '<img src="assets/share.png" alt="">'
                    html += '</div>'
                } else if (data[i].number && !data[i].isUse) {
                    html += '<div class="yogou_item_yy">已拥有</div>'
                } else if (data[i].number && data[i].isUse) {
                    html += '<div class="yogou_item_sy">'
                    html += '<img src="assets/yuer_is.png" alt="">'
                    html += '</div>'
                }
                
                html += '</div>'
                if (data[i].is_limit == 1) {
                    html += '<img class="yugou_item_star" src="assets/star.png" alt="">'
                }
                html += '</div>'
            }
            $('.yogou_wrap').append(html);
        }
    }

    var number = 1
    // 钓鱼请求接口 type 0超时 1不超时
    function fishing(type) {
        $.ajax({
            type: "GET",
            url: "http://fish.7in6.com/iapi/fishing",
            data: {
                token: localStorage.token,
                type: type,
                bait_id: chooseData.id,
                number: number
            },
            dataType: "json",
            success: function (res) {
                if (res.code == 1) {
                    var html = ''
                    if (res.data.code == 1){
                        html = 
                            '<div class="fish_box">'+
                                '<img class="close" src="assets/xIcon.png" alt="">'+
                                '<div class="isfish_tip">' + res.data.msg + '</div>'+
                                '<img class="isfish_img" src="http://fish.7in6.com' + res.data.img_url + '" alt="">'+
                                '<div class="isfish_money">'+
                                    '<img src="assets/jb2.png" alt="">'+
                                    '<span>' + res.data.gold + '</span>'+
                                '</div>'+
                                '<div class="isfish_do">'+
                                    '<img class="share" src="assets/share2.png" alt="">'+
                                    '<img class="sell" src="assets/sell4.png" data-id="' + res.data.fish_id + '" alt="">' +
                                '</div>'+
                            '</div>'
                    }else{
                        html = 
                            '<div class="fish_box">'+
                                '<img class="close" src="assets/xIcon.png" alt="">'+
                                '<img class="nofish_img" src="assets/nofish.png" alt="">'+
                                '<div class = "nofish_tip" > 好可惜， 鱼儿溜走了... </div>'+
                            '</div>'
                    }
                    $('.fish_window').html(html)
                    if (res.data.bait.length){
                        for (var i = 0; i < res.data.bait.length; i++) {
                            if (res.data.bait[i].id == chooseData.id) {
                                $('.yuer_btn').children('.num').text(res.data.bait[i].amount);
                                $('.yuer_btn img').attr('src', 'http://fish.7in6.com' + res.data.bait[i].img_url_2)
                            }
                        }
                        getYuer()
                    }
                    $('.fish_window').css('display', 'block')
                } else {
                    tips(res.msg,1000)
                }
            }
        });
    }
    //抛竿
    var diaoTime
    var diaoIng = false
    function playFish () {
        console.log(chooseData)
        if (!diaoIng) {
            if (chooseData.amount == 0) {
                tips('鱼饵数量不足',1000)
                return
            }
            diaoIng = true
            diao_music.play()
            $(".yindao_up").css("display", "none");
            $(".yindao_hand").css("display", "none");
            $("#diao_pic").css("display", "none");
            $("#frameAnimImg3").css("display", "none");
            $("#frameAnimImg1").css("display", "block");
            setTimeout(function() {
              $("#frameAnimImg1").css("display", "none");
              $("#frameAnimImg2").css("display", "block");
              $(".box").css("display", "block");
              diaoTime = setTimeout(function() {
                $(".box").css("display", "none");
                $("#frameAnimImg2").css("display", "none");
                $("#frameAnimImg3").css("display", "block");
                setTimeout(function() {
                  $("#frameAnimImg3").css("display", "none");
                  $("#diao_pic").css("display", "block");
                  fishing(0)
                  diaoIng = false
                }, 1000);
              }, 5000);
            }, 5000);
        }
    }
    // 提竿
    $('.box').click(function(){
        click_music.play()
        // out_type = 1
        clearTimeout(diaoTime)
        $(".box").css("display", "none");
        $("#diao_pic").css("display", "none");
        $("#frameAnimImg1").css("display", "none");
        $("#frameAnimImg2").css("display", "none");
        $("#frameAnimImg3").css("display", "block");
        setTimeout(function(){
            $("#frameAnimImg3").css("display", "none");
            $("#diao_pic").css("display", "block");
            diaoIng = false;
            fishing(1);
        },1000)
        // 提竿动画 - 出弹窗
    })

    //上划
    $(".touch_box").on("touchstart", function (e) {
        // 判断默认行为是否可以被禁用
        if (e.cancelable) {
            // 判断默认行为是否已经被禁用
            if (!e.defaultPrevented) {
                e.preventDefault();
            }
        }
        startX = e.originalEvent.changedTouches[0].pageX,
            startY = e.originalEvent.changedTouches[0].pageY;
    });
    $(".touch_box").on("touchend", function (e) {
        // 判断默认行为是否可以被禁用
        if (e.cancelable) {
            // 判断默认行为是否已经被禁用
            if (!e.defaultPrevented) {
                e.preventDefault();
            }
        }
        moveEndX = e.originalEvent.changedTouches[0].pageX,
            moveEndY = e.originalEvent.changedTouches[0].pageY,
            X = moveEndX - startX,
            Y = moveEndY - startY;
        //上滑
        console.log(Y)
        if (Y < -100) {
            playFish()
        }
    });

    //卖鱼
    $('.fish_window').on('click', '.sell', function (e) {
        click_music.play()
        var id = e.currentTarget.dataset.id
        $.ajax({
            type: "GET",
            url: "http://fish.7in6.com/iapi/fishSell",
            data: {
                fish_id: id,
                token: localStorage.token
            },
            dataType: "json",
            success: function (res) {
                if (res.code == 1) {
                    tips('出售成功', 1000)
                    yuData = res.data.fish
                    addShopYuHtml(yuData)
                    $('.all_const span').text(res.data.sum)
                    var num = parseInt(res.data.gold)
                    num = (num).toFixed(0)
                    $('.wrap_gold_num').text(num)
                    $('.gold_num').text(num)
                    $('.fish_window').css('display', 'none')
                } else {
                    tips(res.msg, 1000)
                }
            }
        });
    });

    // 分享鱼
    $('.fish_window').on('click', '.share', function () {
        click_music.play()
        $(".copy_btn").trigger("click");
    });

    // 关闭鱼上钩弹窗
    $('.fish_window').on('click', '.close', function () {
        click_music.play()
        $(".fish_window").css("display", "none");
        
    });


    function getYuer2 (){
        $.ajax({
            type: "GET",
            url: "http://fish.7in6.com/iapi/getUserBait",
            data: {
                token: localStorage.token
            },
            dataType: "json",
            success: function (res) {
                if (res.code == 1) {
                    if (res.data.bait.length) {
                        chooseData = res.data.bait[0]
                        $('.yuer_item').children('div').children('.num').text(chooseData.amount);
                        var text = chooseData.name + '：' + chooseData.amount + '个';
                        $('.yuer_item').children('span').text(text);
                        $('.yuer_item img').attr('src', 'http://fish.7in6.com' + chooseData.img_url_2)
                        $('.yuer_btn').children('.num').text(chooseData.amount);
                        $('.yuer_btn img').attr('src', 'http://fish.7in6.com' + chooseData.img_url_2)
                        
                    }
                } else {
                    tips(res.msg,1000)
                }
            }
        });
    }


    

    // 登录 获取验证码
    $('.login_top .send').click(function () {
        click_music.play()
        phone = $('.login_top input').val()
        $.ajax({
            type: "GET",
            url: "http://fish.7in6.com/api/login/getCode",
            data: {
                phone: phone,
            },
            dataType: "json",
            success: function (res) {
                if (res.status == 200) {
                    tips(res.msg,1000)
                    $(".login_top .nosend").css("display", 'block');
                    $(".login_top .send").css("display", 'none');
                    $(".login_top .send_msg").css("display", 'block');
                    $(".login_top .send_msg").text(60);
                    var countdown = 60; //倒计时秒
                    var timer = null;
                    timer = setInterval(function () {
                        if (countdown > 0 && countdown <= 60) {
                            countdown--;
                            if (countdown !== 0) {
                                $(".login_top .send_msg").text(countdown);
                            } else {
                                clearInterval(timer);
                                $(".login_top .send_msg").css("display", 'none');
                                $(".login_top .nosend").css("display", 'none');
                                $(".login_top .send").css("display", 'block');
                            }
                        }
                    }, 1000)
                }else{
                    tips(res.msg,1000)
                }
            }
        });
    })

    // 登录 提交
    $('.login_tj').click(function () {
        click_music.play()
        phone = $('.login_top input').val()
        var code = $('.login_bottom input').val()
        var token = getUrlParam('token')
        $.ajax({
            type: "GET",
            url: "http://fish.7in6.com/api/login/login",
            data: {
                phone: phone,
                code: code,
                token: token
            },
            dataType: "json",
            success: function (res) {
                if (res.status == 200) {
                    localStorage.token = res.data.token
                    localStorage.id = res.data.id
                    localStorage.is_admin = res.data.is_admin
                    tips(res.msg,1000)
                    $('.login_window').hide()
                    $(".yindao_up").css("display", "block");
                    $('.yindao_hand').css('display','block');
                    if (res.data.is_admin == 1 && getUrlParam("chainId")) {
                        $('.admin_btn').css('display','block')
                    }
                    getYuer2()
                    getLink() // 获取复制链接
                    getUserInfo() // 获取用户信息
                } else {
                    tips(res.msg,1000)
                }
            }
        });
    })        



    
    // 点击金币
    $('.wrap_gold_btn').click(function (e) {
        click_music.play()
        openGoldWindow()
    });

    var polingGold
    // 打开金币弹窗
    function openGoldWindow() {
        getGoldList()
        console.log(isApp,'isApp')
        if (!isApp) {
            getChongzhi()
            polingGold = setInterval(function () {
                $.ajax({
                    type: "GET",
                    url: "http://fish.7in6.com/iapi/getGold",
                    data: {
                        token: localStorage.token
                    },
                    dataType: "json",
                    success: function (res) {
                        if (res.code == 1) {
                            tips('金币充值成功', 1000)
                            var num = parseInt(res.data.gold)
                            num = (num).toFixed(0)
                            $('.wrap_gold_num').text(num)
                            $('.gold_num').text(num)
                        } else {
                            tips(res.msg, 1000)
                        }
                    }
                });
            }, 2000);
        }else{
            getBl()
        }
    }

    // APP内获取比例
    var proportion
    function getBl() {
        $.ajax({
            type: "GET",
            url: "http://fish.7in6.com/iapi/getProportion",
            data: {
                token: localStorage.token
            },
            dataType: "json",
            success: function (res) {
                if (res.code == 1) {
                    proportion = res.data.proportion
                    $('.app_bl span').text(proportion);
                } else {
                    tips(res.msg)
                }
            }
        });
    }

    // 非APP获取充值数据
    var chongzhiData
    function getChongzhi(){
        $.ajax({
            type: "GET",
            url: "http://fish.7in6.com/iapi/ugasToGoldList",
            data: {
                token: localStorage.token
            },
            dataType: "json",
            success: function (res) {
                if (res.code == 1) {
                    chongzhiData = res.data.tab
                    $('.chong_tip3 .tip_left span').text(chongzhiData.to_address);
                    $('.chong_tip5 .tip_left span').text(chongzhiData.note_yards);
                    $('.chong_tip2 span').text(chongzhiData.proportion);
                    $('.chong_code img').attr('src', 'http://fish.7in6.com' + chongzhiData.qrcode);
                } else {
                    tips(res.msg)
                }
            }
        });
    }
    
    // 获取金币兑换列表
    var goldList
    function getGoldList() {
        $.ajax({
            type: "GET",
            url: "http://fish.7in6.com/iapi/goldUgasList",
            data: {
                token: localStorage.token
            },
            dataType: "json",
            success: function (res) {
                if (res.code == 1) {
                    if (res.data.tab.length) {
                        goldList = res.data.tab
                        var html = ''
                        for (var i = 0; i < res.data.tab.length; i++) {
                            html +=
                            '<div class="gold_item" data-index="' + i + '">'+
                                '<div class="gold_item_top">'+
                                    '<span>' + res.data.tab[i].ugas + '</span> ugas' +
                                '</div>'+
                                '<div class="gold_item_btn">'+
                                    '<span>' + res.data.tab[i].gold + '</span>'+
                                '</div>'+
                            '</div>'
                        }
                        $('.gold_item_box').html(html)
                        $('.gold_window').css('display', 'block');
                    }
                } else {
                    tips(res.msg)
                }
            }
        });
    }

    // 兑换填写地址弹窗 提交
    $('.add_tj').click(function () {
        click_music.play()
        phone = $('.add_top input').val()
        var code = $('.add_bottom input').val()
        var address = $('.add_address input').val()
        var goldid = chooseGlod.id
        var data = {
            phone: phone,
            code: code,
            address: address,
            goldid: goldid,
            token: localStorage.token
        }
        $.ajax({
            type: "GET",
            url: "http://fish.7in6.com/iapi/userwalletad",
            data: data,
            dataType: "json",
            success: function (res) {
                if (res.code == 1) {
                    tips('兑换成功',1000)
                    var num = parseInt(res.data.goldnow)
                    num = (num).toFixed(0)
                    $('.wrap_gold_num').text(num)
                    $('.gold_num').text(num)
                    $('.add_window').css('display', 'none');
                } else {
                    tips(res.msg, 1000)
                }
            }
        });
    })
    

    // 复制转入地址
    $('.chong_tip3 .tip_right').click(function(){
        click_music.play();
        var text = $('.chong_tip3 .tip_left span').text();
        copyText(text)
    });

    // 复制备注码
    $('.chong_tip5 .tip_right').click(function () {
        click_music.play();
        var text = $('.chong_tip5 .tip_left span').text();
        copyText(text)
    });

    //输入充值数量
    var goldNum
    var ugasNum
    $('.app_left input').on('input', function () {
        goldNum = $(this).val()
        ugasNum = (goldNum / proportion).toFixed(4)
        ugas_text = ugasNum + ' UGAS'
        var ugas = (goldNum / proportion).toFixed(0)
        $('.app_right span').text(ugas)
    });

    // 输入失焦
    $('.app_left input').on("blur", function () {
        window.scroll(0, 0);
    });

    // 充值提交
    $('.app_tj').click(function(){
        data1 = {}
        postData = {}
        data1["receiver"] = "haiyang333"; //商户账号
        data1["quantity"] = ugas_text; //数量单位ugas_text"2.0000 UGAS"
        data1["memo"] = "test";
        postData["chainId"] = getUrlParam("chainId");
        postData["contract"] = "utrio.token"; //合约账号
        postData["action"] = "transfer"; //动作类型
        postData["type"] = "transfer"; //转账类型
        postData["bizId"] = getOrderId(); //业务id
        postData["data"] = data1;
        postData = JSON.stringify(postData);
        if (window.postMessage) {
            window.postMessage(postData);
        } else {
            throw Error('postMessage接口还未注入');
        }
    });

    //监听转账回执消息
    document.addEventListener("message", receiveMessage, false);
    function receiveMessage(e) {
        var data = JSON.parse(e.data)
        if (data.success) {//转账成功
            $.ajax({
                type: "GET",
                url: "http://fish.7in6.com/iapi/ugas_to_gold_forapp",
                data: {
                    token: localStorage.token,
                    gold: goldNum,
                    ugas: ugasNum,
                    bizid: data.bizId
                },
                dataType: "json",
                success: function (res) {
                    if (res.code == 1) {
                        if (res.data.code == 1) {
                            tips('充值成功', 2000)
                            var num = parseInt(res.data.gold)
                            num = (num).toFixed(0)
                            $('.wrap_gold_num').text(num)
                            $('.gold_num').text(num)
                        } else {
                            tips(res.msg, 1000)
                        }
                    } else {
                        tips(res.msg, 1000)
                    }
                }
            });
        }else{
            tips(data.msg, 2000)
        }
    }

    //获取业务ID
    function getOrderId() {
        var myDate = new Date;
        var year = myDate.getFullYear(); //获取当前年
        var mon = myDate.getMonth() + 1; //获取当前月
        var date = myDate.getDate(); //获取当前日
        var h = myDate.getHours(); //获取当前小时数(0-23)
        var m = myDate.getMinutes(); //获取当前分钟数(0-59)
        var s = myDate.getSeconds(); //获取当前秒
        var x = 9999;
        var y = 1000;
        var rand = parseInt(Math.random() * (x - y + 1) + y);
        var result = year + isGtTen(mon) + isGtTen(date) + isGtTen(h) + isGtTen(m) + isGtTen(s) + rand;
        return result;
    }
    function isGtTen(val) {
        if (val == '' || val == undefined) {
            return;
        }
        if (val < 10) {
            return '0' + val;
        }
        return val;
    }

    //获取URL参数方法
    function getUrlParam(name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
        var r = window.location.search.substr(1).match(reg); //匹配目标参数
        if (r != null) return unescape(r[2]);
        return null; //返回参数值
    }
    

    var chooseGlod
    // 兑换填写地址弹窗 打开
    $('.gold_item_box').on('click', '.gold_item', function (e) {
        click_music.play();
        var index = e.currentTarget.dataset.index;
        chooseGlod = goldList[index]
        $('.add_window').css('display', 'block');
    });
    
    // 兑换填写地址弹窗 关闭
    $('.add_window .close').click(function () {
        click_music.play();
        $('.add_window').css('display', 'none');
    });

    // 兑换填写地址弹窗 获取验证码
    $('.add_top .send').click(function () {
        click_music.play()
        phone = $('.add_top input').val()
        $.ajax({
            type: "GET",
            url: "http://fish.7in6.com/api/login/getCode",
            data: {
                phone: phone,
            },
            dataType: "json",
            success: function (res) {
                if (res.status == 200) {
                    tips(res.msg,1000)
                    $(".add_top .nosend").css("display", 'block');
                    $(".add_top .send").css("display", 'none');
                    $(".add_top .send_msg").css("display", 'block');
                    $(".add_top .send_msg").text(60);
                    var countdown = 60; //倒计时秒
                    var timer = null;
                    timer = setInterval(function () {
                        if (countdown > 0 && countdown <= 60) {
                            countdown--;
                            if (countdown !== 0) {
                                $(".add_top .send_msg").text(countdown);
                            } else {
                                clearInterval(timer);
                                $(".add_top .send_msg").css("display", 'none');
                                $(".add_top .nosend").css("display", 'none');
                                $(".add_top .send").css("display", 'block');
                            }
                        }
                    }, 1000)
                } else {
                    tips(res.msg,1000)
                }
            }
        });
    })


    // 金币弹窗tab切换
    $(".gold_tabs .btn_left").click(function () {
        click_music.play();
        $(".gold_tabs .left1").css("display", "none");
        $(".gold_tabs .left2").css("display", "block");
        $(".gold_tabs .right1").css("display", "block");
        $(".gold_tabs .right2").css("display", "none");
        $(".gold_chong").css("display", "block");
        $(".gold_dui").css("display", "none");
    });
    $(".gold_tabs .btn_right").click(function () {
        click_music.play();
        $(".gold_tabs .left1").css("display", "block");
        $(".gold_tabs .left2").css("display", "none");
        $(".gold_tabs .right1").css("display", "none");
        $(".gold_tabs .right2").css("display", "block");
        $(".gold_chong").css("display", "none");
        $(".gold_dui").css("display", "block");
    });
    

    // 关闭金币弹窗
    $('.gold_window .close').click(function (e) {
        e.stopPropagation
        click_music.play()
        $('.gold_window').css('display', 'none')
        clearInterval(polingGold)
    })

    // 轻提示弹窗
    function tips(msg,time){
        time = time ? time : 1000
        $('.tips_window').css('display', 'block')
        $('.tips_window .words').text(msg)
        setTimeout(function () {
            $('.tips_window').css('display', 'none')
        }, time)
    }

    // 跳转下载
    $('.login_words').click(function (e) {
        window.open('https://developer.ultrain.io/shareSoftware?language=zh');
    });
    $('.chong_tip4').click(function (e) {
        window.open('https://developer.ultrain.io/shareSoftware?language=zh');
    });

    // 跳转管理员审核页面
    $('.admin_btn').click(function(e){
        window.location.href = 'http://fish-game.7in6.com/examine/index.html?chainId=' + getUrlParam("chainId");
    })

    
    // 打开组队弹窗
    $('.group_btn').click(function (e) {
        e.stopPropagation()
        click_music.play()
        $('.group_window').css('display', 'block');
        $('.group_btn_box .out').css('display', 'none')
        $('.group_btn_box .pipei').css('display', 'block')
    });

    $('.group_hand').click(function (e) {
        e.stopPropagation()
        click_music.play()
        $('.group_window').css('display', 'block');
        $('.group_btn_box .out').css('display', 'block')
        $('.group_btn_box .pipei').css('display', 'none')
    });

    // 关闭组队弹窗
    $('.group_window .close').click(function () {
        click_music.play()
        $('.group_window').css('display', 'none')
    })
    
    // 组队匹配
    $('.group_btn_box .pipei').click(function (e) {
        click_music.play()
        isClose = false
        connect()
        tips('匹配中...',5000)
    });

    // 退出组队
    $('.group_btn_box .out').click(function (e) {
        click_music.play()
        isClose = true
        ws.close()
        $('.input_wrap').css('display', 'none')
        $('.group_window').css('display', 'none');
        $('.group_btn').css('display', 'block');
        $('.group_hand').css('display', 'none');
        $('.chat_window').css('display', 'none');
        $('.group_item').empty()
        $('.group_gl .gl').text('+ 0%')
        $('.group_gl .num').text('单人')
    });

    // 聊天发送
    $('.input_btn').click(function (e) {
        click_music.play();
        var val = $('.input_wrap input').val()
        if (val != '') {
            //发送数据
            var send_data = val;
            var data = {};
            data["type"] = "say";
            data["room"] = room;
            data["content"] = send_data;
            var sendData = JSON.stringify(data);
            ws.send(sendData);
            $('.input_wrap input').val("");
        }
    });
    $('.input_wrap input').on("blur", function () {
        window.scroll(0, 0);
    });


    var timers = []
    function createScreenbullet(text) {
        var jqueryDom = $("<div class='bullet'>" + text + "</div>");
        var left = $(".screen_container").width() + "px";
        var top = Math.floor(Math.random() * 10) + "rem";
        top = parseInt(top) > 10 ? "10rem" : top;
        jqueryDom.css({
            "position": 'absolute',
            "color": '#fff',
            "font-size": '1rem',
            "left": left,
            "top": top,
            "white-space":"nowrap",
            "text-shadow": "-0.0625rem 0 0.0625rem #6c8099",
        });
        $(".screen_container").append(jqueryDom);
        return jqueryDom;
    }

    function addInterval(jqueryDom) {
        var left = jqueryDom.offset().left - $(".screen_container").offset().left;
        var timer = setInterval(function () {
            left--;
            jqueryDom.css("left", left + "px");
            if (jqueryDom.offset().left + jqueryDom.width() < $(".screen_container").offset().left) {
                jqueryDom.remove();
                clearInterval(timer);
            }
        }, 10);
        timers.push(timer);
    }
    
    // 接入聊天
    var ws,room;
    var isClose = false
    function connect() {
        // 创建websocket
        ws = new WebSocket("ws://fish.7in6.com:9090");
        // 当socket连接打开时，发送登录信息
        ws.onopen = function () {
            var uid = localStorage.id
            var name = "wwwdsdd";
            var login_data = '{"type":"login","client_name":"' + name.replace(/"/g, '\\"') + '","uid":"' + uid + '"}';
            console.log("websocket握手成功，发送登录数据:" + login_data);
            ws.send(login_data);
            ws.send('tom');
            ws.send('保持连接，发第二次信息，查看服务器回应');
            ws.onmessage = function (e) {
                var str = JSON.parse(e.data);                    
                if (str.type == 'login') {
                    var content = ''
                    room = str.room
                    // var probability = (str.probability - 1).toFixed(2) * 100
                    // var probability2 = probability + '%'
                    // if (probability > 0 || probability == 0) {
                    //     $('.group_gl .gl').text(' + ' + probability2)
                    // }else{
                    //     $('.group_gl .gl').text(' ' + probability2)
                    // }
                    var text = '单人'
                    var gl = '+ 0%'
                    switch (str.peopleNum) {
                        case 1:
                            text = '单人'
                            gl = '+ 0%'
                        break;
                        case 2:
                            text = '双人'
                            gl = '+ 15%'
                        break;
                        case 3:
                            text = '三人'
                            gl = '+ 25%'
                        break;
                        case 4:
                            text = '四人'
                            gl = '+ 25%'
                        break;
                        case 5:
                            text = '五人'
                            gl = '+ 25%'
                        break;
                    }
                    $('.group_gl .gl').text(gl)
                    $('.group_gl .num').text(text)
                    number = str.peopleNum
                    var hand = str.headimgurl
                    var html = ''
                    for (var i = 0; i < hand.length; i++) {
                        html = '<img src="http://fish.7in6.com' + hand[i] + '" alt="">'
                        $('.group_item_box' + ' .group_item:eq(' + i + ')').html(html)
                        $('.group_hand' + ' .hand_item:eq(' + i + ')').html(html)
                    }
                    setTimeout(function(){
                        content = str.content;
                        $('.input_wrap').css('display', 'block')
                        $('.group_window').css('display', 'none');
                        $('.group_btn').css('display', 'none');
                        $('.group_hand').css('display', 'block');
                        $('.chat_window').css('display', 'block');
                        var jqueryDom = createScreenbullet(content);
                        addInterval(jqueryDom);
                    },5000)
                    
                } else if (str.type == 'say') {
                    var content = '用户' + uid + '：' + str.content;
                    var jqueryDom = createScreenbullet(content);
                    addInterval(jqueryDom);
                } else {
                    console.log('else-----')
                }
                
            };
        };
        // 当有消息时根据消息类型显示不同信息
        ws.onmessage = onmessage;
        ws.onclose = function () {
            if(!isClose){
                console.log("连接关闭，定时重连");
                connect();
            }
        };
        ws.onerror = function () {
            console.log("出现错误");
        };
    }
})
