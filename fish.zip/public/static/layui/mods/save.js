layui.define(['jquery','layer'], function (mods) {
    'use strict';
    var form,
    $ = layui.jquery,
    layer = layui.layer,
    func = {
        /**
         * input正则验证
         */
        inputvali: function (exp, name, msg, bool) {
            bool = bool || false;

            var el = form.find('[name="' + name + '"]');
            if (bool) {
                // 必填
                if (el.val() === '' || el.val() === null) {
                    this.tips(el, msg);
                    el = null;
                    return true;
                }
                if ((new RegExp(exp)).test(el.val())) { el = null; return false }
            } else {
                // 非必填
                if (el.val() === '' || el.val() === null) {
                    el = null;
                    return false;
                }
                if ((new RegExp(exp)).test(el.val())) { el = null; return false }
            }

            this.tips(el, msg);
            el = null;
            return true;
        },

        /**
         * input非空验证
         */
        inputNotEmpty:function(name){
            var el = form.find('[name="' + name + '"]');
            if(el.val() === '' || el.val() === null){
                this.tips(el,'内容不能为空');
                el = null;
                return true;
            }

            return false;
        },

        /**
         * select验证
         */
        selectvali:function (name, msg, bool) {
            bool = (bool === false) ? bool : true;
            var el = form.find('[name="' + name + '"]');
            var val = el.find(':selected').val();

            if(bool){
                if (val === '') {
                    this.tips(el,msg);
                    el = null;
                    return true;
                }
            } else {
                if (val === '') {
                    el = null;
                    return false;
                }
            }
    
            el = null;
            return false;
        },

        /**
         * 城市验证
         */
        cityvali:function(names,bool){
            bool = bool || false;
            var el = form.find('[name="' + names[0] + '"]');

            if(bool){
                if(el.find(':selected').val() === ''){
                    this.tips(el,'请选择城市');
                    return true;
                } else if(this.selectvali(names[1],'请选择城市')) {
                    return true;
                }
            } else {
                if (el.find(':selected').val() === '') {
                    return false;
                } else if(this.selectvali(names[1],'请选择城市')) {
                    return true;
                }
            }
    
            return false;
        },

        /**
         * 定位滚动条弹出tips
         */
        tips:function(el,msg){
            // 滚动条定位
            $('html').animate({
                scrollTop:el.offset().top - $(window).height() / 2
            },{
                duration:400,
                complete:function(){
                    layer.tips(msg,el,{time:2000,tips:2});
                }
            });
        },
        out:function(){
            form = null;
            return false;
        },

        /**
         * 绑定input/select数据
         */
        ISToData:function(names,data,type){
            type = (type === 'select') ? true : false;

            for(var i = 0,name;name = names[i++];){
                data[name] = type ? $('[name="' + name + '"] :selected').val() : $('[name="' + name + '"]').val();
            }
        },

        /**
         * 绑定city数据
         */
        cityToData:function(obj,data){
            var city;
            for(var i = 0,arr;arr = obj[i++];){
                city = [];
                for(var j = 0,name;name = arr.name[j++];){
                    city.push($('[name="'+name+'"] :selected').val());
                }
                data[arr.tag] = city.join(',');
            }
        },

        /**
         * msg弹窗
         */
        msg:function(msg,time,icon){
            layer.msg(msg,{time:time,icon:icon});
        }
    };

    /**
     * 基础信息保存按钮
     */
    $('.info-save').click(function () {
        var data = {};
        form = $('#form1');
        
        if(!validate()) return false;

        // 绑定普通input
        func.ISToData([
            'name','qq','weixin','email','phone2','teaching_school','birth','alma_mater','major_jt','des'
        ],data,'input');

        // 绑定城市数据
        func.cityToData([
            {name:['city1','city2'],tag:'city'},
            {name:['summer_city1','summer_city2'],tag:'summer_city'},
            {name:['winter_city1','winter_city2'],tag:'winter_city'},
            {name:['ex_city1','ex_city2'],tag:'ex_city'},
            {name:['native_place1','native_place2'],tag:'native_place'},
        ],data);

        // 绑定下拉框数据
        func.ISToData([
            'grade','account','home','role','t_age','major'
        ],data,'select');

        // 绑定性别
        data.sex = $('[name="sex"]:checked').val();

        data.school = (function(){
            var data = [
                $('[name="school1"] :selected').val(),
                $('[name="school2"] :selected').val(),
                $('[name="school"] :selected').val(),
            ].join(',');
            return data;
        }());

        $.ajax({
            url:layui.cache.saveurl,
            type:'put',
            data:data,
            dataType:'json'
        }).done(function(res){
            if(res.code === 0){
                func.msg(res.msg,1500,1);
            }else if(res.code === 1){
                func.msg(res.msg,1500,2);
            }else{
                func.msg('发生未知错误',1500,2);
            }
        });
    });

    // 数据验证
    var validate = function(){
        // 验证姓名
        if (func.inputvali(/^[\u4e00-\u9fa5]{2,6}$/, 'name', '姓名由2-6个中文组成',true)) return func.out();

        // 验证QQ
        if (func.inputvali(/^[\d]{5,10}$/, 'qq', 'QQ号由5-10个数字组成')) return func.out();

        // 微信号验证
        if (func.inputvali(/^[a-z][\w-]{5,19}$/i, 'weixin', '请输入正确的微信号')) return func.out();

        // 邮箱验证
        if (func.inputvali(/^[\u4e00-\u9fa5\w\.+-]+@[\u4e00-\u9fa5a-z\d-]+(\.[\u4e00-\u9fa5a-z\d-]+)*\.([a-z]+|[\u4e00-\u9fa5]+)$/i, 'email', '请输入正确的邮箱')) return func.out();

        // 备用手机号验证
        if (func.inputvali(/^1(3\d|4[579]|5[0-35-9]|6[016]|7[034678]|8\d|9[89])\d{8}$/, 'phone2', '请输入正确的手机号')) return func.out();

        // 所在城市验证
        if (func.cityvali(['city1','city2'],true)) return func.out();

        // 暑假城市验证
        if (func.cityvali(['summer_city1','summer_city2'])) return func.out();

        // 寒假城市验证
        if (func.cityvali(['winter_city1','winter_city2'])) return func.out();

        // 学校城市验证
        if (func.cityvali(['school1','school2'],true)) return func.out();
        
        // 学校验证
        if(func.selectvali('school','请选择学校')) return func.out();

        // 高考所在地验证
        if (func.cityvali(['ex_city1','ex_city2'])) return func.out();

        // 出生年月验证
        // if (func.inputvali(/^\d{4}-\d{2}-\d{2}$/,'birth','出生年月不正确',true)) return func.out();

        // 专业选择验证
        if (func.selectvali('major','请选择专业')) return func.out();

        // 具体专业验证
        if (func.inputNotEmpty('major_jt')) return func.out();

        // 目前住所验证
        if (func.selectvali('home','请选择住所')) return func.out();

        // 验证个人描述
        if(func.inputNotEmpty('des','请填写个人描述')) return func.out();

        form = null;
        return true;
    }

    mods('save', { info: '老师信息保存验证' });
});