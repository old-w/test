if (!window.bizr2Version) {
    window.bizr2Version = {}
}
window.bizr2Version["tools-cs"] = "1.0.8";
window.undefined = window.undefined;
Tools = {};
Tools.attchEvent = function (e, c, b, a) {
    var d = function () {
        b.call(e, a)
    };
    if (window.attachEvent) {
        e.attachEvent("on" + c, d)
    } else {
        e.addEventListener(c, d, false)
    }
};
Tools.Div = function (e, d) {
    var c = Math.round(e);
    var b = Math.round(d);
    var a = c / b;
    if (a >= 0) {
        a = Math.floor(a)
    } else {
        a = Math.ceil(a)
    }
    return a
};
Tools.accDiv = function (arg1, arg2) {
    var t1 = 0, t2 = 0, r1, r2;
    try {
        t1 = arg1.toString().split(".")[1].length
    } catch (e) {
    }
    try {
        t2 = arg2.toString().split(".")[1].length
    } catch (e) {
    }
    with (Math) {
        r1 = Number(arg1.toString().replace(".", ""));
        r2 = Number(arg2.toString().replace(".", ""));
        return (r1 / r2) * pow(10, t2 - t1)
    }
};
Tools.accMul = function (d, b) {
    var a = 0, f = d.toString(), c = b.toString();
    try {
        a += f.split(".")[1].length
    } catch (g) {
    }
    try {
        a += c.split(".")[1].length
    } catch (g) {
    }
    return Number(f.replace(".", "")) * Number(c.replace(".", "")) / Math.pow(10, a)
};
Tools.accAdd = function (f, d) {
    var c, b, a;
    try {
        c = f.toString().split(".")[1].length
    } catch (g) {
        c = 0
    }
    try {
        b = d.toString().split(".")[1].length
    } catch (g) {
        b = 0
    }
    a = Math.pow(10, Math.max(c, b));
    return (f * a + d * a) / a
};
Tools.setCookie = function (a, b) {
    args = arguments;
    if (args[2] == 1) {
        document.cookie = a + "=" + b
    } else {
        document.cookie = a + "=" + escape(b)
    }
};
Tools.getCookie = function (name) {
    var strs = document.cookie;
    var ind = strs.indexOf(name + "=");
    if (ind >= 0) {
        end = strs.indexOf(";", ind);
        newStr = strs.substring(strs.indexOf("=", ind) + 1, (end < 0 ? strs.length : end));
        var value = unescape(newStr);
        if (value.charAt(0) == "{" && value.charAt(value.length - 1) == "}") {
            eval("value=" + value)
        }
        return value
    } else {
        return ""
    }
};
Tools.closeWindow = function (a) {
    if (!a) {
        a = window
    }
    a.opener = null;
    a.open("", "_self");
    a.close()
};
Tools.getUrlValue = function (a) {
    var c = window.location.search;
    if (c.length > 1) {
        c = c.substring(1)
    } else {
        return ""
    }
    var d = c.split("&");
    for (var b = 0; b < d.length; b++) {
        var f = d[b];
        var e = f.split("=");
        if (e.length > 1 && e[0] == a) {
            return e[1]
        }
    }
};
Tools.makeChars = function (a, c) {
    var d = "";
    for (var b = 0; b < a; b++) {
        d += c
    }
    return d
};
Tools.moneyStr = function (h) {
    h = $.trim(h);
    if (h == null || h == "" || h == "null" || h == Infinity) {
        return "0.00"
    }
    var g = (h + "").split(".");
    var f = g[0];
    if (!f || isNaN(f)) {
        f = "0"
    }
    var b = g[1];
    if (!b) {
        b = "00"
    } else {
        if (b.length > 2) {
            b = b.substr(0, 2)
        } else {
            if (b.length < 2) {
                b = Tools.padRight(b, 2, "0")
            }
        }
    }
    var a;
    if (f.substr(0, 1) == "-") {
        f = f.substr(1);
        a = "-"
    } else {
        a = ""
    }
    var e = f.length;
    for (var c = e - 3; c > 0; c -= 3) {
        f = f.substr(0, c) + "," + f.substr(c)
    }
    return a + f + "." + b
};
Tools.formatDecimal = function (j, g, l) {
    var m = "";
    if (g) {
        m = Tools.makeChars(g, "0")
    }
    if (j == null || j == "" || j == "null") {
        return Number("0." + m)
    }
    if (/^(([+-]?\d+.?\d*)[Ee]{1}([+-]?\d+))$/.test(j)) {
        j = new Number(j)
    }
    var b = (j + "").split(".");
    var c = b[0];
    if (!c || isNaN(c)) {
        c = "0"
    }
    var h = c;
    if (l) {
        var a = h.length;
        for (var f = a - 3; f > 0; f -= 3) {
            h = h.substr(0, f) + "," + h.substr(f)
        }
    }
    if (g == 0) {
        return (l ? h : Number(c))
    }
    var e = b[1];
    if (!e) {
        e = m
    } else {
        if (g == null) {
            e = Tools.padRight(e, 2, "0")
        } else {
            if (g > 0) {
                if (e.length > g) {
                    e = e.substr(0, g)
                } else {
                    if (e.length < g) {
                        e = Tools.padRight(e, g, "0")
                    }
                }
            }
        }
    }
    if (e == "") {
        e = "00"
    }
    if (l) {
        return h + "." + e
    } else {
        return Number(c + "." + e)
    }
};
Tools.strIsEmpty = function (a) {
    if (a == null || a == undefined || a == "") {
        return true
    }
    return false
};
Tools.isTime = function (c) {
    c = Tools.trim(c);
    if (c.length != 4) {
        return false
    }
    var a = Number(c.substr(0, 2));
    var b = Number(c.substr(2, 2));
    if (isNaN(a) || isNaN(b)) {
        return false
    }
    if (a > 23 || a < 0 || b > 59 || b < 0) {
        return false
    }
    return true
};
Tools.isTime6 = function (d) {
    d = Tools.trim(d);
    var a, b, c;
    if (d.length != 4 && d.length != 6) {
        return false
    }
    a = Number(d.substr(0, 2));
    b = Number(d.substr(2, 2));
    if (d.length == 6) {
        c = Number(d.substr(4, 2))
    } else {
        c = 0
    }
    if (isNaN(a) || isNaN(b) || isNaN(c)) {
        return false
    }
    if (a > 23 || a < 0 || b > 59 || b < 0 || c > 59 || c < 0) {
        return false
    }
    return true
};
Tools.timeRangeFormatGb = function (d) {
    var c = d.split("-");
    if (c.length != 2 || !Tools.isTime(c[0]) || !Tools.isTime(c[1])) {
        return d
    }
    var b = Tools.trim(c[0]);
    var a = Tools.trim(c[1]);
    return b.substr(0, 2) + "时" + b.substr(2, 2) + "分" + " 至 " + +a.substr(0, 2) + "时" + a.substr(2, 2) + "分"
};
Tools.timeRangeFormat = function (d) {
    var c = d.split("-");
    if (c.length != 2 || !Tools.isTime(c[0]) || !Tools.isTime(c[1])) {
        return d
    }
    var b = Tools.trim(c[0]);
    var a = Tools.trim(c[1]);
    return b.substr(0, 2) + ":" + b.substr(2, 2) + " - " + +a.substr(0, 2) + ":" + a.substr(2, 2)
};
Tools.dateFormat = function (a) {
    if (a) {
        if (a.length == 8) {
            return a.substr(0, 4) + "-" + a.substr(4, 2) + "-" + a.substr(6, 2)
        }
    }
    return a
};
Tools.dateFormatGb = function (a) {
    if (a) {
        if (a.length == 8) {
            return a.substr(0, 4) + "年" + a.substr(4, 2) + "月" + a.substr(6, 2) + "日"
        }
    }
    return a
};
Tools.dateFormater = function (c) {
    if (typeof c == "string") {
        if (c.length == 8) {
            return c.substr(0, 4) + "-" + c.substr(4, 2) + "-" + c.substr(6)
        }
        return c
    } else {
        var e = c.getFullYear(), a = c.getMonth() + 1, b = c.getDate();
        if (a < 10) {
            a = "0" + a
        }
        if (b < 10) {
            b = "0" + b
        }
        return String(e) + "-" + String(a) + "-" + String(b)
    }
};
Tools.timeFormat = function (a) {
    if (a) {
        if (a.length == 6) {
            return a.substr(0, 2) + ":" + a.substr(2, 2) + ":" + a.substr(4, 2)
        }
        if (a.length == 4) {
            return a.substr(0, 2) + ":" + a.substr(2, 2)
        }
    }
    return a
};
Tools.datetimeFormat = function (b) {
    if (b) {
        b = String(b);
        var a = b.split(" ");
        if (a.length == 2) {
            return Tools.dateFormat(a[0]) + " " + Tools.timeFormat(a[1])
        }
    }
    return b
};
Tools.firstDayOfCurrMonth = function () {
    var a = new Date();
    var b = a.getFullYear();
    var c = Tools.padLeft(a.getMonth() + 1, 2, "0");
    return b + "-" + c + "-01"
};
Tools.firstDayOfCurrYear = function () {
    var a = new Date();
    var b = a.getFullYear();
    return b + "-01-01"
};
Tools.dateAddMonth = function (c, b) {
    if (typeof c == "string") {
        c = Tools.str2Date(c)
    }
    var a = new Date(c.getTime());
    a.setMonth(Tools.accAdd(a.getMonth(), b));
    return a
};
Tools.dateAddDay = function (b, c) {
    if (typeof b == "string") {
        b = Tools.str2Date(b)
    }
    var a = new Date(b.getTime());
    a.setDate(Tools.accAdd(a.getDate(), c));
    return a
};
Tools.substr = function (f, b) {
    if (!f || !b) {
        return ""
    }
    var c = 0;
    var e = 0;
    var d = "";
    var b = Tools.gblen(f);
    for (e = 0; e < b; e++) {
        if (f.charCodeAt(e) > 255) {
            c += 2
        } else {
            c++
        }
        if (c > b) {
            return d
        }
        d += f.charAt(e)
    }
    return f
};
Tools.gblen = function (b) {
    var a = 0;
    if (!b) {
        return 0
    }
    if (typeof b !== "string") {
        return 0
    }
    for (var c = 0; c < b.length; c++) {
        if (b.charCodeAt(c) > 127 || b.charCodeAt(c) == 94) {
            a += 2
        } else {
            a++
        }
    }
    return a
};
Tools.gbtrim = function (c, a, e) {
    var g = "";
    var f = e || "";
    var b = 0;
    for (var d = 0; d < c.length; d++) {
        if (c.charCodeAt(d) > 127 || c.charCodeAt(d) == 94) {
            b += 2
        } else {
            b++
        }
    }
    if (b <= a) {
        return c
    }
    b = 0;
    a = (a > f.length) ? a - f.length : a;
    for (var d = 0; d < c.length; d++) {
        if (c.charCodeAt(d) > 127 || c.charCodeAt(d) == 94) {
            b += 2
        } else {
            b++
        }
        if (b > a) {
            g += f;
            break
        }
        g += c.charAt(d)
    }
    return g
};
Tools.trim = function (a) {
    if (a == null || a == "") {
        return ""
    }
    if (typeof a != "string") {
        a = String(a)
    }
    return a.replace(/(^\s*)|(\s*$)/g, "")
};
Tools.padLeft = function (f, a, e) {
    var c = f + "";
    var b = f + "";
    if (f.length == 0) {
        return f
    }
    for (var d = Tools.gblen(c); d < a; d++) {
        b = e + b
    }
    return b
};
Tools.padRight = function (f, a, e) {
    var c = f + "";
    var b = f + "";
    if (f.length == 0) {
        return f
    }
    for (var d = Tools.gblen(c); d < a; d++) {
        b = b + e
    }
    return b
};
Tools.htmlEncodeObject = function (c) {
    var b;
    if (c instanceof Array) {
        b = [];
        for (var a = 0; a < c.length; a++) {
            if (typeof c[a] == "string") {
                b[a] = Tools.htmlEncode(c[a])
            } else {
                b[a] = Tools.htmlEncodeObject(c[a])
            }
        }
    } else {
        if (typeof c == "object") {
            b = {};
            for (key in c) {
                if (typeof c[key] == "string") {
                    b[key] = Tools.htmlEncode(c[key])
                } else {
                    b[key] = Tools.htmlEncodeObject(c[key])
                }
            }
        } else {
            return c
        }
    }
    return b
};
Tools.htmlEncode = function (b) {
    if (b === null || b === undefined || b === "") {
        return b
    }
    var c = document.createElement("DIV");
    if (c.innerText == null) {
        c.textContent = b
    } else {
        c.innerText = b
    }
    var a = c.innerHTML;
    c = null;
    return a
};
Tools.htmlDecode = function (b) {
    if (b === null || b === undefined || b === "") {
        return b
    }
    var c = document.createElement("DIV");
    c.innerHTML = b;
    var a;
    if (c.innerText == null) {
        a = c.textContent
    } else {
        a = c.innerText
    }
    c = null;
    if (a == "undefined") {
        a = ""
    }
    return a
};
Tools.br2nl = function (a) {
    return a.replace(/\<br \/>/g, "\n")
};
Tools.nl2br = function (a) {
    return a.replace(/\r\n/g, "<br />")
};
Tools.urlEncode = function (a) {
    return encodeURIComponent(a)
};
Tools.urlDecode = function (a) {
    return decodeURIComponent(a)
};
Tools.MD5 = function (a) {
    return hex_md5(a)
};
Tools.includeCss = function (b) {
    var a = document.createElement("link");
    a.setAttribute("rel", "stylesheet");
    a.setAttribute("type", "text/css");
    a.setAttribute("href", b);
    document.getElementsByTagName("head")[0].appendChild(a)
};
Tools.addStyle = function (b) {
    var a;
    if (document.all) {
        a = document.createStyleSheet();
        a.cssText = b
    } else {
        a = document.createElement("style");
        a.type = "text/css";
        a.textContent = b
    }
    try {
        document.getElementsByTagName("head")[0].appendChild(a)
    } catch (c) {
    }
};
Tools.apply = function (b, d) {
    if (b == null) {
        b = {}
    }
    if (b && d && typeof d == "object") {
        for (var a in d) {
            b[a] = d[a]
        }
    }
    return b
};
Tools.applyIf = function (b, d) {
    if (b == null) {
        b = {}
    }
    if (b && d && typeof d == "object") {
        for (var a in d) {
            if (b[a] === undefined) {
                b[a] = d[a]
            }
        }
    }
    return b
};
Tools.arrayRemove = function (b, c) {
    if (!Tools.isArray(c)) {
        c = [c]
    }
    for (var d = 0; d < c.length; d++) {
        var a = Tools.indexOfArray(b, c[d]);
        if (a > -1) {
            b.splice(a, 1)
        }
    }
    return b
};
Tools.loadingTip = function (c) {
    var a = null;
    if (window.frameElement) {
        a = window.parent.$(window.parent.document.body)
    } else {
        a = $(document.body)
    }
    var b = a.find(".tools-loadtip-div");
    if (b.length == 0) {
        if (window.frameElement) {
            b = window.parent.$('<div class="tools-loadtip-div" ></div>')
        } else {
            b = $('<div class="tools-loadtip-div" ></div>')
        }
        a.append(b)
    }
    b.text(c);
    b.animate({top: "0px"}, 100)
};
Tools.unloadingTip = function () {
    var a = null;
    if (window.frameElement) {
        a = window.parent.$(window.parent.document.body)
    } else {
        a = $(document.body)
    }
    var b = a.find(".tools-loadtip-div");
    if (b.length > 0) {
        b.animate({top: "-38px"}, 100)
    }
};
Tools.mask = function (c, b) {
    if (b == null) {
        if (Tools.maskMask == null) {
            Tools.maskMask = Tools.makeMask($('<div class="tools-mask-div panel"></div>'), null, true)
        }
        Tools.maskMask.obj.text(c);
        Tools.maskMask.show()
    } else {
        var a = $(b).data("tools-mask");
        if (a == null) {
            a = Tools.makeMask($('<div class="tools-mask-div panel"></div>'), null, true, b);
            $(b).data("tools-mask", a)
        }
        a.obj.text(c);
        a.show()
    }
};
Tools.unmask = function (b) {
    if (b == null) {
        if (Tools.maskMask == null) {
            return
        }
        Tools.maskMask.hide()
    } else {
        var a = $(b).data("tools-mask");
        if (a == null) {
            return
        }
        a.hide();
        $(b).removeData("tools-mask");
        a.remove()
    }
};
Tools.Msg = {
    ERROR: "/static/admin/file/images/icon-error.gif",
    INFO: "/static/admin/file/images/icon-info.gif",
    QUESTION: "/static/admin/file/images/icon-question.gif",
    WARNING: "/static/admin/file/images/icon-warning.gif"
};
Tools.maskZindex = 99999 + 1;
Tools.maskObjs = [];
Tools.maskBackground = null;
$(function () {
    $(document.body).on("keyup", function (b) {
        if (b.keyCode == 27) {
            var a = Tools.maskObjs[Tools.maskObjs.length - 1];
            if (a && a.noesc !== true) {
                a.hide()
            }
        }
    })
});
Tools.maskShow = function (a, d) {
    Tools.arrayRemove(Tools.maskObjs, a);
    Tools.maskObjs.push(a);
    a.bg.css("z-index", Tools.maskZindex++).show();
    if (d) {
        a.obj.offset(d)
    } else {
        var c = a.obj.outerWidth() / 2, b = a.obj.outerHeight() / 2;
        a.obj.css("margin-left", (-c) + "px");
        a.obj.css("margin-top", (-b) + "px")
    }
    a.obj.css("z-index", Tools.maskZindex++).show(150, function () {
        a.obj.find(".btn,.k-btn").first().focus();
        if (a.obj.height() >= $(window).height()) {
            var h = a.obj.prev();
            var g = a.obj.find("div.panel-heading");
            var i = a.obj.find("div.panel-body");
            var f = a.obj.find("div.panel-footer");
            var e = h.height() - 20 - g.height() - f.height();
            i.css("height", e + "px");
            i.css("overflow", "auto");
            var j = a.obj.outerHeight() / 2;
            a.obj.css("margin-top", (-j) + "px")
        }
        if (a.onshow) {
            a.onshow.call(a.obj, a.obj)
        }
    });
    if (navigator.userAgent.indexOf("MSIE 6.0") > 0) {
        a.bg.css("z-index", 10);
        a.obj.css("z-index", 10)
    }
    return a
};
Tools.maskHide = function (a) {
    Tools.arrayRemove(Tools.maskObjs, a);
    a.obj.hide(150, function () {
        if (a.onhide) {
            a.onhide.call(a.obj, a.obj)
        }
    });
    a.bg.hide()
};
Tools.makeMask = function (f, b, g, c) {
    var d = window.$;
    var e = d(window);
    var a = {
        obj: f,
        bg: d('<div class="mask-background"></div>').appendTo(c || document.body),
        onshow: null,
        onhide: null
    };
    a.obj.addClass("mask-window-div").appendTo(c || document.body);
    a.noesc = g;
    a.show = function (h) {
        if (navigator.userAgent.indexOf("MSIE 6.0") > 0) {
            d(".paging-div select").attr("style", "width:0")
        }
        Tools.maskShow(a, h);
        a.showed = true
    };
    a.hide = function () {
        if (navigator.userAgent.indexOf("MSIE 6.0") > 0) {
            d(".paging-div select").attr("style", "")
        }
        Tools.maskHide(a);
        a.showed = false
    };
    a.remove = function () {
        Tools.maskHide(a);
        a.obj.remove();
        a.bg.remove();
        for (var h in a) {
            delete a[h]
        }
        delete a
    };
    return a
};
Tools.href = "javascript:void(0);";
Tools.alert = function (e, d, c) {
    var g = $('<div class="tools-alert panel">' + '<div class="panel-heading"><div class="title"></div></div>' + '<div class="panel-body"><div class="icon"></div><div class="text"><span class="k-field-display" style="word-wrap:break-word;"></span></div></div>' + '<div class="panel-footer center">' + '	<button class="ok btn btn-sm">确定</button></div>' + "</div>");
    var a = Tools.makeMask(g, "div.panel > div.panel-body");
    a.obj.find("button.ok").click(function () {
        a.hide();
        if (a.okFn) {
            a.okFn.call(a.obj)
        }
    });
    a.okFn = c;
    a.onhide = function () {
        a.obj.remove();
        delete a
    };
    if (d == null) {
        d = Tools.Msg.INFO
    }
    var h, b, f;
    switch (d) {
        case Tools.Msg.ERROR:
            h = "错误提示";
            b = "btn-danger";
            break;
        case Tools.Msg.WRANING:
            h = "警告提示";
            b = "btn-warning";
            break;
        default:
            h = "提示信息";
            b = "btn-primary"
    }
    a.obj.find("div.icon").html('<img src="' + d + '" />');
    a.obj.find("div.title").text(h);
    a.obj.find("div.text span").text(e);
    a.obj.find("button.ok").addClass(b);
    a.show();
    return a
};
Tools.alertFn = function (c, b, a) {
    Tools.alert(c, a, b)
};
Tools.confirm = function (d, c) {
    var e = $('<div class="tools-confirm panel">' + '<div class="panel-heading"><div class="title"></div></div>' + '<div class="panel-body"><div class="icon"></div><div class="text"></div></div>' + '<div class="panel-footer center">' + '	<button class="ok btn btn-primary btn-sm">确定</button> &nbsp; <button class="no btn btn-default btn-sm">取消</button></div>' + "</div>");
    var a = Tools.makeMask(e, "div.panel > div.panel-body");
    a.obj.find("button.ok").click(function () {
        a.hide();
        if (a.fn) {
            a.fn.call(a.obj, true)
        }
    });
    a.obj.find("button.no").click(function () {
        a.hide();
        if (a.fn) {
            a.fn.call(a.obj, false)
        }
    });
    a.fn = c;
    a.onhide = function () {
        a.obj.remove();
        delete a
    };
    var b = Tools.Msg.QUESTION, f = "系统提示";
    a.obj.find("div.icon").html('<img src="' + b + '" />');
    a.obj.find("div.title").text(f);
    a.obj.find("div.text").html(d);
    a.show();
    return a
};
Tools.submit2BlankAddHidden = function (b, a, d) {
    var c = document.createElement("input");
    c.type = "hidden";
    c.name = a;
    c.value = (d === window.undefined ? "" : d);
    b.appendChild(c);
    return c
};
Tools.submit2BlankWindow = function (a, d, l) {
    var b = document.createElement("form");
    b.target = l || "_blank";
    b.method = "POST";
    b.action = a;
    document.body.appendChild(b);
    var g = [];
    if (d) {
        for (var j in d) {
            var c = d[j];
            var h = typeof c;
            if (h == "undefined") {
            } else {
                if (h != "function" && h != "object") {
                    g.push(Tools.submit2BlankAddHidden(b, j, c))
                } else {
                    if (c != null && typeof c == "object" && c.length != null) {
                        if (c.length) {
                            for (var e = 0, f = c.length; e < f; e++) {
                                g.push(Tools.submit2BlankAddHidden(b, j, c[e]))
                            }
                        }
                    }
                }
            }
        }
    }
    b.submit();
    if (g && g.length > 0) {
        for (var e = 0, f = g.length; e < f; e++) {
            $(g[e]).remove()
        }
    }
    $(b).remove()
};
Tools.isNumber = function (b) {
    if (!b) {
        return false
    }
    var c = /^\d+(\.\d+)?$/;
    if (!c.test(b)) {
        return false
    }
    try {
        if (parseFloat(b) != b) {
            return false
        }
    } catch (a) {
        return false
    }
    return true
};
Tools.isValidDate = function (a) {
    a = String(a);
    if (a.length == 8) {
        a = a.substr(0, 4) + "-" + a.substr(4, 2) + "-" + a.substr(6, 2)
    }
    var b = a.match(/^(\d{1,4})(-|\/)(\d{1,2})\2(\d{1,2})$/);
    if (b == null) {
        return false
    }
    var c = new Date(b[1], b[3] - 1, b[4]);
    return (c.getFullYear() == b[1] && (c.getMonth() + 1) == b[3] && c.getDate() == b[4])
};
Tools.isArray = function (a) {
    if (a == null) {
        return false
    }
    return a != null && typeof a == "object" && a.splice != null && a.join != null && a.length != null
};
Tools.isChinaIDCard = function (g, f) {
    var f = f.toString();
    var i = [];
    if (f.length == 15) {
        if (!Tools.isValidDate("19" + f.substr(6, 2) + f.substr(8, 2) + f.substr(10, 2))) {
            i.push("身份证号码错误：出生日期不正确")
        }
    } else {
        if (f.length == 18) {
            if (!Tools.isValidDate(f.substr(6, 4) + f.substr(10, 2) + f.substr(12, 2))) {
                i.push("身份证号码错误：出生日期不正确")
            }
        } else {
            i.push("身份证号码必须为15位或者18位")
        }
    }
    if (f.length == 18) {
        var e, d, h;
        if (!Tools.isNumber(f.substr(0, 17))) {
            i.push("身份证号码错误：前17位不能含有英文字母")
        }
        e = parseInt(f.substr(0, 1)) * 7 + parseInt(f.substr(1, 1)) * 9 + parseInt(f.substr(2, 1)) * 10;
        e = e + parseInt(f.substr(3, 1)) * 5 + parseInt(f.substr(4, 1)) * 8 + parseInt(f.substr(5, 1)) * 4;
        e = e + parseInt(f.substr(6, 1)) * 2 + parseInt(f.substr(7, 1)) * 1 + parseInt(f.substr(8, 1)) * 6;
        e = e + parseInt(f.substr(9, 1)) * 3 + parseInt(f.substr(10, 1)) * 7 + parseInt(f.substr(11, 1)) * 9;
        e = e + parseInt(f.substr(12, 1)) * 10 + parseInt(f.substr(13, 1)) * 5 + parseInt(f.substr(14, 1)) * 8;
        e = e + parseInt(f.substr(15, 1)) * 4 + parseInt(f.substr(16, 1)) * 2;
        d = e % 11;
        if (d == 2) {
            h = f.substr(17, 1).toUpperCase()
        } else {
            h = parseInt(f.substr(17, 1))
        }
        switch (d) {
            case 0:
                if (h != 1) {
                    i.push("身份证号码校验位错")
                }
                break;
            case 1:
                if (h != 0) {
                    i.push("身份证号码校验位错")
                }
                break;
            case 2:
                if (h != "X") {
                    i.push("身份证号码校验位错")
                }
                break;
            case 3:
                if (h != 9) {
                    i.push("身份证号码校验位错")
                }
                break;
            case 4:
                if (h != 8) {
                    i.push("身份证号码校验位错")
                }
                break;
            case 5:
                if (h != 7) {
                    i.push("身份证号码校验位错")
                }
                break;
            case 6:
                if (h != 6) {
                    i.push("身份证号码校验位错")
                }
                break;
            case 7:
                if (h != 5) {
                    i.push("身份证号码校验位错")
                }
                break;
            case 8:
                if (h != 4) {
                    i.push("身份证号码校验位错")
                }
                break;
            case 9:
                if (h != 3) {
                    i.push("身份证号码校验位错")
                }
                break;
            case 10:
                if (h != 2) {
                    i.push("身份证号码校验位错")
                }
        }
    } else {
        if (!Tools.isNumber(f)) {
            i.push("身份证号码错误：前15位不能含有英文字母")
        }
    }
    if (i.length > 0) {
        return false
    } else {
        return true
    }
};
Tools.Base64 = {
    _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", encode: function (c) {
        var a = "";
        var l, h, f, j, g, e, d;
        var b = 0;
        c = Tools.Base64._utf8_encode(c);
        while (b < c.length) {
            l = c.charCodeAt(b++);
            h = c.charCodeAt(b++);
            f = c.charCodeAt(b++);
            j = l >> 2;
            g = ((l & 3) << 4) | (h >> 4);
            e = ((h & 15) << 2) | (f >> 6);
            d = f & 63;
            if (isNaN(h)) {
                e = d = 64
            } else {
                if (isNaN(f)) {
                    d = 64
                }
            }
            a = a + this._keyStr.charAt(j) + this._keyStr.charAt(g) + this._keyStr.charAt(e) + this._keyStr.charAt(d)
        }
        return a
    }, decode: function (c) {
        var a = "";
        var l, h, f;
        var j, g, e, d;
        var b = 0;
        c = c.replace(/[^A-Za-z0-9\+\/\=]/g, "");
        while (b < c.length) {
            j = this._keyStr.indexOf(c.charAt(b++));
            g = this._keyStr.indexOf(c.charAt(b++));
            e = this._keyStr.indexOf(c.charAt(b++));
            d = this._keyStr.indexOf(c.charAt(b++));
            l = (j << 2) | (g >> 4);
            h = ((g & 15) << 4) | (e >> 2);
            f = ((e & 3) << 6) | d;
            a = a + String.fromCharCode(l);
            if (e != 64) {
                a = a + String.fromCharCode(h)
            }
            if (d != 64) {
                a = a + String.fromCharCode(f)
            }
        }
        a = Tools.Base64._utf8_decode(a);
        return a
    }, _utf8_encode: function (b) {
        b = b.replace(/\r\n/g, "\n");
        var a = "";
        for (var e = 0; e < b.length; e++) {
            var d = b.charCodeAt(e);
            if (d < 128) {
                a += String.fromCharCode(d)
            } else {
                if ((d > 127) && (d < 2048)) {
                    a += String.fromCharCode((d >> 6) | 192);
                    a += String.fromCharCode((d & 63) | 128)
                } else {
                    a += String.fromCharCode((d >> 12) | 224);
                    a += String.fromCharCode(((d >> 6) & 63) | 128);
                    a += String.fromCharCode((d & 63) | 128)
                }
            }
        }
        return a
    }, _utf8_decode: function (a) {
        var b = "";
        var d = 0;
        var e = c1 = c2 = 0;
        while (d < a.length) {
            e = a.charCodeAt(d);
            if (e < 128) {
                b += String.fromCharCode(e);
                d++
            } else {
                if ((e > 191) && (e < 224)) {
                    c2 = a.charCodeAt(d + 1);
                    b += String.fromCharCode(((e & 31) << 6) | (c2 & 63));
                    d += 2
                } else {
                    c2 = a.charCodeAt(d + 1);
                    c3 = a.charCodeAt(d + 2);
                    b += String.fromCharCode(((e & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                    d += 3
                }
            }
        }
        return b
    }
};
Tools.isEmail = function (b) {
    var a = new RegExp("^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(.[a-zA-Z0-9_-]+)+$");
    if (!a.test(b)) {
        return "电子邮箱格式不正确"
    }
    return true
};
Tools.removeRepeat = function (a) {
    var f = [], d, c, b, e;
    for (d = 0; d < a.length; d++) {
        b = a[d];
        e = false;
        for (c = 0; c < f.length; c++) {
            if (f[c] == b) {
                e = true;
                break
            }
        }
        if (e) {
            continue
        }
        f.push(b)
    }
    return f
};
Tools.gbMoney = function (b) {
    if (b == "" || b == null) {
        return ""
    }
    b = Number(b);
    if (isNaN(b)) {
        return "错误的金额"
    }
    var a = "";
    var e = "万仟佰拾亿仟佰拾万仟佰拾元角分";
    b += "00";
    var d = b.indexOf(".");
    if (d >= 0) {
        b = b.substring(0, d) + b.substr(d + 1, 2)
    }
    e = e.substr(e.length - b.length);
    for (var c = 0; c < b.length; c++) {
        a += "零壹贰叁肆伍陆柒捌玖".substr(b.substr(c, 1), 1) + e.substr(c, 1)
    }
    return a.replace(new RegExp("零角零分$"), "整").replace(new RegExp("零分$"), "").replace(new RegExp("零[仟佰拾]", "g"), "零").replace(new RegExp("零{2,}", "g"), "零").replace(new RegExp("零([亿|万])", "g"), "$1").replace(new RegExp("零+元"), "元").replace(new RegExp("亿零{0,3}万"), "亿").replace(new RegExp("^元"), "零元")
};
Tools.idCard15to18 = function (b) {
    if (b == null) {
        return ""
    }
    b = Tools.trim(b);
    if (b.length == 18) {
        return b
    }
    var h = ["1", "0", "X", "9", "8", "7", "6", "5", "4", "3", "2"];
    var g = 0;
    var e = b;
    if (b != null && b.length == 15) {
        e = b.substr(0, 6) + "19" + b.substr(6);
        for (var d = 0; d < e.length; d++) {
            var i = e.charAt(d);
            var a = Math.pow(2, e.length - d) % 11;
            g = g + parseInt(i) * a
        }
        var f = g % 11;
        e += h[f]
    }
    return e
};
Tools.idCard18to15 = function (a) {
    if (a == null) {
        return ""
    }
    a = Tools.trim(a);
    if (a.length == 18) {
        return a.substr(0, 6) + a.substring(8, a.length - 1)
    }
    return a
};
Tools.indexOfArray = function (a, c) {
    if (a == null) {
        return -1
    }
    for (var b = 0; b < a.length; b++) {
        if (a[b] == c) {
            return b
        }
    }
    return -1
};
Tools.indexOfJsonArray = function (b, d, e) {
    if (b == null) {
        return -1
    }
    for (var c = 0, a = b.length; c < a; c++) {
        if (b[c][d] == e) {
            return c
        }
    }
    return -1
};
Tools.Number = function (a) {
    if (a == null) {
        return 0
    }
    return Number(a.replace(/,/g, ""))
};
Tools.array2str = function (a, f) {
    if (a == null) {
        return "null"
    }
    var e = [], b, d;
    for (var c = 0; c < a.length; c++) {
        b = a[c], d = (typeof b);
        switch (d) {
            case"function":
                if (f === true) {
                    b = '"' + String(b).replace(/[\n\r\t]/g, "").replace(/[\t]/g, " ") + '"'
                } else {
                    continue
                }
                break;
            case"string":
                b = '"' + b + '"';
                break;
            case"object":
                if (Tools.isArray(b)) {
                    b = Tools.array2str(b, f)
                } else {
                    b = Tools.json2str(b, f)
                }
                break
        }
        e.push(b)
    }
    return "[" + e.join(",") + "]"
};
Tools.json2str = function (d, h, a) {
    if (d == null) {
        return "null"
    }
    if (Tools.isArray(d)) {
        return Tools.array2str(d, h, a)
    }
    var g = [], c, b, f;
    for (c in d) {
        b = d[c], f = (typeof b);
        switch (f) {
            case"function":
                if (h === true) {
                    b = String(b).replace(new RegExp("//.*[\n\r]", "g"), " ").replace(new RegExp("[\n\r]", "g"), "").replace(new RegExp("[\t]", "g"), " ");
                    if (a === true) {
                    } else {
                        b = '"' + b + '"'
                    }
                } else {
                    continue
                }
                break;
            case"string":
                var e = new RegExp('"', "g");
                b = b.replace(e, '\\"');
                b = '"' + b + '"';
                break;
            case"object":
                if (Tools.isArray(b)) {
                    b = Tools.array2str(b, h, a)
                } else {
                    if (c == "confOption") {
                        b = '"' + Tools.json2str(b, h, true).replace(/["]/g, '\\"') + '"'
                    } else {
                        b = Tools.json2str(b, h, a)
                    }
                }
                break
        }
        g.push('"' + c + '":' + b)
    }
    return "{" + g.join(", ") + "}"
};
Tools.str2Json = function (str) {
    if (!str) {
        return null
    }
    var json = null;
    json = eval("(" + str + ")");
    return json
};
Tools.str2Date = function (a) {
    var c = String(a);
    if (c.length == 8) {
        c = c.substr(0, 4) + "-" + c.substr(4, 2) + "-" + c.substr(6, 2)
    }
    var b = c.match(/^(\d{1,4})(-|\/)(\d{1,2})\2(\d{1,2})$/);
    if (b == null) {
        return null
    }
    return new Date(b[1], b[3] - 1, b[4])
};
Tools.date2str = function (b) {
    var c = b.getMonth() + 1, a = b.getDate();
    if (c < 10) {
        c = "0" + String(c)
    }
    if (a < 10) {
        a = "0" + String(a)
    }
    return String(b.getFullYear()) + String(c) + String(a)
};
Tools.LOG_LEVEL = "debug";
Tools.log = function (h) {
    var c = window.$;
    var a;
    try {
        a = h.toLowerCase()
    } catch (g) {
    }
    if ((a == "error" && Tools.LOG_LEVEL != "debug" && Tools.LOG_LEVEL != "error") || (a == "debug" && Tools.LOG_LEVEL != "debug")) {
        return
    }
    if (Tools.logDiv == null) {
        Tools.logDiv = c(['<div id="tools-log-div">', '<div class="title">', '<span style="float:left">日志窗口</span>', '<a href="' + Tools.href + '" onclick="Tools.logClose()">隐藏</a>', '<a href="' + Tools.href + '" onclick="Tools.logClear()">清空</a>', '<a href="' + Tools.href + '" onclick="Tools.logHeight(400)">高400</a>', '<a href="' + Tools.href + '" onclick="Tools.logHeight(300)">高300</a>', '<a href="' + Tools.href + '" onclick="Tools.logHeight(200)">高200</a>', '<a href="' + Tools.href + '" onclick="Tools.logHeight(100)">高100</a>', '<a href="' + Tools.href + '" onclick="Tools.logHeight(40)">高40</a>', "</div>", '<div class="msg"><ul></ul></div>', "</div>"].join("")).appendTo(document.body)
    }
    var j = "", a = "";
    var l = 0;
    if (h == "error" || h == "debug") {
        j = h;
        l = 1;
        a = h.toUpperCase() + " | "
    }
    var b = [];
    for (var d = l; d < arguments.length; d++) {
        b.push(arguments[d])
    }
    Tools.logDiv.show();
    var f = Tools.logDiv.children("div.msg").children("ul");
    c("<li></li>").addClass(j).prependTo(f).text(f.children("li").length + " | " + a + b.join("，"))
};
Tools.logClose = function () {
    if (Tools.logDiv) {
        Tools.logDiv.hide()
    }
};
Tools.logClear = function () {
    if (Tools.logDiv) {
        Tools.logDiv.children("div.msg").children("ul").empty()
    }
};
Tools.logHeight = function (a) {
    if (Tools.logDiv) {
        Tools.logDiv.children("div.msg").height(a)
    }
};
Tools.json2get = function (d) {
    var a = [];
    for (var c in d) {
        var e = d[c];
        if (Tools.isArray(e)) {
            for (var b = 0; b < e.length; b++) {
                if (typeof e[b] == "object") {
                    a.push(c + "={[json]}" + encodeURIComponent(Tools.json2str(e[b])))
                } else {
                    a.push(c + "=" + encodeURIComponent(e[b]))
                }
            }
        } else {
            if (typeof e == "object") {
                if (e != null) {
                    a.push(c + "={[json]}" + encodeURIComponent(Tools.json2str(e)))
                } else {
                    a.push(c + "=")
                }
            } else {
                a.push(c + "=" + encodeURIComponent(e))
            }
        }
    }
    return a.join("&")
};
Tools.getDateRegion = function (d, e) {
    if (d != "" && e != "") {
        var g, c, a, f;
        if (d.length == 8) {
            d = d.substr(0, 4) + "-" + d.substr(4, 2) + "-" + d.substr(6, 2)
        }
        if (e.length == 8) {
            e = e.substr(0, 4) + "-" + e.substr(4, 2) + "-" + e.substr(6, 2)
        }
        g = d.split("-");
        c = new Date(g[1] + "/" + g[2] + "/" + g[0]);
        g = e.split("-");
        a = new Date(g[1] + "/" + g[2] + "/" + g[0]);
        var b = (c - a) / 1000 / 60 / 60 / 24;
        f = b;
        return f
    } else {
        return 0
    }
};
Tools.argsCall = function (fn, scope, addArgs, start) {
    var nstart;
    if (addArgs === undefined || addArgs == null) {
        nstart = 0
    } else {
        if (typeof addArgs == "number") {
            nstart = addArgs;
            addArgs = null
        } else {
            if (!$.isArray(addArgs)) {
                Tools.log("error", "Tools.argsCall[1]:addArgs参数值错误:" + addArgs);
                return undefined
            }
            if (start === undefined || start == null) {
                nstart = 0
            } else {
                nstart = Number(start)
            }
        }
    }
    if (isNaN(nstart) || nstart < 0) {
        Tools.log("error", "Tools.argsCall[2]:start参数值错误:" + start);
        return undefined
    }
    var s = [];
    if (addArgs && addArgs.length > 0) {
        var len = addArgs.length;
        for (var i = 0; i < len; i++) {
            s.push("addArgs[" + i + "]")
        }
    }
    var args = Tools.argsCall.caller.arguments;
    var len = args.length;
    for (var i = nstart; i < len; i++) {
        s.push("args[" + i + "]")
    }
    var argstr = "";
    if (s.length > 0) {
        argstr = "," + s.join(",")
    }
    return eval("fn.call(scope" + argstr + ")")
};
Tools.logerror = function () {
    Tools.argsCall(Tools.log, this, ["error"])
};
Tools.logdebug = function () {
    Tools.argsCall(Tools.log, this, ["debug"])
};
Tools.doEvent = function (scope, fn) {
    if (fn === undefined || fn == null || fn == "") {
        return fn
    }
    fn = Tools.trim(fn);
    var f = null;
    if (typeof fn == "function") {
        f = fn
    } else {
        if (fn.match(/function[\s]*[(][^)]*[)][\s]*[{].*[}]$/)) {
            try {
                f = eval("(" + fn + ")")
            } catch (ex) {
                Tools.logerror("Tools.doEvent[0]:eval(" + fn + ") exception:" + ex);
                return undefined
            }
        } else {
            try {
                if (fn.indexOf(".") == -1) {
                    f = eval('(window["' + fn + '"])')
                } else {
                    var fs = fn.split(".");
                    var str = "(window";
                    for (var i = 0; i < fs.length; i++) {
                        str += "['" + fs[i] + "']"
                    }
                    str += ")";
                    f = eval(str)
                }
            } catch (ex) {
            }
        }
    }
    if (f == null) {
        return (function () {
            try {
                eval(fn)
            } catch (ex) {
                Tools.logerror("Tools.doEvent[2]:eval(" + fn + ") exception:" + ex)
            }
            return undefined
        }).call(scope)
    } else {
        try {
            return Tools.argsCall(f, scope, 2)
        } catch (e) {
            Tools.logerror("Tools.doEvent[3]:call function " + fn + " exception:" + e);
            return undefined
        }
    }
};
Tools.getDateMonthBetween = function (h, f) {
    if (h != "" && f != "") {
        var b = h.substr(0, 4);
        var a = f.substr(0, 4);
        var i = h.substr(4, 2);
        var g = f.substr(4, 2);
        var e = h.substr(6, 2);
        var d = f.substr(6, 2);
        var c = (a - b) * 12 + (g - i);
        if (c > 0) {
            if (d - e <= 0) {
                c = c - 1
            }
        } else {
            if (e - d <= 0) {
                c = c + 1
            }
        }
        return Math.abs(c)
    } else {
        return 0
    }
};
Tools.addWorkDay = function (a, c) {
    var b = "";
    Util.ajaxQuery({
        exeid: "M8222EQWD01", async: false, params: {date: a, days: c}, afterSuccess: function (d) {
            if (d.rows.length > 0) {
                b = d.rows[0].workday
            } else {
                b = a
            }
        }
    }, false);
    return b
};
Tools.addWorkDayEx = function (a, c) {
    var b = "";
    Util.ajaxQuery({
        exeid: "M8222EQWD02", async: false, params: {date: a, days: c}, afterSuccess: function (d) {
            if (d.rows.length > 0) {
                b = d.rows[0].workday
            } else {
                b = a
            }
        }
    }, false);
    return b
};
Tools.getRealWorkDay = function (d, j) {
    if (d == undefined || d == "") {
        return
    }
    if (isNaN(j)) {
        j = 0
    }
    var g = d.substring(0, 4);
    var f = d.substring(4, 6);
    var h = d.substring(6);
    f = parseInt(f, 10) - 1;
    var a = new Date(Number(g), f, parseInt(h, 10) + parseInt(j, 10));
    var i = a.getFullYear();
    var c = a.getMonth() + 1;
    var b = a.getDate();
    if (c < 10) {
        c = "0" + String(c)
    }
    if (b < 10) {
        b = "0" + String(b)
    }
    var e = i + String(c) + b;
    return Tools.addWorkDayEx(e, 0)
};
Tools.getDealNo = function () {
    var a = "";
    Util.ajaxQuery({
        exeid: "M8000EQDEALNO", async: false, params: {}, afterSuccess: function (b) {
            if (b.rows.length > 0) {
                a = b.rows[0].dealno
            } else {
                a = ""
            }
        }
    }, false);
    return a
};
Tools.getSysParam = function (b) {
    var a = "";
    Util.ajaxQuery({
        exeid: "M0000EQ003", async: false, params: {paraid: b}, afterSuccess: function (c) {
            if (c.rows.length > 0) {
                a = c.rows[0].paravalue
            } else {
                a = ""
            }
        }
    }, false);
    return a
};
Tools.cancelBubble = function (a) {
    if (a.stopPropagation) {
        a.stopPropagation()
    } else {
        a.cancelBubble = true
    }
};
Tools.tradeCheck = function (c, a, b) {
    Util.ajaxRequest({
        url: "tradeCheck/controller.json",
        params: {datas: Tools.json2str(c)},
        async: false,
        afterSuccess: function (f) {
            if (f.success) {
                var d = f.returndata.msg;
                if (d.length > 0) {
                    var g = "";
                    for (var e = 0; e < d.length; e++) {
                        g += ((e + 1) + "、" + d[e] + "<br/>")
                    }
                    g += "<p style='font-size:14px;color:red;text-align:center;'>是否继续提交？</p>";
                    Tools.confirm(g, function (h) {
                        if (h) {
                            if (typeof a == "function") {
                                a(b)
                            }
                        }
                    })
                } else {
                    if (typeof a == "function") {
                        a(b)
                    }
                }
            }
        }
    }, false)
};
Tools.initSearch = function (e, d, a) {
    var g = {};
    if (d.length > 0) {
        for (var c = 0; c < d.length; c++) {
            var h = d[c];
            if (typeof h == "string") {
                h = $(h)
            }
            var f = a[c];
            K.field.value(h, f);
            K_field_search_onInputChange.call(h, f);
            var b = h.attr("name") || h.attr("data-name");
            g[b] = f
        }
    }
    K.btn.handle(e, g)
};
Date.prototype.format = function (a) {
    var c = {
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "h+": this.getHours(),
        "m+": this.getMinutes(),
        "s+": this.getSeconds(),
        "q+": Math.floor((this.getMonth() + 3) / 3),
        "S": this.getMilliseconds()
    };
    if (/(y+)/.test(a)) {
        a = a.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length))
    }
    for (var b in c) {
        if (new RegExp("(" + b + ")").test(a)) {
            a = a.replace(RegExp.$1, (RegExp.$1.length == 1) ? (c[b]) : (("00" + c[b]).substr(("" + c[b]).length)))
        }
    }
    return a
};
Tools.arrayRemoveItem = function (c, a) {
    if (isNaN(a) || a > c.length) {
        return false
    }
    for (var b = 0, d = 0; b < c.length; b++) {
        if (c[b] != c[a]) {
            c[d++] = c[b]
        }
    }
    c.length -= 1
};
if (!window.wpVersion) {
    window.wpVersion = {}
}
window.bizr2Version["util-cs"] = "1.0.5";
Util = {};
String.prototype.trim = function () {
    var a = /\r\n/ig;
    return this.replace(a, "")
};
Util.ajaxRequestFailure = function (result) {
    var retText = result.responseText.trim();
    if (retText.indexOf("dateError") != -1) {
        var retArr = retText.split(",");
        if (retArr[1] == "1") {
            K.index.openPage("M8DATEERROR")
        } else {
            window.top.Tools.alert("系统工作日已经被修改，请让有重整权限的用户重整！", Tools.Msg.ERROR);
            window.top.$(".mask-background").remove();
            var $w = window.top.$(".tools-alert");
            for (var i = 1; i < $w.length; i++) {
                $w.eq(i).remove()
            }
        }
        return
    }
    var errmsg = null, msg;
    try {
        var json = null;
        eval("json=" + result.responseText);
        errmsg = json.returnmsg
    } catch (e) {
        if (result.responseText && result.responseText.indexOf("login.json") > -1 && result.responseText.indexOf("k-login.css") > -1) {
            if (window.frameElement) {
                window.parent.location.href = "login.jsp"
            } else {
                window.location.href = "login.jsp"
            }
            return
        }
    }
    msg = "提交请求失败：服务器处理过程中发生错误";
    if (errmsg) {
        msg += "：<br />" + errmsg
    }
    Tools.alert(msg, Tools.Msg.ERROR)
};
Util.toNullString = function (c) {
    if (Tools.isArray(c)) {
        for (var b = 0; b < c.length; b++) {
            if (c[a] == null) {
                c[a] = "NULL"
            } else {
                if (typeof c[a] == "object") {
                    Util.toNullString(c[a])
                }
            }
        }
    } else {
        for (var a in c) {
            if (c[a] == null) {
                c[a] = "NULL"
            } else {
                if (typeof c[a] == "object") {
                    Util.toNullString(c[a])
                }
            }
        }
    }
};
Util.bizwareSuccess = function (a) {
    if (typeof Global.bizware_success_code == "string") {
        return Global.bizware_success_code == a
    } else {
        return Tools.indexOfArray(Global.bizware_success_code, a) > -1
    }
};
Util.xss = function (b, a) {
    if (!b) {
        return b === 0 ? "0" : ""
    }
    switch (a) {
        case"none":
            return b + "";
            break;
        case"html":
            return b.replace(/[&'"<>\/\\\-\x00-\x09\x0b-\x0c\x1f\x80-\xff]/g, function (c) {
                return "&#" + c.charCodeAt(0) + ";"
            }).replace(/ /g, "?").replace(/\r\n/g, "<br />").replace(/\n/g, "<br />").replace(/\r/g, "<br />");
            break;
        case"htmlEp":
            return b.replace(/[&'"<>\/\\\-\x00-\x1f\x80-\xff]/g, function (c) {
                return "&#" + c.charCodeAt(0) + ";"
            });
            break;
        case"url":
            return escape(b).replace(/\+/g, "%2B");
            break;
        case"miniUrl":
            return b.replace(/%/g, "%25");
            break;
        case"script":
            return b.replace(/[\\"']/g, function (c) {
                return "\\" + c
            }).replace(/%/g, "\\x25").replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\x01/g, "\\x01");
            break;
        case"reg":
            return b.replace(/[\\\^\$\*\+\?\{\}\.\(\)\[\]]/g, function (c) {
                return "\\" + c
            });
            break;
        default:
            return escape(b).replace(/[&'"<>\/\\\-\x00-\x09\x0b-\x0c\x1f\x80-\xff]/g, function (c) {
                return "&#" + c.charCodeAt(0) + ";"
            }).replace(/ /g, "?").replace(/\r\n/g, "<br />").replace(/\n/g, "<br />").replace(/\r/g, "<br />");
            break
    }
};
Util.encodeURIComponent = function (c) {
    if (Object.prototype.toString.call(c) === "[object Array]") {
        for (var b = 0; b < c.length; b++) {
            c[b] = encodeURIComponent(c[b])
        }
    } else {
        if (Object.prototype.toString.call(c) === "[object Object]") {
            for (var a in c) {
                c[a] = encodeURIComponent(c[a])
            }
        } else {
            if (typeof c === "string") {
                c = encodeURIComponent(c);
                return c
            }
        }
    }
};
Util.decodeURIComponent = function (c) {
    if (Object.prototype.toString.call(c) === "[object Array]") {
        for (var b = 0; b < c.length; b++) {
            c[b] = decodeURIComponent(c[b])
        }
    } else {
        if (Object.prototype.toString.call(c) === "[object Object]") {
            for (var a in c) {
                c[a] = decodeURIComponent(c[a])
            }
        } else {
            if (typeof c === "string") {
                c = decodeURIComponent(c);
                return c
            }
        }
    }
};
Util.htmlUnEncode = function (a) {
    a = a.replace(/&amp;/g, "&");
    a = a.replace(/&gt;/g, ">");
    a = a.replace(/&lt;/g, "<");
    a = a.replace(/&quot;/g, '"');
    a = a.replace(/&#39;/g, "'");
    return a
};
Util.ajaxConfig = function (a, b) {
    if (a.params == null) {
        a.params = {}
    }
    if (a.exeid) {
        Tools.applyIf(a.params, {exeid: a.exeid});
        Tools.applyIf(a, {url: a.dataUrl || a.submitUrl || b})
    }
    if (a.url == "bizware") {
        a.url = "base/bizware.json"
    }
    return a
};
Util.ajaxRequest = function (c, e) {
    var d = window.$;
    c = Tools.apply({}, c);
    c.params = Tools.apply({}, c.params);
    if (e !== false) {
        var a = c.requestMsg;
        c.maskMsg = c.maskMsg || "处理中...";
        Tools.mask(c.maskMsg, c.maskEl)
    }
    c = Util.ajaxConfig(c, "base/comn-update.json");
    if (c.success) {
        var f = c.success;
        c.success = function (g) {
            if (e !== false) {
                Tools.unmask(c.maskEl)
            }
            f(g)
        }
    }
    Tools.applyIf(c, {
        timeout: Global.AJAX_TIMEOUT, type: "POST", dataType: "json", complete: function () {
        }, error: function (h, i, g) {
            if (e !== false) {
                Tools.unmask(c.maskEl)
            }
            Util.ajaxRequestFailure(h)
        }, success: function (j) {
            if (e !== false) {
                Tools.unmask(c.maskEl)
            }
            if (c.callback) {
                c.callback.call(c.callbackScope, j)
            }
            var g = j.success === true || (j.head_rtn_code && Util.bizwareSuccess(j.head_rtn_code));
            var h = j.success === false || (j.head_rtn_code && !Util.bizwareSuccess(j.head_rtn_code));
            var l = j.returnmsg || j.head_rtn_desc;
            if (g && c.afterSuccess) {
                var i = c.afterSuccess.call(c.afterSuccessScope, j);
                if (i === false) {
                    return
                }
            }
            if (h && c.afterError) {
                var i = c.afterError.call(c.afterErrorScope, j);
                if (i === false) {
                    return
                }
            }
            if (c.aCallback) {
                var i = c.aCallback.call(this, j);
                if (i === false) {
                    return
                }
            }
            if (j.authLogin) {
                K.form.reset(d("#SYS_AUTH_LOGIN"));
                K.popup(d("#SYS_AUTH_LOGIN"));
                return
            }
            if (l) {
                if (g && c.succesalert !== false) {
                    Tools.alert(l)
                } else {
                    if (h && c.errorsalert !== false) {
                        Tools.alert((a || "处理") + "失败：" + l, Tools.Msg.ERROR)
                    }
                }
            }
        }
    });
    Util.toNullString(c.params);
    if (K && K.index.isPage()) {
        var b = K.index.getPage();
        if (b && b.length > 0) {
            c.params["SYSTEM_MENUNAME"] = b.parent().attr("data-title")
        }
    }
    c.data = Tools.json2get(c.params);
    delete c.params;
    d.ajax(c)
};
Util.ajaxQuery = function (b, d) {
    var c = window.$;
    b = Tools.apply({}, b);
    b.params = Tools.apply({}, b.params);
    if (d !== false) {
        var a = b.requestMsg;
        b.maskMsg = b.maskMsg || "加载中...";
        Tools.loadingTip(b.maskMsg)
    }
    b = Util.ajaxConfig(b, "base/comn-query.json");
    if (b.success) {
        var e = b.success;
        b.success = function (f) {
            if (d !== false) {
                Tools.unloadingTip()
            }
            e(f)
        }
    }
    Tools.applyIf(b, {
        timeout: Global.AJAX_TIMEOUT, type: "POST", dataType: "json", complete: function () {
        }, error: function (g, h, f) {
            if (d !== false) {
                Tools.unloadingTip()
            }
            Util.ajaxRequestFailure(g)
        }, success: function (h) {
            if (d !== false) {
                Tools.unloadingTip()
            }
            var f = false;
            if ((h.results != null && h.rows != null) || Tools.isArray(h) || Util.bizwareSuccess(h.head_rtn_code)) {
                f = true
            }
            if (f) {
                b.afterSuccess.call(b.afterSuccessScope, h)
            }
            if (b.aCallback) {
                var g = b.aCallback.call(this, h);
                if (g === false) {
                    return
                }
            }
            if (f === false) {
                var i = h.returnmsg || h.head_rtn_desc;
                Tools.alert((a || "查询") + "失败：" + i, Tools.Msg.ERROR)
            }
        }
    });
    b.data = Tools.json2get(b.params);
    delete b.params;
    c.ajax(b)
};
Util.removeNull = function (a) {
    for (key in a) {
        if (a[key] == null) {
            delete a[key]
        }
    }
};
Util.renderer = {};
Util.renderer.getRenderer = function (a) {
    var b = null;
    switch (a) {
        case"date":
            b = Tools.dateFormat;
            break;
        case"time":
            b = Tools.timeFormat;
            break;
        case"datetime":
            b = Tools.datetimeFormat;
            break;
        case"money":
            b = Tools.moneyStr;
            break;
        case"double":
        case"bigdecimal":
            b = function (c) {
                return Tools.formatDecimal(c, null, true)
            };
            break;
        case"percent":
            b = function (c) {
                return Tools.formatDecimal(c, null, true) + "%"
            };
            break;
        case"long":
        case"int":
            b = function (c) {
                return Tools.formatDecimal(c, 0, true)
            };
            break
    }
    return b
};
Util.dictMng = {
    DICTS: {}, dict: function (b) {
        var a = Util.dictMng.DICTS[b];
        if (a == null) {
            a = Util.dictMng.ajaxGetDict(b);
            Util.dictMng.DICTS[b] = a
        }
        return a
    }, transfer: function (g, c) {
        if (g == null || g == "" || c == null || c == "") {
            return ""
        }
        var f = Util.dictMng.dict(g);
        if (f == null) {
            return c
        }
        var e = [];
        var d = String(c).split(",");
        var a = d.length;
        for (var b = 0; b < a; b++) {
            k = Tools.trim(String(d[b]));
            if (k) {
                e.push(f[k] == null ? "" : f[k])
            }
        }
        return e.join("，")
    }, ajaxGetDict: function (c) {
        var b = null;
        var a = "base/dict/" + c + ".json";
        $.ajax({
            url: a, async: false, type: "POST", dataType: "json", success: function (d) {
                b = d
            }
        });
        return b
    }
};
Util.dictManager = Util.dictMng;
Util.printForm = function (a, b) {
    b.jasper = a;
    Tools.submit2BlankWindow("form-print.report", b)
};
Util.getWorkflowSubmitParams = function (a) {
    var b;
    Util.ajaxQuery({
        url: "workflow/custom/getSubmitParams.json",
        async: false,
        params: {"processid": a},
        afterSuccess: function (c) {
            b = c.rows[0]
        }
    }, false);
    return b
};
Util.getCreditBalance = function (d) {
    var b = "0";
    Util.ajaxQuery({
        exeid: "M8000SYSPARAM", async: false, params: {"id": "8000012000"}, afterSuccess: function (e) {
            if (e.rows.length == 0) {
                b = "0"
            } else {
                b = e.rows[0].value
            }
        }
    }, false);
    if (b == "0") {
        return true
    }
    var c = {};
    c.PdTp = d.PdTp;
    c.HVBnkNo = d.HVBnkNo;
    c.cashflow = d.cashflow;
    c.SYS_MB = "ams";
    c.businessCode = "80004";
    c.SYS_BUSIID = "8";
    var a = true;
    Util.ajaxRequest({
        url: "bizware",
        serviceCode: "ams",
        businessCode: "80004",
        async: false,
        succesalert: false,
        params: c,
        afterSuccess: function (e) {
            a = true
        },
        afterError: function (e) {
            a = false
        }
    }, false);
    return a
};
Util.updateCreditBalance = function (e) {
    var d = {};
    d.id = e.id;
    d.adtype = e.t8_sys_adtype_id;
    d.transdate = e.tradedate;
    d.cashflow = e.cashflow;
    d.pdtp = e.pdtp;
    d.ftool_code = e.ftool_code;
    d.SYS_MB = "ams";
    d.businessCode = "80003";
    d.SYS_BUSIID = "8";
    var a = true;
    var b = "0";
    Util.ajaxQuery({
        exeid: "M8000SYSPARAM", async: false, params: {"id": "8000012000"}, afterSuccess: function (f) {
            if (f.rows.length == 0) {
                b = "0"
            } else {
                b = f.rows[0].value
            }
        }
    }, false);
    if (b == "0") {
        return true
    }
    if (e.subj_type == "非标资产投资") {
        var c = "";
        Util.ajaxQuery({
            exeid: "M829EQ0012",
            params: {id: e.t8_sys_adtype_id},
            async: false,
            afterSuccess: function (f) {
                if (f.rows.length > 0) {
                    c = f.rows[0].is_bank_credit
                }
            }
        }, false);
        if (c == "1") {
            Util.ajaxRequest({
                url: "bizware",
                serviceCode: "ams",
                businessCode: "80003",
                async: false,
                succesalert: false,
                params: d,
                afterSuccess: function (f) {
                    if (f.head_rtn_code == "000000") {
                        a = true
                    } else {
                        a = false
                    }
                },
                afterError: function (f) {
                    a = false
                }
            });
            return a
        } else {
            return true
        }
    } else {
        Util.ajaxRequest({
            url: "bizware",
            serviceCode: "ams",
            businessCode: "80003",
            async: false,
            succesalert: false,
            params: d,
            afterSuccess: function (f) {
                if (f.head_rtn_code == "000000") {
                    a = true
                } else {
                    a = false
                }
            },
            afterError: function (f) {
                a = false
            }
        });
        return a
    }
};
Util.getRandomFtoolCode = function () {
    return new Date().getTime() + "" + parseInt(Math.random() * 1000)
};
Util.getRandomFtoolCode = function () {
    return new Date().getTime() + "" + parseInt(Math.random() * 1000)
};
Util.get_loginname = function () {
    var a = "";
    Util.ajaxQuery({
        exeid: "M8291EQ0027", params: {}, async: false, afterSuccess: function (b) {
            a = b.rows[0].sys_user_loginname
        }
    }, false);
    return a
};
Util.OperaLimit = function (b) {
    b.trade_date = b.tradedate;
    if (b.t8_sys_portfol_id == undefined) {
        b.t8_sys_portfol_id = b.portfolio
    }
    if (b.trade_date == undefined) {
        b.trade_date = b.account_date
    }
    if (b.oside_code == undefined) {
        b.oside_code = Util.getOsideCodeById(b.t8_oside_basei_id)
    }
    var a = Util.queryHead_OsideCode(b);
    if (a != "") {
        b.oside_code = a
    }
    if (b.dir_type == -1) {
        Util.getDeduLimitAmount(b)
    } else {
        if (b.dir_type == 2) {
            return Util.getLimitAmount(b)
        } else {
            Tools.alert("授信额度类型有误");
            false
        }
    }
};
Util.getLimitAmount = function (b) {
    var a;
    Util.ajaxRequest({
        url: "credit/Opera_Credit_Limit.json", params: b, async: false, afterSuccess: function (c) {
            a = c;
            return false
        }
    }, false);
    return a
};
Util.getDeduLimitAmount = function (a) {
    Util.ajaxRequest({
        exeid: "M898EU0023", params: a, async: false, afterSuccess: function (b) {
            return false
        }
    }, false)
};
Util.getOsideCodeById = function (a) {
    var b = "";
    Util.ajaxQuery({
        exeid: "M898EQ0024", params: {t8_oside_basei_id: a}, async: false, afterSuccess: function (c) {
            b = c.rows[0].oside_code
        }
    }, false);
    return b
};
Util.getItemByT8SysAdTypeId = function (a) {
    var b = "";
    Util.ajaxQuery({
        exeid: "M898EQ0015", params: {t8_sys_adtype_id: a}, async: false, afterSuccess: function (c) {
            b = c.rows[0].pdtp
        }
    }, false);
    return b
};
Util.isChcekToXL = function (b) {
    var a = false;
    Util.ajaxQuery({
        exeid: "M898EQ0016", params: b, async: false, afterSuccess: function (c) {
            if (c.rows.length > 0) {
                if (c.rows[0].prod_series_code != undefined && c.rows[0].prod_series_code != "") {
                    a = true
                }
            }
            return false
        }
    }, false);
    return a
};
Util.queryHead_OsideCode = function (b) {
    var a = "";
    Util.ajaxQuery({
        exeid: "M898EQ0029", params: b, async: false, afterSuccess: function (c) {
            if (c.rows.length > 0) {
                a = c.rows[0].oside_code
            }
            return false
        }
    }, false);
    return a
};
Util.getOsideToFtoolCode = function (b) {
    var a = "";
    Util.ajaxQuery({
        exeid: "M898EQ0033", params: b, async: false, afterSuccess: function (c) {
            if (c.rows.length > 0) {
                a = c.rows[0].oside_code
            }
            return false
        }
    }, false);
    return a
};
var isie, isop, isff, iscr, issf;
(function () {
    var a = navigator.userAgent.toLowerCase();
    isie = a.indexOf("msie") > -1;
    isop = a.indexOf("opera") > -1;
    isff = a.indexOf("firefox") > -1;
    iscr = a.indexOf("chrome") > -1;
    issf = a.indexOf("safari") > -1
})();
var TAB_CHAR = String.fromCharCode(9);

function specilKeyCode(a) {
    switch (a) {
        case 9:
        case 12:
        case 13:
        case 16:
        case 17:
        case 18:
        case 19:
        case 20:
        case 27:
        case 33:
        case 34:
        case 35:
        case 36:
        case 37:
        case 38:
        case 39:
        case 40:
        case 41:
        case 42:
        case 43:
        case 45:
        case 46:
        case 47:
        case 112:
        case 113:
        case 114:
        case 115:
        case 116:
        case 117:
        case 118:
        case 119:
        case 120:
        case 121:
        case 122:
        case 123:
        case 124:
        case 125:
        case 126:
        case 127:
        case 128:
        case 129:
        case 130:
        case 131:
        case 132:
        case 133:
        case 134:
        case 135:
        case 136:
        case 137:
            return true
    }
    return false
}

var FIELD_SELECTOR = "input[name],input[data-name],select[name],textarea[name]";
var FIELD_SELECTOR_NOHIDDEN = 'input[name][type!="hidden"],input[data-name][type!="hidden"],select[name],textarea[name]';

function getFieldSelector(b, a) {
    if (a == null) {
        a = ""
    } else {
        if (a.charAt(0) != ".") {
            a = "." + a
        }
    }
    return 'input[name="' + b + '"]' + a + ',select[name="' + b + '"]' + a + ',textarea[name="' + b + '"]' + a
}

function encodeDivHtml(a) {
    return Tools.htmlDecode(a.replace(/[<][\/]div[>]/g, "").replace(/<br[\/]><div>/g, "\n").replace(/<div>/g, "\n").replace(/<br[\/]>/g, "\n"))
}

function nl2br(a) {
    return Tools.htmlEncode(a).replace("\n", "<br/>")
}

function br2nl(a) {
    return a.replace("<br/>", "\n")
}

function zero2empty(a) {
    if (a == 0 || a == "0") {
        return ""
    }
    return a
}

function inputTab(j) {
    var g = j.srcElement || j.target || window.event;
    var h = j.keyCode || j.which;
    var q = $(g);
    var c = q.attr("data-disabled");
    if (h == 13) {
        if (g.tagName == "TEXTAREA") {
            return
        }
        j.preventDefault();
        if (g.tagName == "INPUT" || g.tagName == "SELECT") {
            var a = $(FIELD_SELECTOR_NOHIDDEN);
            idx = a.index(g) + 1;
            if (a.length > idx) {
                var l = true;
                while (l) {
                    var p = $(a[idx]);
                    c = $(a[idx]).attr("data-disabled");
                    var d = $(a[idx]).attr("disabled");
                    if (c != "true" && !d) {
                        l = false
                    } else {
                        idx = a.index(p) + 1;
                        if (a.length <= idx) {
                            l = false
                        }
                    }
                }
                g.blur();
                a[idx].focus()
            } else {
                g.blur()
            }
        }
        return
    }
    if (g.tagName == "INPUT") {
        var q = $(g);
        var o = g.value;
        var n = null;
        var f = q.attr("data-validate-type") || q.attr("data-type");
        if (f == "number" || f == "money" || f == "int" || f == "code") {
            var i = o.indexOf(".");
            var m = o.indexOf("-");
            if ((j.ctrlKey == true && h == 65) || (j.ctrlKey == true && h == 88) || (j.ctrlKey == true && h == 86) || (j.ctrlKey == true && h == 67) || (j.ctrlKey == true && h == 90)) {
            } else {
                if (((h > 48 || h == 32) && (h < 48 || h > 57) && (h < 96 || h > 105))) {
                    if ((f == "number" || f == "money") && (h == 190 || h == 110) && o != "" && i == -1) {
                    } else {
                        if ((f == "number" || f == "money" || f == "int") && (((h == 189 || h == 109) && o == "") || (h == 189 && o != "" && m == -1))) {
                        } else {
                            j.returnValue = false;
                            return false
                        }
                    }
                }
            }
        }
        var b = Number(q.attr("data-max-length"));
        if (!isNaN(b) && b > 0) {
            if (n == null) {
                n = Tools.gblen(o)
            }
            if ((j.ctrlKey == true && h == 65) || (j.ctrlKey == true && h == 88) || (j.ctrlKey == true && h == 86) || (j.ctrlKey == true && h == 67) || (j.ctrlKey == true && h == 90)) {
            } else {
                if (((h >= 48 || h == 32) && n >= b) || (h == 229 && n >= b - 1)) {
                    j.returnValue = false;
                    return false
                }
            }
        }
    }
}

function colorKeyWord(h, e, c) {
    var g = [].concat(e), a = g.length;
    var f = [];
    for (var d = 0; d < a; d++) {
        var b = g[d];
        if (Tools.indexOfArray(f, b) == -1) {
            f.push(b)
        }
    }
    return h.replace(new RegExp(f.join("|"), "g"), '<font color="' + c + '">$&</font>')
}

$(function () {
    $(document.body).keydown(inputTab)
});

function textareaAutoHeight() {
    var b = $(this);
    if (this.scrollHeight > b.outerHeight()) {
        b.height(this.scrollHeight)
    } else {
        var a = Number(b.css("min-height").replace("px", ""));
        if (b.height() > a) {
            b.height(a);
            if (this.scrollHeight > b.outerHeight()) {
                b.height(this.scrollHeight)
            }
        }
    }
}

function fuc_str2Json(str) {
    if (!str) {
        return null
    }
    var json = null;
    try {
        json = eval("(" + str + ")")
    } catch (e) {
        K.logerror("json字符串" + e)
    }
    return json
}

function getParam(c) {
    var a = {};
    var b;
    if (typeof c == "string") {
        b = $("#" + c)
    } else {
        b = c
    }
    b.find(FIELD_SELECTOR).each(function () {
        var h = $(this), d = this.name, e = h.val();
        var g = a[d];
        if (g == null) {
            switch (h.attr("type")) {
                case"radio":
                case"checkbox":
                    if (this.checked) {
                        a[d] = Tools.trim(this.value)
                    }
                    break;
                default:
                    if (h.hasClass("datepicker")) {
                        var f = h.attr("data-date-format");
                        if (f) {
                            f = f.replace("yyyy", "|").replace("mm", "|").replace("m", "|").replace("dd", "|").replace("d", "|").replace("||", "|").replace("||", "|").replace(/^[|]/, "");
                            e = e.replace(new RegExp(f, "g"), "")
                        }
                    }
                    a[d] = Tools.trim(e)
            }
        } else {
            switch (h.attr("type")) {
                case"radio":
                case"checkbox":
                    if (this.checked) {
                        if (!Tools.isArray(g)) {
                            a[d] = [g]
                        }
                        a[d].push(Tools.trim(this.value))
                    }
                    break;
                default:
                    if (!Tools.isArray(g)) {
                        a[d] = [g]
                    }
                    if (h.hasClass("datepicker")) {
                        var f = h.attr("data-date-format");
                        if (f) {
                            f = f.replace("yyyy", "|").replace("mm", "|").replace("m", "|").replace("dd", "|").replace("d", "|").replace("||", "|").replace("||", "|").replace(/^[|]/, "");
                            e = e.replace(new RegExp(f, "g"), "")
                        }
                    }
                    a[d].push(Tools.trim(e))
            }
        }
    });
    return a
}

function setParam(e, c) {
    var d;
    if (typeof e == "string") {
        d = $("#" + e)
    } else {
        d = e
    }
    for (var a in c) {
        var b = c[a];
        d.find(getFieldSelector(a)).each(function (f) {
            setValue(this, b)
        })
    }
}

function setValue(g, h) {
    var c = $(g);
    switch (g.type) {
        case"radio":
        case"checkbox":
            var d = g.value;
            if (!Tools.isArray(h)) {
                if (h != null && h.indexOf(",") > -1) {
                    h = h.split(",")
                } else {
                    h = [h]
                }
            }
            if (Tools.indexOfArray(h, d) > -1) {
                g.checked = true
            } else {
                g.checked = false
            }
            break;
        default:
            if (c.hasClass("datepicker")) {
                var f = c.attr("data-date-format");
                if (f) {
                    var b = h.substr(0, 4), e = h.substr(4, 2), a = h.substr(6, 2);
                    h = f.replace("yyyy", b).replace("mm", e).replace("m", Number(e)).replace("dd", a).replace("d", Number(a))
                }
            }
            c.val(h).data("oriValue", h)
    }
}

function getValue(c, a) {
    $obj = $(c);
    var b = null;
    $obj.find(getFieldSelector(a)).each(function () {
        var f = $(this);
        var e = f.val();
        if (b == null) {
            switch (f.attr("type")) {
                case"radio":
                case"checkbox":
                    if (this.checked) {
                        b = Tools.trim(this.value)
                    }
                    break;
                default:
                    if (f.hasClass("datepicker")) {
                        var d = f.attr("data-date-format");
                        if (d) {
                            d = d.replace("yyyy", "|").replace("mm", "|").replace("m", "|").replace("dd", "|").replace("d", "|").replace("||", "|").replace("||", "|").replace(/^[|]/, "");
                            b = b.replace(new RegExp(d, "g"), "")
                        }
                    }
                    b = Tools.trim(e)
            }
        } else {
            switch (f.attr("type")) {
                case"radio":
                case"checkbox":
                    if (this.checked) {
                        b = Tools.trim(this.value)
                    }
                    break;
                default:
                    if (f.hasClass("datepicker")) {
                        var d = f.attr("data-date-format");
                        if (d) {
                            d = d.replace("yyyy", "|").replace("mm", "|").replace("m", "|").replace("dd", "|").replace("d", "|").replace("||", "|").replace("||", "|").replace(/^[|]/, "");
                            b = b.replace(new RegExp(d, "g"), "")
                        }
                    }
                    b.push(Tools.trim(e))
            }
        }
    });
    return b
}

window.K = {
    init: {form: {}, field: {}, grid: {}, treegrid2: {}, tab: {}, step: {}, btn: {}, upload: {}},
    form: {},
    field: {
        text: {},
        display: {},
        date: {},
        time: {},
        textarea: {},
        checkbox: {},
        radio: {},
        select: {},
        mselect: {},
        tree: {},
        mtree: {},
        btndate: {},
        btnselect: {},
        btnmselect: {},
        btntree: {},
        search: {},
        mInput: {},
        bswitch: {},
        mselecttree: {}
    },
    grid: {},
    treegrid: {},
    treegrid2: {},
    tab: {},
    step: {},
    btn: {}
};
window["K"] = K;
K.argsCall = Tools.argsCall;
K.logerror = Tools.logerror;
K.logdebug = Tools.logdebug;
K.doEvent = Tools.doEvent;
K.firechange = function (b, c) {
    var a = $(b);
    if (a.length == 0) {
        return
    }
    a.data("k-firechange-callback", c);
    if (navigator.userAgent.indexOf("MSIE") > 0) {
        a.trigger("keyup")
    } else {
        a.trigger("input")
    }
};
K.onchange = function (e, c) {
    var b = $(e);
    if (b.length == 0) {
        return
    }
    var a = b.data("k-on-change-functions");
    if (a == null) {
        a = []
    }
    a.push(c);
    b.data("k-on-change-functions", a);
    var d = function (f) {
        b.data("k-field-last-keyup", (new Date()).getTime());
        window.setTimeout(function () {
            K.onchange.change.call(b[0], f)
        }, K.onchange.KEYDOWN_DELAY + 1)
    };
    if (navigator.userAgent.indexOf("MSIE") > 0) {
        b.on("keyup", d);
        b.on("blur", function (f) {
            K.onchange.change.call(this, f)
        })
    } else {
        b.on("input", d)
    }
};
K.onchange.KEYDOWN_DELAY = 400;
K.onchange.change = function (f) {
    var d = $(this);
    var a = d.data("k-field-last-keyup");
    if (a == null) {
        return
    }
    if (a + K.onchange.KEYDOWN_DELAY > (new Date()).getTime()) {
        return
    }
    var g = d.val();
    if (g == d.attr("data-k-onchange-last-value")) {
        return
    }
    var c = d.data("k-on-change-functions");
    if (c != null) {
        for (var b = 0; b < c.length; b++) {
            c[b].call(this, f)
        }
    }
    d.attr("data-k-onchange-last-value", g);
    var h = d.data("k-firechange-callback");
    if (h != null && typeof h == "function") {
        h.call(this, f)
    }
    d.data("k-firechange-callback", null)
};
K.init = function (a) {
    if (a == null) {
        a = "body"
    }
    var c, b;
    for (c in K.init) {
        b = K.init[c];
        if (typeof b == "function") {
            b(a)
        }
    }
    var d;
    if (typeof a == "string") {
        d = $(a)
    } else {
        d = a
    }
    if (d.length == 0) {
        return
    }
    d.find(".panel-heading > .k-btn-collapse").each(function () {
        var e = $(this);
        if (e.attr("data-k-inited") == "true") {
            return
        }
        e.attr("data-k-inited", "true");
        e.addClass("close glyphicon glyphicon-chevron-down").click(function () {
            var f = $(this), g = f.parent(".panel-heading").parent(".panel");
            if (f.hasClass("glyphicon-chevron-up")) {
                f.attr("title", "隐藏");
                g.find(".panel-body").show();
                g.find(".panel-toolbar,.panel-footer").show();
                f.removeClass("glyphicon-chevron-up").addClass("glyphicon-chevron-down")
            } else {
                f.attr("title", "显示");
                g.find(".panel-body").hide();
                g.find(".panel-toolbar,.panel-footer").hide();
                f.removeClass("glyphicon-chevron-down").addClass("glyphicon-chevron-up")
            }
        });
        e.parents(".panel").find(".panel-body").addClass("collapse in")
    })
};
K.documentClickHide = function (e, b, d) {
    var g = $(document);
    var a = K.documentClickHide.classes.length;
    for (var c = 0; c < a; c++) {
        var f = K.documentClickHide.classes[c];
        if (f.el == e) {
            return
        }
    }
    K.documentClickHide.classes.push({el: e, list: b, fn: d})
};
K.documentClickHide.classes = [];
K.findListField = function (b, a) {
    return $(b).parents("." + a).length > 0
};
K.init.form = function (a) {
    var b;
    if (a) {
        b = $(a)
    } else {
        b = $(document.body)
    }
    b.find(FIELD_SELECTOR_NOHIDDEN).focus(function () {
        $(this).attr("data-k-i-am-focus", true)
    });
    b.find(FIELD_SELECTOR_NOHIDDEN).blur(function () {
        $(this).attr("data-k-i-am-focus", false)
    })
};
K.submit = function (a, d, c) {
    var g;
    if (typeof a == "string") {
        g = $(a)
    } else {
        g = a
    }
    if (g.length == 0) {
        return
    }
    var f = K.form.params(g);
    if (c === true) {
        var e = getParam(g);
        setParam(g, f);
        g[0].submit();
        return
    }
    if (d.exeid || d.submitUrl) {
        var b = {
            params: f, afterSuccess: function (i) {
                if (i.afterSuccess) {
                    var h = K.doEvent(g[0], i.afterSuccess, f, i);
                    if (h === false) {
                        return false
                    }
                }
                if (i.callback) {
                    var h = K.doEvent(g[0], i.callback, f, i);
                    if (h === false) {
                        return false
                    }
                }
                return true
            }
        };
        if (d.submitUrl) {
            if (d.submitUrl == "bizware") {
                Tools.apply(b, {serviceCode: d.serviceCode, businessCode: d.businessCode})
            } else {
                Tools.apply(b, {url: d.submitUrl})
            }
            Util.ajaxRequest(b)
        } else {
            if (data_exeid) {
                Tools.apply(b, {exeid: d.exeid});
                Util.ajaxRequest(b)
            }
        }
    }
};
K.form.params = function (a) {
    var e;
    if (typeof a == "string") {
        e = $(a)
    } else {
        e = a
    }
    if (e.length == 0) {
        return
    }
    var c = {};
    var b = e.find(K.field.selectorAll());
    var d = b.hasClass("k-field-search");
    b.each(function () {
        var i = $(this), l = K.field.value(i);
        if (i.hasClass("k-field-search")) {
            Tools.apply(c, l);
            return
        }
        if (d && i.parents(".k-field-search")) {
            return
        }
        if (i.attr("name") != null && i.attr("name") != "") {
            var j = i.attr("name");
            var h = j + "_" + "display" + "lable";
            var f = i.val();
            if (c[i.attr("name")] != null) {
                c[i.attr("name")] = [].concat(c[i.attr("name")]);
                c[i.attr("name")].push(l);
                c[h] = [].concat(c[h]);
                c[h].push(f)
            } else {
                c[i.attr("name")] = l;
                c[h] = f
            }
        } else {
            var g = i.attr("data-name");
            var h = g + "_" + "displaylable";
            var f = i.val();
            if (c[i.attr("data-name")] != null) {
                c[i.attr("data-name")] = [].concat(c[i.attr("name")]);
                c[i.attr("data-name")].push(l);
                c[h] = [].concat(c[h]);
                c[h].push(f)
            } else {
                c[i.attr("data-name")] = l;
                c[h] = f
            }
        }
    });
    return c
};
K.form.validate = function (a) {
    $obj = $(a);
    var b = 0;
    $obj.find(K.field.selectorAll()).each(function () {
        var d = $(this), c = K.field.validate(d);
        if (c != true) {
            b = 1
        }
    });
    if (b == 1) {
        return false
    } else {
        return true
    }
};
K.form.setparams = function (a, b) {
    if (b) {
        $obj = $(a);
        $obj.find(K.field.selectorAll()).each(function () {
            var c = $(this);
            if (c.attr("name") != null && c.attr("name") != "") {
                var d = b[c.attr("name")];
                if (d != undefined && d != null) {
                    K.field.value(c, d)
                } else {
                    K.field.value(c, "")
                }
            } else {
                var d = b[c.attr("data-name")];
                if (d != undefined && d != null) {
                    K.field.value(c, d)
                } else {
                    K.field.value(c, "")
                }
            }
        })
    }
};
K.form.reset = function (a) {
    $obj = $(a);
    $obj.find(K.field.selectorAll()).each(function () {
        var b = $(this);
        K.field.reset(b)
    })
};
K.init.field = function (a) {
    if (a == null) {
        a = "body"
    }
    var c, b;
    for (c in K.init.field) {
        b = K.init.field[c];
        if (typeof b == "function") {
            var d = b(a);
            if (d) {
                d.each(function () {
                    var e = $(this);
                    if (e.attr("data-k-fieldtype")) {
                        return
                    }
                    e.attr("data-k-fieldtype", c);
                    if (e.attr("data-value") !== "" && e.attr("data-value") !== undefined) {
                        e.data("k-field-ori-value", e.attr("data-value"))
                    } else {
                        if (e.attr("value") !== "" && e.attr("value") !== undefined) {
                            e.data("k-field-ori-value", e.attr("value"))
                        }
                    }
                    if (e.attr("data-allowblank") == "false") {
                        K.field.allowblank(e, false)
                    }
                    if (e.attr("data-onpaste-disable") == "true") {
                        e.attr("onpaste", "return false")
                    }
                })
            }
        }
    }
};
K.field.SELECTOR = {};
K.field.pushSelector = function (b, a) {
    K.field.SELECTOR[b] = a
};
K.field.selectorAll = function (c) {
    var a = [];
    for (var b in K.field.SELECTOR) {
        a.push(K.field.selector(b, c))
    }
    return a.join(",")
};
K.field.selector = function (c, b) {
    var a = K.field.SELECTOR[c];
    if (b == null) {
        return a
    }
    if (a.match(/^(?:input|select|textarea|button)/)) {
        a = a + '[name="' + b + '"]'
    } else {
        a = a + '[data-name="' + b + '"]'
    }
    return a
};
K.field.get = function (c, a) {
    var b;
    if (a == null) {
        b = $(c)
    } else {
        if (typeof c == "string") {
            b = $('form[name="' + c + '"]')
        }
        b = b.find(K.field.selectorAll(a))
    }
    if (b.length > 0 && b.is(K.field.selectorAll())) {
        return b
    }
    return null
};
K.field.is = function (b) {
    if (b == null) {
        return false
    }
    if (b.length == 0) {
        return false
    }
    if (!b.is(K.field.selectorAll())) {
        K.logerror("K.field.is[1]:非法的字段对象:" + b[0].outerHTML);
        return false
    }
    var a = b.attr("data-k-fieldtype");
    if (a == null || a == "") {
        K.logerror("K.field.is[2]:未初始化的字段对象");
        return false
    }
    if (K.field[a] == null) {
        K.logerror("K.field.is[3]:非法的字段对象");
        return false
    }
    return a
};
K.field.value = function (d, c) {
    var b = $(d);
    var a = K.field.is(b);
    if (!a) {
        return undefined
    }
    if (K.field[a].value == null) {
        K.logerror("K.field.value[1]:组件不支持value方法");
        return undefined
    }
    return K.field[a].value(d, c)
};
K.field.text = function (c) {
    var b = $(c);
    var a = K.field.is(b);
    if (!a) {
        return undefined
    }
    if (K.field[a].text == null) {
        return K.field.value(c)
    }
    return K.field[a].text(c)
};
K.field.allowblank = function (d, c) {
    var b = $(d);
    var a = K.field.is(b);
    if (!a) {
        return
    }
    if (c) {
        b.attr("data-allowblank", "true");
        b.removeClass("k-field-not-allowblank")
    } else {
        b.attr("data-allowblank", "false");
        b.addClass("k-field-not-allowblank")
    }
    K.field.clearerr(b)
};
K.field.disable = function (c) {
    var b = $(c);
    var a = K.field.is(b);
    if (!a) {
        return
    }
    if (K.field[a].disable == null) {
        b.attr("disabled", "disabled");
        return
    }
    return K.field[a].disable(c)
};
K.field.enable = function (c) {
    var b = $(c);
    var a = K.field.is(b);
    if (!a) {
        return
    }
    if (K.field[a].enable == null) {
        b.removeAttr("disabled");
        return
    }
    return K.field[a].enable(c)
};
K.field.reset = function (e) {
    var d = $(e);
    var c = K.field.is(d);
    if (!c) {
        return
    }
    var b = d.data("k-field-ori-value");
    var a = null;
    if (b !== undefined && b !== "") {
        a = b
    }
    K.field[c].value(d, a);
    if (c == "select" || c == "date") {
        d.attr("data-last-value", "")
    }
    if (c == "mselect") {
        d.attr("data-value", "")
    }
    K.field.clearerr(d)
};
K.field.show = function (c) {
    var b = $(c);
    var a = K.field.is(b);
    if (!a) {
        return
    }
    b.parents(".k-field").show()
};
K.field.hide = function (c) {
    var b = $(c);
    var a = K.field.is(b);
    if (!a) {
        return
    }
    b.parents(".k-field").hide()
};
K.field.computeValue = function (e, d) {
    if (d == null) {
        return d
    }
    var g = d.match(/[{]([^}]*)[}]/g);
    if (g == null) {
        return d
    } else {
        var f = d;
        var b = e.parents("form");
        var g, c, h, a;
        while (g = f.match(/[{]([^}]*)[}]/)) {
            c = g[1];
            a = b.find(K.field.selectorAll(c));
            if (a.length == 0) {
                a = $(c)
            }
            h = K.field.value(a);
            f = f.replace(g[0], h)
        }
        return f
    }
};
K.field.validate = function (n) {
    var m = $(n);
    var c = K.field.is(m);
    if (!c) {
        return
    }
    K.field.clearerr(m);
    if (m.parents(".k-field").css("display") == "none") {
        return true
    }
    var p = K.field.value(m);
    var o = [];
    if (m.attr("data-allowblank") == "false" && (p == null || p == "" || Tools.trim(p) == "")) {
        o.push("该输入项不允许为空")
    }
    var e = K.doEvent(m[0], m.attr("data-validate"), p);
    if (e && e !== true) {
        o.push(e)
    }
    var l = Tools.gblen(p);
    var d = m.attr("data-min-length");
    if (d && parseInt(d) > l && (p != null && p != "")) {
        o.push("该输入项的长度最少为" + d)
    }
    var a = Number(m.attr("data-max-length"));
    if (!isNaN(a) && a > 0 && a < l && (p != null && p != "")) {
        o.push("该输入项的长度最大为" + a);
        var g = Number(a);
        var j = p.substr(0, g);
        K.field.value(m, j)
    }
    var b = m.attr("data-regx");
    if (b) {
        if (!(new RegExp(b)).test(p)) {
            var f = m.attr("data-regx-text");
            var e = f || ("正则验证不通过" + ":" + b);
            o.push(e)
        }
    }
    if (K.field[c].validate) {
        var h = K.field[c].validate(m);
        if (h !== true) {
            o = o.concat(h)
        }
    }
    if (o.length > 0) {
        if (o.length == 1) {
            K.field.errormsg(m, o);
            return o
        } else {
            o = o[0];
            K.field.errormsg(m, o);
            return o
        }
    }
    return true
};
K.field.dict = function (c, d) {
    var b = $(c);
    var a = K.field.is(b);
    if (!a) {
        return undefined
    }
    if (K.field[a].dict == null) {
        K.logerror("K.field.dict[1]:组件不支持dict方法");
        return undefined
    }
    return K.field[a].dict(c, d)
};
K.field.reloadData = function (b, c) {
    var a = $(b);
    a.each(function () {
        var e = $(this);
        var d = K.field.is(e);
        if (!d) {
            return undefined
        }
        if (K.field[d].reloadData == null) {
            K.logerror("K.field.reloadData[1]:组件不支持reloadData方法");
            return undefined
        }
        K.field[d].reloadData(b, c)
    })
};
K.field.greenmsg = function (c, b) {
    var a = $(c);
    if (b == null || b == "" || b.length == 0) {
        a.data("k-field-messages", null)
    } else {
        a.data("k-field-messages", [].concat(b))
    }
    K.field.initPopover(a)
};
K.field.clearerr = function (c) {
    var b = $(c);
    var a = K.field.is(b);
    if (!a) {
        return
    }
    b.removeClass("k-field-error");
    b.data("k-field-errors", null);
    K.field.initPopover(b)
};
K.field.errormsg = function (b, c) {
    var a = $(b);
    if (c == null || c == "" || c.length == 0) {
        a.removeClass("k-field-error");
        a.data("k-field-errors", null)
    } else {
        a.addClass("k-field-error");
        a.data("k-field-errors", [].concat(c))
    }
    K.field.initPopover(a)
};
K.field.hideover = function (b, c, a) {
    if (a) {
        b.removeClass("k-field-error")
    }
    if (c !== true && b.attr("data-k-i-am-focus") == "true" && (b.data("k-field-errors") || b.data("k-field-messages"))) {
        return
    }
    b.popover("hide")
};
K.field.showover = function (a) {
    if (a.hasClass("k-field-error") || a.data("k-field-messages")) {
        a.popover("show")
    }
};
K.field.initPopover = function (a) {
    if (a.data("k-field-popover-inited") !== true) {
        a.data("k-field-popover-inited", true);
        a.popover({
            placement: "bottom", trigger: "manual", html: true, content: function () {
                var h = $(this), b = h.data("k-field-errors"), f = h.data("k-field-messages");
                var c = "";
                if (f && f.length > 0) {
                    var d = '<li class="k-field-message">', g = "</li>";
                    c = c + d + f.join(g + d) + g
                }
                if (b && b.length > 0) {
                    var d = '<li class="k-field-error"><span class="glyphicon glyphicon-exclamation-sign"></span>',
                        g = "</li>";
                    c = c + d + b.join(g + d) + g
                }
                if (c == "") {
                    return false
                } else {
                    return '<ul class="k-field-popover-ul">' + c + "</ul>"
                }
            }
        }).focus(function () {
            var b = $(this);
            if (b.data("bs.popover") && b.data("bs.popover").tip().hasClass("in")) {
                return
            }
        }).mouseenter(function () {
            var b = $(this);
            if (b.data("bs.popover") && b.data("bs.popover").tip().hasClass("in")) {
                return
            }
        }).mouseleave(function () {
            K.field.hideover($(this))
        }).blur(function () {
        })
    }
    K.field.showover(a);
    window.setTimeout(function () {
        K.field.hideover(a, true, true)
    }, 2000)
};
K.init.field.text = function (a) {
    var b;
    if (a) {
        b = $(a)
    } else {
        b = $(document.body)
    }
    K.field.pushSelector("text", "input.k-field-text");
    return b.find("input.k-field-text:not(.k-donot-init)").each(function () {
        var f = $(this);
        if (f.attr("data-k-inited") == "true") {
            return
        }
        f.attr("data-k-inited", "true");
        var d = f.attr("data-validate-type") || f.attr("data-type");
        switch (d) {
            case"number":
            case"money":
            case"int":
            case"zint":
                f.css("text-align", "right");
                break
        }
        f.focus(function (g) {
            switch (d) {
                case"number":
                case"money":
                    var h = f.val();
                    f.val(!h ? h : h.replace(/[,]/g, ""));
                    break
            }
            K.doEvent(f[0], f.attr("data-on-focus"), K.field.text.value(f));
            f.select()
        });
        f.blur(function (n) {
            var l = f.attr("data-digits");
            var p = K.field.value(f);
            if (p != "" && p != undefined && p != null) {
                if (d == "money") {
                    if (!l) {
                        l = 2
                    }
                    var o = p.split(".");
                    var j = o[0];
                    var h = ".";
                    if (o.length > 1) {
                        for (var g = 1; g < o.length; g++) {
                            h = h + o[g]
                        }
                        j = parseInt(j, 10) + h
                    } else {
                        j = parseInt(j, 10)
                    }
                    var i = Tools.formatDecimal(j, l, true) + "";
                    if (i.indexOf("-,") > -1) {
                        i = i.replace(/-,/g, "-")
                    }
                    f.val(!p ? p : i)
                } else {
                    if (d == "number") {
                        if (l) {
                            var i = Tools.formatDecimal(p, l, true) + "";
                            if (i.indexOf("-,") > -1) {
                                i = i.replace(/-,/g, "-")
                            }
                            f.val(!p ? p : i)
                        } else {
                            var i = Tools.formatDecimal(p, null, true) + "";
                            if (i.indexOf("-,") > -1) {
                                i = i.replace(/-,/g, "-")
                            }
                            f.val(!p ? p : i)
                        }
                    } else {
                        if (d == "int") {
                            f.val(parseInt(K.field.value(f)))
                        } else {
                            if (d == "zint") {
                                f.val(parseInt(K.field.value(f)))
                            }
                        }
                    }
                }
            }
            K.doEvent(f[0], f.attr("data-on-blur"), K.field.text.value(f))
        });
        K.onchange(f, function (j) {
            var h = $(this), i = K.field.text.value(h), g = h.attr("data-k-last-value");
            if (g == i) {
                return
            }
            h.attr("data-k-last-value", i);
            K.doEvent(h[0], h.attr("data-on-change"), i, g);
            var l = f.attr("data-validate-type") || f.attr("data-type");
            if (l == "number" || l == "money" || l == "int" || l == "text" || l == "zint") {
                if (i.indexOf("-") > -1) {
                    i = "-" + i.replace(/-/g, "");
                    h.val(i)
                }
            }
            if (f.attr("data-alert") != "false") {
                K.field.validate(h)
            }
        });
        if (f.attr("data-disabled") == "true") {
            f.attr("disabled", "disabled");
            f.addClass("disabled")
        }
        var e = f.val();
        if (e) {
            K.field.text.value(f, e)
        }
        var c = f.attr("data-value");
        if (c) {
            K.field.text.value(f, c)
        }
    })
};
K.field.text.value = function (f, e) {
    var b = $(f);
    var g = b.attr("data-validate-type") || b.attr("data-type");
    if (e === undefined) {
        var d = b.val();
        if (g == "number" || g == "money") {
            return !d ? d : d.replace(/[,]/g, "")
        }
        return d
    } else {
        if (e === null || e === undefined || e === "") {
            b.val(e);
            return
        }
        var c = b.attr("data-digits");
        if (g == "money") {
            if (!c) {
                c = 2
            }
            var a = Tools.formatDecimal(e, c, true) + "";
            if (a.indexOf("-,") > -1) {
                a = a.replace(/-,/g, "-")
            }
            b.val(a)
        } else {
            if (g == "number") {
                if (!c) {
                    c = null
                }
                var a = Tools.formatDecimal(e, c, true) + "";
                if (a.indexOf("-,") > -1) {
                    a = a.replace(/-,/g, "-")
                }
                b.val(a)
            } else {
                b.val(e)
            }
        }
    }
};
K.field.text.validate = function (field) {
    var $field = $(field);
    var errors = [];
    var moneyMsg = "";
    var value = K.field.text.value($field);
    if (value.length > 0) {
        if (value == "NULL") {
            errors.push("该输入项的值不能为NULL值")
        }
        if (value == "null") {
            errors.push("该输入项的值不能为null值")
        }
        var digits = $field.attr("data-digits");
        switch ($field.attr("data-validate-type") || $field.attr("data-type")) {
            case"text":
                if ((!/^[a-zA-Z0-9\u4E00-\u9FA5\uF900-\uFA2D\s*\,\:\;\.\""\''\-\+\=\_\!]+$/.test(value))) {
                    errors.push("该输入项不允许输入特殊字符")
                }
                break;
            case"number":
                if (!/^(\+|-)?\d+($|\.\d+$)/.test(value)) {
                    if (isNaN(value)) {
                        errors.push("错误的数值");
                        K.field.text.value($field, "")
                    }
                } else {
                    var index = value.indexOf(".");
                    var len;
                    if (index > -1) {
                        len = value.length - index - 1;
                        if (parseInt(len) > parseInt(digits)) {
                            errors.push("最多保留" + digits + "位小数")
                        }
                    }
                }
                break;
            case"money":
                if (/^(\+|-)?\d+($|\.\d+$)/.test(value) || value == "0") {
                    var index = value.indexOf(".");
                    var len;
                    if (index > -1) {
                        if (!digits) {
                            digits = 2
                        }
                        len = value.length - index - 1;
                        if (parseInt(len) > parseInt(digits)) {
                            errors.push("最多保留" + digits + "位小数")
                        }
                    }
                    var data_show_gbmoney = $field.attr("data-show-gbmoney") || "true";
                    if (data_show_gbmoney == "true") {
                        var unitVal = value;
                        var unit = $field.attr("data-unit-value");
                        if (unit) {
                            try {
                                unitVal = parseFloat(value) * parseFloat(unit)
                            } catch (e) {
                                unitVal = value
                            }
                        } else {
                            var v = $field.parent("div").find("label").eq(0).text();
                            if (v.indexOf("万") != -1 && v.indexOf("万份") == -1) {
                                try {
                                    unitVal = parseFloat(value) * parseFloat(10000)
                                } catch (e) {
                                    unitVal = value
                                }
                            } else {
                                if (v.indexOf("亿") != -1) {
                                    try {
                                        unitVal = parseFloat(value) * parseFloat(100000000)
                                    } catch (e) {
                                        unitVal = value
                                    }
                                }
                            }
                        }
                        moneyMsg = Tools.gbMoney(unitVal)
                    }
                } else {
                    if (isNaN(value) && value != "-") {
                        errors.push("错误的金额");
                        K.field.text.value($field, "")
                    }
                }
                break;
            case"email":
                if (!/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(value)) {
                    errors.push("错误的邮箱格式")
                }
                break;
            case"int":
                if (!/^[-\+]?\d+$/.test(value)) {
                    errors.push("该输入项只能输入整数");
                    if (isNaN(value)) {
                        K.field.text.value($field, "")
                    }
                }
                break;
            case"zint":
                if (!/^\+?\d+$/.test(value)) {
                    errors.push("该输入项只能输入正整数");
                    if (isNaN(value)) {
                        K.field.text.value($field, "")
                    }
                }
                break;
            case"code":
                if (!/^[-\+]?\d+$/.test(value)) {
                    errors.push("只能包含0~9的数字");
                    if (isNaN(value)) {
                        K.field.text.value($field, "")
                    }
                }
                break
        }
    }
    var msg = "";
    if (moneyMsg != "") {
        msg = '<span class="money-string">' + moneyMsg + "</span>"
    }
    K.field.greenmsg($field, msg);
    var isnum = false;
    switch ($field.attr("data-validate-type") || $field.attr("data-type")) {
        case"text":
        case"number":
        case"money":
        case"int":
        case"zint":
            isnum = true;
            break
    }
    var minValue = Tools.trim($field.attr("data-min-value"));
    if (minValue && value != "") {
        var sp = "";
        switch (minValue.charAt(0)) {
            case"[":
                sp = ">=";
                break;
            case"(":
                sp = ">";
                break
        }
        if (sp) {
            minValue = minValue.substr(1)
        } else {
            sp = ">="
        }
        var compare_value = K.field.computeValue($field, minValue);
        var compare_eval;
        if (compare_value && compare_value != undefined && compare_value != null && compare_value != "") {
            if (isnum) {
                compare_eval = "Number(value)" + sp + "Number(compare_value)"
            } else {
                compare_eval = "String(value)" + sp + "String(compare_value)"
            }
            if (eval("!(" + compare_eval + ")")) {
                errors.push("该输入项必须" + sp.replace(">", "大于").replace("=", "等于") + compare_value)
            }
        }
    }
    var maxValue = Tools.trim($field.attr("data-max-value"));
    if (maxValue) {
        var lastIndex = maxValue.length - 1;
        var sp = "";
        switch (maxValue.charAt(lastIndex)) {
            case"]":
                sp = "<=";
                break;
            case")":
                sp = "<";
                break
        }
        if (sp) {
            maxValue = maxValue.substring(0, lastIndex)
        } else {
            sp = "<="
        }
        var compare_value = K.field.computeValue($field, maxValue);
        var compare_eval;
        if (compare_value && compare_value != undefined && compare_value != null && compare_value != "") {
            if (isnum) {
                compare_eval = "Number(value)" + sp + "Number(compare_value)"
            } else {
                compare_eval = "String(value)" + sp + "String(compare_value)"
            }
            if (eval("!(" + compare_eval + ")")) {
                errors.push("该输入项必须" + sp.replace("<", "小于").replace("=", "等于") + compare_value)
            }
        }
    }
    if (errors.length > 0) {
        return errors
    }
    return true
};
K.field.text.disable = function (a) {
    $(a).attr("disabled", "disabled")
};
K.field.text.enable = function (a) {
    $(a).removeAttr("disabled")
};

function getFormById(a) {
    return $(a).parent().parent().attr("id")
}

function getFormByName(a) {
    return $(a).parent().parent().attr("name")
}

K.init.field.textarea = function (a) {
    var b;
    if (a) {
        b = $(a)
    } else {
        b = $(document.body)
    }
    K.field.pushSelector("textarea", "textarea.k-field-textarea");
    return b.find("textarea.k-field-textarea:not(.k-donot-init)").each(function () {
        var g = $(this);
        if (g.attr("data-k-inited") == "true") {
            return
        }
        g.attr("data-k-inited", "true");
        g.css("resize", "none");
        g.focus(function (h) {
            K.doEvent(g[0], g.attr("data-on-focus"), K.field.textarea.value(g));
            g.select()
        });
        g.blur(function (h) {
            K.doEvent(g[0], g.attr("data-on-blur"), K.field.textarea.value(g))
        });
        K.onchange(g, function (m) {
            var j = $(this), l = K.field.textarea.value(j), i = j.attr("data-k-last-value");
            if (i == l) {
                return
            }
            j.attr("data-k-last-value", l);
            K.doEvent(j[0], j.attr("data-on-change"), l, i);
            var h = K.field.validate(j)
        });
        if (g.attr("data-disabled") == "true") {
            g.attr("disabled", "disabled")
        }
        if (g.attr("data-statistics") == "true" && parseInt(g.attr("maxlength")) > 0) {
            var c = parseInt(g.attr("maxlength")), f = g.val().length, d = "", e = 13 + 14 * c.toString().length;
            d += '<span class="span-wordwrap"><var class="word-count">' + (c - f) + "</var>/" + c + "</span>";
            g.after(d);
            g.next("span").css("right", e + 20);
            g.next("span").css("top", (parseInt(g.css("height")) - 11));
            g.on("input propertychange", function () {
                $(this).next("span").children(".word-count").text(c - g.val().length)
            })
        }
    })
};
K.field.textarea.value = function (d, c) {
    var a = $(d);
    var e = a.attr("data-validate-type") || a.attr("data-type");
    if (c === undefined) {
        var b = a.val();
        return b
    } else {
        a.val(c);
        a.trigger("input")
    }
};
K.field.textarea.validate = function (a) {
    return true
};
K.field.textarea.disable = function (a) {
    $(a).attr("disabled", "disabled")
};
K.field.textarea.enable = function (a) {
    $(a).removeAttr("disabled")
};
K.init.btn = function (a) {
    var e;
    if (a) {
        e = $(a)
    } else {
        e = $(document.body)
    }
    var d = function () {
        K.btn.simpleButton2($(this))
    };
    e.filter(".k-btn:not(.k-donot-init)").each(d);
    e.find(".k-btn:not(.k-donot-init)").each(d);
    var c, b;
    for (c in K.init.btn) {
        b = K.init.btn[c];
        if (typeof b == "function") {
            b(a)
        }
    }
};
K.btn.disable = function (a) {
    var b;
    if (typeof id == "string") {
        b = $(a)
    } else {
        b = a
    }
    if (b.length == 0) {
        return
    }
    b.attr("disabled", "disabled")
};
K.btn.enable = function (a) {
    var b;
    if (typeof id == "string") {
        b = $(a)
    } else {
        b = a
    }
    if (b.length == 0) {
        return
    }
    b.removeAttr("disabled")
};
K.btn.doDisableCondition = function (a) {
    var d;
    if (typeof id == "string") {
        d = $(a)
    } else {
        d = a
    }
    if (d.length == 0) {
        return
    }
    var b = d.attr("data-disable-condition");
    if (b) {
        var c = d.parents("tr.k-grid-tr");
        if (c.length == 0) {
            c = d.parents("tr.k-treegrid2-tr")
        }
        if (c.length == 0) {
            return
        }
        var f = c.data("data");
        var e = K.doEvent(d[0], b, f);
        if (e) {
            K.btn.disable(d)
        }
    }
};
K.btn.doHiddenCondition = function (a) {
    var c;
    if (typeof id == "string") {
        c = $(a)
    } else {
        c = a
    }
    if (c.length == 0) {
        return
    }
    var e = c.attr("data-hidden-condition");
    if (e) {
        var b = c.parents("tr.k-grid-tr");
        if (b.length == 0) {
            b = c.parents("tr.k-treegrid2-tr")
        }
        var f;
        if (b.length > 0) {
            f = b.data("data")
        }
        var d = K.doEvent(c[0], e, f);
        if (d) {
            c.addClass("k-hidden")
        }
    }
};
K.btn.doAfterSuccess = function (d, e, b) {
    var c = d.attr("data-after-success"), f = d.attr("data-callback");
    if (c) {
        var a = K.doEvent(d[0], c, b, e);
        if (a === false) {
            return false
        }
    }
    if (f) {
        var a = K.doEvent(d[0], f, b, e);
        if (a === false) {
            return false
        }
    }
    return true
};
K.btn.doAfterSuccess2 = function (d, e, b) {
    var c = d.attr("data-after-success");
    if (c) {
        var a = K.doEvent(d[0], c, b, e);
        if (a === false) {
            return false
        }
    }
    return true
};
K.btn.doCallback = function (c, d, b) {
    var e = c.attr("data-callback");
    if (e) {
        var a = K.doEvent(c[0], e, b, d);
        if (a === false) {
            return false
        }
    }
    return true
};
K.btn.handle = function (b, c) {
    var m;
    if (typeof b == "string") {
        m = $(b)
    } else {
        m = b
    }
    if (m.length == 0) {
        return
    }
    if (m.attr("disabled") == "disabled") {
        return
    }
    var r = m.attr("data-from"), q = m.attr("data-exeid"), e = m.attr("data-submitUrl"), o = m.attr("data-confirm"),
        d = m.attr("data-disable-condition"), j = m.attr("data-handler"), a = m.attr("data-param-handler"),
        n = m.attr("data-callback"), h = m.attr("data-functype"), g = m.attr("data-popupclose"),
        l = m.attr("data-descript"), p = m.attr("data-close"), i = m.attr("data-error-alert");
    var f = function () {
        var L = fuc_str2Json(m.attr("data-params")) || {};
        if (L == null) {
            L = {}
        }
        var G = m.attr("class");
        if (G.indexOf("buttonid") != -1) {
            var C = G.substring(G.indexOf("buttonid-") + 9);
            L.button_id = C
        }
        Tools.apply(L, c);
        var Y = m.parents("tr.k-grid-tr");
        if (Y.length == 0) {
            Y = m.parents("tr.k-treegrid2-tr")
        }
        var F = Y.data("data");
        Tools.applyIf(L, F);
        Math.uuidFast = function () {
            var af = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split("");
            var ae = af, ac = new Array(36), ab = 0, ad;
            for (var aa = 0; aa < 36; aa++) {
                if (aa == 8 || aa == 13 || aa == 18 || aa == 23) {
                    ac[aa] = "-"
                } else {
                    if (aa == 14) {
                        ac[aa] = "4"
                    } else {
                        if (ab <= 2) {
                            ab = 33554432 + (Math.random() * 16777216) | 0
                        }
                        ad = ab & 15;
                        ab = ab >> 4;
                        ac[aa] = ae[(aa == 19) ? (ad & 3) | 8 : ad]
                    }
                }
            }
            return ac.join("")
        };
        var t = m.data("k-grid-row");
        if (t) {
            Tools.apply(L, t)
        }
        var W;
        if (r) {
            W = $(r)
        } else {
        }
        if (W) {
            W.each(function () {
                var ab = $(this);
                var aa = K.form.params(ab);
                Tools.apply(L, aa)
            })
        }
        if (j) {
            K.doEvent(m[0], j, L)
        }
        var S = false;
        if (W) {
            W.each(function () {
                var ab = $(this);
                var aa = K.form.validate(ab);
                if (aa === false) {
                    S = true
                }
            })
        }
        if (S) {
            return false
        }
        if (a) {
            L = K.doEvent(m[0], a, L);
            if (L === false) {
                return
            }
        }
        Tools.apply(L, {"SYSTEM_BUTTON_DESCRIPT": l});
        if (h == "PAGE") {
            var D = {
                menuid: m.attr("data-menuid"),
                url: m.attr("data-target"),
                title: m.attr("data-menuname"),
                icon: m.attr("data-icon")
            };
            K.index.openPage(D, L);
            return
        }
        $ttarget = $(m.attr("data-target"));
        if (h == "RESET") {
            K.form.reset($ttarget);
            K.btn.doAfterSuccess(m, L);
            return
        }
        if (h == "EXPORT") {
            var Q = fuc_str2Json(m.attr("data-export-params"));
            if (!Q) {
                Q = {}
            }
            if ($ttarget.length > 0 && $ttarget.hasClass("k-grid")) {
                var Z = "导出列表";
                var N = $ttarget.parents("div.panel-heading");
                if (N.length > 0) {
                    Z = N.text()
                } else {
                    try {
                        Z = K.index.getPage().parent().attr("data-title")
                    } catch (V) {
                    }
                }
                if (!Q.documentName) {
                    Q.documentName = Z
                }
                if (!Q.reportTitle) {
                    Q.reportTitle = Z
                }
                var T = $ttarget.data("data-params"), R = $ttarget.data("ajaxparams"), H = {};
                if (T) {
                    Tools.apply(H, T)
                }
                if (R) {
                    Tools.apply(H, R)
                }
                if (H.limit) {
                    H.limit = Global.reportParagrapSize[Global.reportFormat.XLS]
                }
                if (H.query_num) {
                    H.query_num = Global.reportParagrapSize[Global.reportFormat.XLS]
                }
                for (var B in H) {
                    if (H[B] == undefined || H[B] == null) {
                        H[B] = ""
                    }
                }
                Tools.applyIf(H, L);
                Q.search_params = Tools.json2str(H);
                var y = [], x = [], J = [], w = [], A = [], v = [], u = [];
                var O = $ttarget.children("tbody"), U = O.data("columns_tr");
                U.find("td").each(function (aa) {
                    var ac = $(this);
                    if (ac.find("input[type=checkbox]").length > 0 || ac.hasClass("k-buttons")) {
                    } else {
                        var ab = ac.attr("data-name");
                        if (ac.attr("data-hidden") == "true") {
                            return
                        }
                        y.push(ac.attr("data-header"));
                        J.push(ac.attr("width") || 100);
                        A.push(ac.attr("data-dict") || "");
                        v.push(ac.attr("data-type") || "string");
                        u.push(ab);
                        w.push(ac.attr("data-align") || "")
                    }
                });
                Q.headers = y.join(",");
                Q.hiddens = x.join(",");
                Q.widths = J.join(",");
                Q.aligns = w.join(",");
                Q.dicts = A.join(",");
                Q.columnTypes = v.join(",");
                Q.columns = u.join(",");
                Tools.submit2BlankWindow("base/export-excel.excel", Q)
            } else {
                return
            }
            K.btn.doAfterSuccess(m, L);
            return
        }
        if (h == "POPUP") {
            var z;
            if (F != undefined) {
                z = F
            }
            if (z) {
                $ttarget.data("submit_old_data", z)
            }
            $ttarget.find(".k-btn").each(function () {
                $(this).data("data-paneltype", "grid")
            });
            K.popup($ttarget);
            K.btn.setTargetParams($ttarget, L);
            var X = K.btn.doAfterSuccess(m, L);
            if (X === false) {
                return
            }
            return
        }
        if ((m.parents("table.k-grid").length > 0 || m.parents("table.k-treegrid2").length > 0) && h == "SUBMIT") {
            m.data("data-paneltype", "grid")
        }
        if (h == "SUBMIT") {
            var z;
            if (W) {
                z = W.data("submit_old_data")
            }
            if (L && z != null) {
                L.submit_old_data = Tools.json2str(z)
            }
            if ($ttarget.length > 0 && ($ttarget.hasClass("k-grid") || $ttarget.hasClass("k-treegrid2") || $ttarget.hasClass("k-treegrid"))) {
                var s = m.attr("data-generate-id");
                if (!s) {
                    s = Math.uuidFast();
                    m.attr("data-generate-id", s)
                }
                if (L != undefined && L != null) {
                    L.button_generate_id = s
                }
            }
            if ($ttarget.length > 0 && $ttarget.hasClass("k-grid")) {
                var R = $ttarget.data("ajaxparams");
                for (items in L) {
                    R[items] = L[items]
                }
                R.submit_old_data = null;
                $ttarget.data("ajaxparams", R)
            }
            var P = function (ac) {
                var ab = K.btn.doAfterSuccess2(m, L, ac);
                if (ab === false) {
                    return false
                }
                var ad = m.parents("div.k-popup");
                if (p != "false") {
                    if (ad.length > 0 && g !== "false") {
                        K.popup.close(ad);
                        if (W) {
                            W.data("submit_old_data", null)
                        }
                    }
                }
                var aa = m.attr("data-contain-params");
                if (aa == "true") {
                    Tools.apply(L, ac);
                    K.btn.setTargetParams($ttarget, L);
                    return true
                }
                if (m.data("data-paneltype") == "grid" || ad.length > 0) {
                    K.btn.setTargetParams($ttarget)
                } else {
                    Tools.apply(L, ac);
                    K.btn.setTargetParams($ttarget, L)
                }
                return true
            };
            var I = function (ab) {
                var aa = K.btn.doCallback(m, L, ab);
                if (aa === false) {
                    return false
                }
            };
            if (L) {
                if (L.exeid) {
                    q = L.exeid
                }
                if (L.url) {
                    e = L.url
                }
            } else {
                q = null;
                e = null
            }
            if (q || e) {
                L.grid_save_page = true;
                var E = true;
                if (i == "false") {
                    E = false
                }
                var M = {
                    params: L, afterSuccess: function (ab) {
                        var aa = P(ab);
                        return aa
                    }, callback: function (ab) {
                        var aa = I(ab);
                        return aa
                    }, errorsalert: E
                };
                if (e) {
                    if (e == "bizware") {
                        Tools.apply(M, {url: e, serviceCode: L.serviceCode, businessCode: L.businessCode})
                    } else {
                        Tools.apply(M, {url: e})
                    }
                    Util.ajaxRequest(M)
                } else {
                    if (q) {
                        Tools.apply(M, {exeid: q});
                        Util.ajaxRequest(M)
                    }
                }
            } else {
                P()
            }
            return
        }
    };
    if (o == null || o == "" || o == "false") {
        f.call(m[0])
    } else {
        if (o == "true") {
            if (l) {
                l = "确认" + l + "吗？"
            } else {
                l = "确认执行操作吗？"
            }
        } else {
            l = o
        }
        Tools.confirm(l, function (s) {
            if (s) {
                f.call(m[0])
            } else {
                return
            }
        })
    }
};
var checkbutton = function (b) {
    if (b.button_id == null || b.button_id == undefined) {
    } else {
        var a = b.button_id;
        Util.ajaxQuery({
            exeid: "M0020EQ009", params: {buttonid: a}, async: false, afterSuccess: function (c) {
                if (c.rows.length > 0) {
                    a = c.rows[0].buttonid
                }
            }
        }, false);
        b.button_id = "";
        Util.ajaxQuery({
            exeid: "M0020EQ007", params: {buttonid: a}, async: false, afterSuccess: function (c) {
                if (c.rows.length > 0) {
                    a = c.rows[0].newbuttonid
                }
            }
        }, false);
        b.button_id = a
    }
    return b
};
K.btn.reloadGrid = function (a, b) {
    if (a.hasClass("k-grid")) {
        if (K.grid && K.grid.load) {
            if (b && b.grid_save_page != true) {
                a.data("page", 0)
            }
            K.grid.load(a, b)
        }
    } else {
        if (a.hasClass("k-treegrid2")) {
            if (K.treegrid2 && K.treegrid2.load) {
                K.treegrid2.load(a, b)
            }
        }
    }
};
K.btn.simpleButton2 = function (b) {
    if (b.data("inited") === true) {
        return
    }
    b.data("inited", true);
    var a = b.attr("type");
    if ((a == null || a == "") && b[0].tagName.toUpperCase() == "BUTTON") {
        b.attr("type", "button")
    }
    if (!b.attr("title")) {
        b.attr("title", b.attr("data-descript"))
    }
    if (b.attr("data-disabled") == "true") {
        K.btn.disable(b)
    }
    K.btn.doDisableCondition(b);
    K.btn.doHiddenCondition(b);
    b.on("click", function () {
        K.btn.handle($(this))
    })
};
K.btn.setTargetParams = function (c, b) {
    var a;
    if (typeof id == "string") {
        a = $(c)
    } else {
        a = c
    }
    a.each(function () {
        var d = $(this);
        if (d.hasClass("k-grid") || d.hasClass("k-treegrid2")) {
            K.btn.reloadGrid(d, b)
        } else {
            if (d[0].tagName.toUpperCase() == "FORM") {
                K.form.setparams(d, b)
            } else {
                d.find("table.k-grid").each(function () {
                    K.btn.reloadGrid($(this), b)
                });
                d.find("form").each(function () {
                    K.form.setparams(d, b)
                });
                d.find("table.k-treegrid2").each(function () {
                    K.btn.reloadGrid($(this), b)
                })
            }
        }
    })
};
K.popup = function (d) {
    if (d == null) {
        return
    }
    var a = $(d);
    if (a.length == 0) {
        return
    }
    var j = a.data("popup-mask");
    if (j == null) {
        a.css("display", "");
        j = Tools.makeMask(a);
        $('<a class="close" title="关闭"><span>&times;</span></a>').appendTo(a.children(".panel-heading")).click(function () {
            j.hide()
        });
        a.find(".k-popup-close").click(function () {
            j.hide()
        });
        a.data("popup-mask", j);
        resizePopup(a);
        var g;
        var i;
        var c;
        var h;

        function b(l) {
            g = l.screenX;
            i = l.screenY
        }

        function e(o) {
            c = o.screenX;
            h = o.screenY;
            if (o.offsetY < 0) {
                return
            }
            var m = c - g;
            var q = h - i;
            var p = a;
            var n = parseFloat(p.css("margin-left").replace("px", ""));
            var l = parseFloat(p.css("margin-top").replace("px", ""));
            g = g + m;
            i = i + q;
            p.css("margin-left", n + m + "px");
            p.css("margin-top", l + q + "px")
        }

        var f = false;
        a.find(".panel-heading").css("cursor", "move");
        a.find(".panel-heading").mousedown(function (l) {
            b(l);
            f = true
        });
        a.parent().mousemove(function (l) {
            if (f) {
                e(l)
            }
        });
        a.parent().mouseup(function (l) {
            f = false
        })
    }
    j.show()
};
K.popup.close = function (a) {
    $(".paging-div select").attr("style", "");
    if (a == null) {
        return
    }
    var c;
    if (typeof a == "string") {
        c = $(a)
    } else {
        c = a
    }
    if (c.length == 0) {
        return
    }
    var b = c.data("popup-mask");
    if (b == null) {
        return
    }
    b.hide()
};

function resizePopup(d) {
    var c = "<span class='resize-span'></span>";
    d.append(c);
    var a = d.height();
    var b = d.width() / 2;
    $(".resize-span").mousedown(function (i) {
        var h = this;
        var g = $(h).parents(".k-popup");
        var f = i.clientX - g.width();
        var j = i.clientY - g.height();
        $(document).mousemove(function (n) {
            var m = n.clientX - f;
            var l = n.clientY - j;
            m = m < b ? b : m;
            l = l < a ? a : l;
            g.css({width: m + "px", height: l + "px"})
        });
        $(document).mouseup(function () {
            $(document).unbind("mousemove")
        })
    })
}

$(function () {
    K.init()
});